"""Global Bridge MCP: no project root is captured at server startup."""
import json
import os
import sys
from pathlib import Path
from urllib.request import Request, build_opener, ProxyHandler, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
import ntpath


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise ValueError('LOCAL_BRIDGE_REDIRECT_DENIED')


class Bridge:
    def request(self, path, body=None, timeout=8):
        cfg = json.loads((Path(os.environ.get('AI_BRIDGE_DATA_DIR', str(Path.home()/'.ai_bridge'))) / 'connection.json').read_text(encoding='utf-8'))
        url = urlsplit(cfg['url'])
        if url.scheme != 'http' or url.hostname not in ('127.0.0.1','localhost','::1') or not url.port or url.username or url.password or url.path not in ('','/') or url.query or url.fragment:
            raise ValueError('LOCAL_BRIDGE_URL_REQUIRED')
        request = Request(cfg['url'].rstrip('/') + path, data=None if body is None else json.dumps(body).encode(),
            headers={'Authorization': 'Bearer '+cfg['token'], 'Content-Type': 'application/json'})
        try:
            with build_opener(ProxyHandler({}), NoRedirect()).open(request, timeout=timeout) as response:
                data = response.read(2_000_001)
        except HTTPError as exc:
            if exc.code == 404:
                raise ValueError('ENDPOINT_OR_COMMAND_NOT_FOUND: staged async/trace support requires Runtime activation') from None
            raise ValueError('BRIDGE_HTTP_'+str(exc.code)) from None
        if len(data)>2_000_000:
            raise ValueError('RESPONSE_TOO_LARGE: query fewer events')
        return json.loads(data)

    def context(self):
        return self.request('/client/context')

    def submit(self, command_id, workspace, adapter, operation, arguments=None, session_id=None, project_file=None):
        context = self.context()
        if workspace not in context['workspaces']:
            raise ValueError('WORKSPACE_NOT_REGISTERED')
        if adapter in ('unreal','houdini'):
            if not session_id or not project_file:
                raise ValueError('EXPLICIT_SESSION_AND_PROJECT_REQUIRED')
            matches = [s for s in context['sessions'] if s['session_id']==session_id and s['adapter']==adapter
                       and ntpath.normcase(ntpath.normpath(s['project_file']))==ntpath.normcase(ntpath.normpath(project_file))]
            if len(matches)!=1:
                raise ValueError('CURRENT_SESSION_PROJECT_MISMATCH')
            target = matches[0]
            roots = [w['root'] for w in context.get('workspace_details',[]) if w['workspace_id']==workspace]
            if len(roots)!=1 or ntpath.commonpath([ntpath.normcase(roots[0]),ntpath.normcase(project_file)]) != ntpath.normpath(ntpath.normcase(roots[0])):
                raise ValueError('PROJECT_OUTSIDE_WORKSPACE')
        elif adapter=='workspace':
            if session_id or project_file:
                raise ValueError('WORKSPACE_COMMAND_HAS_NO_HOST_SESSION')
            if operation not in ('workspace.project.inspect','workspace.command.run'):
                raise ValueError('WORKSPACE_OPERATION_NOT_EXPOSED')
            target = next((d for d in context.get('local_adapters',[]) if d['adapter']==adapter), {})
        else:
            raise ValueError('ONLY_UE_HOUDINI_AND_DECLARED_WORKSPACE_COMMANDS')
        capability = next((c for c in target.get('capabilities',[]) if c['name']==operation), None)
        if capability is None:
            raise ValueError('CAPABILITY_NOT_ADVERTISED: inspect current context')
        command = {'protocol':'bridge/1','command_id':command_id,'workspace':workspace,'adapter':adapter,
            'operation':operation,'arguments':arguments or {},'risk':capability['risk'],
            'execution':{'verify':True,'checkpoint':'auto','dry_run':False}}
        if session_id:
            command.update(session=session_id,project_file=project_file)
        try:
            return self.request('/client/jobs',command)
        except (TimeoutError, URLError):
            return {'command_id':command_id,'status':'acceptance_unknown','do_not_replay':True,
                    'next':'Query ta_bridge_status using this same command_id before any retry.'}

    def status(self, command_id, after=0, limit=50, log_offset=None):
        from urllib.parse import quote
        path='/client/jobs/'+quote(command_id,safe='')+'?after='+str(max(0,int(after)))+'&limit='+str(max(1,min(200,int(limit))))
        if log_offset is not None: path+='&log_offset='+str(max(0,int(log_offset)))
        return self.request(path)

    def result(self, command_id):
        from urllib.parse import quote
        return self.request('/results/'+quote(command_id,safe=''))

    def cancel(self, command_id, close_host=False):
        if type(close_host) is not bool: raise ValueError('CLOSE_HOST_MUST_BE_BOOLEAN')
        from urllib.parse import quote
        return self.request('/client/jobs/'+quote(command_id,safe='')+'/cancel', {'close_host':close_host})


def schema(properties, required=()):
    return {'type':'object','properties':properties,'required':list(required),'additionalProperties':False}


TOOLS = [
    ('ta_bridge_cancel','Cancel the process tree owned by command_id. close_host defaults false; set true only when the user also requests normal closure of that command-bound UE/Houdini session. Unsaved-work prompts require the user; never force-kills the Host or selects a different project. Check status for actual exit.',schema({'command_id':{'type':'string'},'close_host':{'type':'boolean','default':False}},['command_id']),False,'cancel'),
    ('ta_bridge_context','Discover live UE/Houdini sessions, exact projects, workspaces and declared capabilities before executing. Global scope; never guesses a project.',schema({}),True,'context'),
    ('ta_bridge_submit','Submit one authorized declared UE/Houdini operation or registered workspace command asynchronously. Supply a stable command_id; query it on timeout, never generate a new ID to retry. Host calls require explicit session/project/workspace.',schema({
        'command_id':{'type':'string'},'workspace':{'type':'string'},'adapter':{'enum':['unreal','houdini','workspace']},
        'operation':{'type':'string'},'arguments':{'type':'object'},'session_id':{'type':'string'},'project_file':{'type':'string'}},['command_id','workspace','adapter','operation']),False,'submit'),
    ('ta_bridge_status','Read command state and incremental lifecycle/process progress using after cursor; log_offset reads up to 16KB of the full process log. Silence does not prove a stall; inspect process_running and output_idle_seconds. Historical commands may have no trace.',schema({'command_id':{'type':'string'},'after':{'type':'integer','default':0},'limit':{'type':'integer','default':50},'log_offset':{'type':'integer'}},['command_id']),True,'status'),
    ('ta_bridge_result','Read original command and final receipt/evidence reference. Missing terminal result means unknown or still running; never replay a mutation to find its result.',schema({'command_id':{'type':'string'}},['command_id']),True,'result'),
]


def serve():
    bridge = Bridge()
    mapping = {row[0]:row for row in TOOLS}
    for line in sys.stdin:
        rid = None
        try:
            if len(line)>1_000_000: raise ValueError('REQUEST_TOO_LARGE')
            message = json.loads(line)
            rid = message.get('id')
            if rid is None: continue
            method = message['method']
            params = message.get('params') or {}
            if method=='initialize':
                result = {'protocolVersion':'2025-06-18','serverInfo':{'name':'global-ai-bridge','version':'1.0.0'},'capabilities':{'tools':{}},
                    'instructions':'Use context to select explicit current project/session. Submit once with a stable command_id; poll status with its cursor. Never interpret timeout/silent output as permission to replay. Capabilities describe execution facts; only user-authorized actions may be submitted.'}
            elif method=='tools/list':
                result = {'tools':[{'name':n,'description':d,'inputSchema':s,'annotations':{'readOnlyHint':ro,'openWorldHint':False}} for n,d,s,ro,fn in TOOLS]}
            elif method=='tools/call':
                try:
                    tool = mapping[params['name']]
                    args = params.get('arguments') or {}
                    if not isinstance(args,dict) or set(args)-set(tool[2]['properties']) or set(tool[2]['required'])-set(args):
                        raise ValueError('INVALID_ARGUMENTS')
                    data = getattr(bridge,tool[4])(**args)
                    result = {'content':[{'type':'text','text':json.dumps(data,ensure_ascii=False)}],'isError':False}
                except Exception as exc:
                    result = {'content':[{'type':'text','text':json.dumps({'error':type(exc).__name__,'detail':str(exc)[:400]},ensure_ascii=False)}],'isError':True}
            elif method=='ping': result={}
            else:
                raise ValueError('METHOD_NOT_SUPPORTED')
            answer={'jsonrpc':'2.0','id':rid,'result':result}
        except Exception as exc:
            answer={'jsonrpc':'2.0','id':rid,'error':{'code':-32600,'message':type(exc).__name__}}
        print(json.dumps(answer,ensure_ascii=False),flush=True)


if __name__=='__main__':
    serve()
