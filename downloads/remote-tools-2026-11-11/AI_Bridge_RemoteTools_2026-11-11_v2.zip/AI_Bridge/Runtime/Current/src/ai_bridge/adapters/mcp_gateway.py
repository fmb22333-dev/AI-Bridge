from __future__ import annotations

import hashlib
import json
import os
import queue
import subprocess
import threading
import time
import tomllib
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ai_bridge.adapters.registry import AdapterDescriptor
from ai_bridge.core.workspace import WorkspaceRegistry
from ai_bridge.protocol.capability import CapabilityDescriptor
from ai_bridge.protocol.command import CommandEnvelope, RiskLevel
from ai_bridge.protocol.result import (
    ExecutionResult,
    ExecutionStatus,
    FailureInfo,
    FailureOrigin,
)

ADAPTER_NAME = "mcp_gateway"
MAX_RESPONSE_BYTES = 4 * 1024 * 1024
MAX_BATCH_CALLS = 16


class MCPCallAmbiguous(RuntimeError):
    """The request was sent but a terminal MCP response was not observed."""


@dataclass(frozen=True)
class MCPServerSpec:
    server_id: str
    source: str
    name: str
    command: str
    args: tuple[str, ...]
    cwd: str
    env: tuple[tuple[str, str], ...]
    enabled_tools: tuple[str, ...] | None
    fingerprint: str

    def launch_env(self) -> dict[str, str]:
        env = dict(os.environ)
        env.update(dict(self.env))
        return env

    def public(self) -> dict[str, Any]:
        return {
            "server_id": self.server_id,
            "source": self.source,
            "name": self.name,
            "transport": "stdio",
            "command": self.command,
            "cwd": self.cwd,
            "enabled_tools": list(self.enabled_tools) if self.enabled_tools is not None else None,
            "fingerprint": self.fingerprint,
        }


class _StdioSession:
    def __init__(self, spec: MCPServerSpec, *, request_timeout: float) -> None:
        self.spec = spec
        self.request_timeout = max(0.25, float(request_timeout))
        self._lock = threading.RLock()
        self._queue: queue.Queue = queue.Queue()
        self._next_id = 1
        self._closed = False
        self.process = subprocess.Popen(
            [spec.command, *spec.args],
            cwd=spec.cwd,
            env=spec.launch_env(),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            shell=False,
        )
        self._reader = threading.Thread(
            target=self._read_stdout,
            name=f"AI-Bridge-MCP-{spec.name}",
            daemon=True,
        )
        self._reader.start()
        self._initialize()

    @property
    def alive(self) -> bool:
        return not self._closed and self.process.poll() is None

    def _read_stdout(self) -> None:
        stream = self.process.stdout
        try:
            if stream is None:
                return
            for raw in stream:
                if len(raw) > MAX_RESPONSE_BYTES:
                    self._queue.put(RuntimeError("MCP_RESPONSE_TOO_LARGE"))
                    break
                try:
                    self._queue.put(json.loads(raw.decode("utf-8")))
                except Exception as exc:
                    self._queue.put(RuntimeError(f"MCP_INVALID_JSON: {type(exc).__name__}"))
                    break
        finally:
            self._queue.put(EOFError("MCP_STDIO_CLOSED"))

    def _send(self, payload: dict) -> None:
        if not self.alive or self.process.stdin is None:
            raise EOFError("MCP_PROCESS_NOT_RUNNING")
        raw = (json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        if len(raw) > 1024 * 1024:
            raise ValueError("MCP_REQUEST_TOO_LARGE")
        self.process.stdin.write(raw)
        self.process.stdin.flush()

    def request(self, method: str, params: dict | None = None, *, timeout: float | None = None) -> dict:
        with self._lock:
            if not self.alive:
                raise EOFError("MCP_PROCESS_NOT_RUNNING")
            request_id = self._next_id
            self._next_id += 1
            self._send({
                "jsonrpc": "2.0",
                "id": request_id,
                "method": method,
                "params": params or {},
            })
            deadline = time.monotonic() + max(0.25, float(timeout or self.request_timeout))
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError(f"MCP_REQUEST_TIMEOUT: {method}")
                try:
                    item = self._queue.get(timeout=remaining)
                except queue.Empty as exc:
                    raise TimeoutError(f"MCP_REQUEST_TIMEOUT: {method}") from exc
                if isinstance(item, BaseException):
                    raise item
                if not isinstance(item, dict):
                    continue
                if item.get("id") != request_id:
                    # R4 serializes requests per stdio server. Notifications and
                    # unrelated frames are ignored, never treated as our result.
                    continue
                if "error" in item:
                    error = item.get("error") or {}
                    raise RuntimeError(
                        "MCP_REMOTE_ERROR: "
                        + str(error.get("code") or "")
                        + " "
                        + str(error.get("message") or "")
                    )
                result = item.get("result")
                if not isinstance(result, dict):
                    raise RuntimeError("MCP_RESULT_NOT_OBJECT")
                if len(json.dumps(result, ensure_ascii=False, default=str).encode("utf-8")) > MAX_RESPONSE_BYTES:
                    raise RuntimeError("MCP_RESPONSE_TOO_LARGE")
                return result

    def notify(self, method: str, params: dict | None = None) -> None:
        with self._lock:
            self._send({"jsonrpc": "2.0", "method": method, "params": params or {}})

    def _initialize(self) -> None:
        self.request(
            "initialize",
            {
                "protocolVersion": "2025-06-18",
                "capabilities": {},
                "clientInfo": {"name": "ai-bridge-workstation-hub", "version": "r4"},
            },
        )
        self.notify("notifications/initialized")

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            try:
                if self.process.stdin is not None:
                    self.process.stdin.close()
            except Exception:
                pass
            if self.process.poll() is None:
                try:
                    self.process.terminate()
                    self.process.wait(timeout=1.5)
                except Exception:
                    try:
                        self.process.kill()
                    except Exception:
                        pass
            try:
                if self.process.stdout is not None:
                    self.process.stdout.close()
            except Exception:
                pass
        self._reader.join(timeout=1.0)


class MCPGateway:
    def __init__(
        self,
        *,
        workspaces: WorkspaceRegistry,
        global_config_path: Path | None = None,
        request_timeout: float = 30.0,
    ) -> None:
        self.workspaces = workspaces
        self.global_config_path = (
            Path(global_config_path)
            if global_config_path is not None
            else Path.home() / ".codex" / "config.toml"
        )
        self.request_timeout = max(0.25, float(request_timeout))
        self._lock = threading.RLock()
        self._sessions: dict[str, _StdioSession] = {}
        self._tool_cache: dict[str, tuple[str, list[dict]]] = {}
        self.closed = False

    @staticmethod
    def _fingerprint(payload: dict) -> str:
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    @staticmethod
    def _raw_servers(path: Path) -> dict[str, dict]:
        if not path.is_file():
            return {}
        try:
            raw = tomllib.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {}
        servers = raw.get("mcp_servers")
        if not isinstance(servers, dict):
            return {}
        return {
            str(name): dict(cfg)
            for name, cfg in servers.items()
            if isinstance(cfg, dict)
        }

    @staticmethod
    def _merged_server_config(base: dict | None, overlay: dict | None) -> dict:
        merged = dict(base or {})
        if overlay is None:
            return merged
        base_env = merged.get("env") if isinstance(merged.get("env"), dict) else {}
        overlay_env = overlay.get("env") if isinstance(overlay.get("env"), dict) else None
        for key, value in overlay.items():
            if key == "env":
                continue
            merged[key] = value
        if overlay_env is not None:
            merged["env"] = {**base_env, **overlay_env}
        return merged

    @classmethod
    def _make_spec(
        cls,
        *,
        name: str,
        cfg: dict,
        source: str,
        cwd: Path,
    ) -> MCPServerSpec | None:
        if cfg.get("enabled") is False:
            return None
        command = str(cfg.get("command") or "").strip()
        if not command:
            # Streamable HTTP and other transports are deferred in R4.
            return None
        args_raw = cfg.get("args") or []
        if not isinstance(args_raw, list):
            return None
        args = tuple(str(x) for x in args_raw)
        env_raw = cfg.get("env") or {}
        env = tuple(
            sorted(
                (str(k), str(v))
                for k, v in env_raw.items()
                if isinstance(k, str)
            )
        ) if isinstance(env_raw, dict) else tuple()
        enabled_raw = cfg.get("enabled_tools")
        enabled_tools = (
            tuple(str(x) for x in enabled_raw)
            if isinstance(enabled_raw, list)
            else None
        )
        server_id = f"{source}:{name}"
        payload = {
            "command": command,
            "args": args,
            "cwd": str(cwd.resolve()),
            "env": env,
            "enabled_tools": enabled_tools,
        }
        return MCPServerSpec(
            server_id=server_id,
            source=source,
            name=str(name),
            command=command,
            args=args,
            cwd=str(cwd.resolve()),
            env=env,
            enabled_tools=enabled_tools,
            fingerprint=cls._fingerprint(payload),
        )

    def _discover(self, workspace_id: str | None = None) -> dict[str, MCPServerSpec]:
        global_raw = self._raw_servers(self.global_config_path)
        global_cwd = (
            self.global_config_path.parent
            if self.global_config_path.parent.is_dir()
            else Path.home()
        )

        found: dict[str, MCPServerSpec] = {}
        if workspace_id is None:
            for name in sorted(global_raw):
                spec = self._make_spec(
                    name=name,
                    cfg=global_raw[name],
                    source="global",
                    cwd=global_cwd,
                )
                if spec is not None:
                    found[spec.server_id] = spec
            for workspace in sorted(self.workspaces.list(), key=lambda item: item.workspace_id):
                if workspace.workspace_id.startswith("__"):
                    continue
                overlay_raw = self._raw_servers(
                    workspace.root / ".codex" / "config.toml"
                )
                for name in sorted(overlay_raw):
                    overlay = overlay_raw[name]
                    if overlay.get("enabled") is False:
                        continue
                    merged = self._merged_server_config(global_raw.get(name), overlay)
                    spec = self._make_spec(
                        name=name,
                        cfg=merged,
                        source=f"workspace:{workspace.workspace_id}",
                        cwd=workspace.root,
                    )
                    if spec is not None:
                        found[spec.server_id] = spec
        else:
            workspace = self.workspaces.get(str(workspace_id))
            overlay_raw = self._raw_servers(
                workspace.root / ".codex" / "config.toml"
            )
            names = sorted(set(global_raw) | set(overlay_raw))
            for name in names:
                overlay_present = name in overlay_raw
                overlay = overlay_raw.get(name)
                if overlay_present and overlay.get("enabled") is False:
                    continue
                merged = self._merged_server_config(global_raw.get(name), overlay)
                source = f"workspace:{workspace.workspace_id}" if overlay_present else "global"
                cwd = workspace.root if overlay_present else global_cwd
                spec = self._make_spec(
                    name=name,
                    cfg=merged,
                    source=source,
                    cwd=cwd,
                )
                if spec is not None:
                    found[spec.server_id] = spec

        with self._lock:
            for server_id, session in list(self._sessions.items()):
                spec = found.get(server_id)
                if spec is None or spec.fingerprint != session.spec.fingerprint:
                    session.close()
                    self._sessions.pop(server_id, None)
                    self._tool_cache.pop(server_id, None)
        return found

    def list_servers(self, workspace_id: str | None = None) -> list[dict]:
        return [spec.public() for spec in self._discover(workspace_id).values()]

    def _spec(self, server_id: str, workspace_id: str | None = None) -> MCPServerSpec:
        spec = self._discover(workspace_id).get(str(server_id))
        if spec is None:
            raise ValueError("MCP_SERVER_NOT_FOUND_OR_OUT_OF_SCOPE")
        return spec

    def _session(self, server_id: str, workspace_id: str | None = None) -> _StdioSession:
        if self.closed:
            raise RuntimeError("MCP_GATEWAY_CLOSED")
        spec = self._spec(server_id, workspace_id)
        with self._lock:
            existing = self._sessions.get(server_id)
            if existing is not None and existing.alive and existing.spec.fingerprint == spec.fingerprint:
                return existing
            if existing is not None:
                existing.close()
            session = _StdioSession(spec, request_timeout=self.request_timeout)
            self._sessions[server_id] = session
            return session

    def status(self, server_id: str, workspace_id: str | None = None) -> dict:
        spec = self._spec(server_id, workspace_id)
        with self._lock:
            session = self._sessions.get(server_id)
            running = bool(session and session.alive and session.spec.fingerprint == spec.fingerprint)
            pid = int(session.process.pid) if running and session is not None else None
        return {
            **spec.public(),
            "state": "running" if running else "stopped",
            "pid": pid,
            "schema_cached": server_id in self._tool_cache,
        }

    @staticmethod
    def _normalize_tools(spec: MCPServerSpec, payload: dict) -> list[dict]:
        raw = payload.get("tools")
        if not isinstance(raw, list):
            raise RuntimeError("MCP_TOOLS_LIST_INVALID")
        allowed = set(spec.enabled_tools) if spec.enabled_tools is not None else None
        rows = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "").strip()
            if not name or (allowed is not None and name not in allowed):
                continue
            annotations = item.get("annotations") if isinstance(item.get("annotations"), dict) else {}
            rows.append(
                {
                    "name": name,
                    "description": str(item.get("description") or "")[:2000],
                    "inputSchema": item.get("inputSchema") if isinstance(item.get("inputSchema"), dict) else {"type": "object"},
                    "annotations": dict(annotations),
                    "read_only": annotations.get("readOnlyHint") is True,
                }
            )
        return rows

    def list_tools(self, server_id: str, workspace_id: str | None = None) -> list[dict]:
        spec = self._spec(server_id, workspace_id)
        cached = self._tool_cache.get(server_id)
        if cached is not None and cached[0] == spec.fingerprint:
            return [dict(x) for x in cached[1]]
        try:
            payload = self._session(server_id, workspace_id).request("tools/list")
        except Exception:
            # Metadata discovery is safe to retry once with a fresh process.
            with self._lock:
                prior = self._sessions.pop(server_id, None)
                if prior is not None:
                    prior.close()
            payload = self._session(server_id, workspace_id).request("tools/list")
        rows = self._normalize_tools(spec, payload)
        self._tool_cache[server_id] = (spec.fingerprint, rows)
        return [dict(x) for x in rows]

    def _tool(self, server_id: str, tool: str, workspace_id: str | None = None) -> dict:
        for item in self.list_tools(server_id, workspace_id):
            if item["name"] == tool:
                return item
        raise ValueError("MCP_TOOL_NOT_FOUND")

    def call_readonly(self, server_id: str, tool: str, arguments: dict | None = None, *, workspace_id: str | None = None) -> dict:
        item = self._tool(server_id, str(tool), workspace_id)
        if item.get("read_only") is not True:
            raise ValueError("MCP_TOOL_NOT_READ_ONLY")
        session = self._session(server_id, workspace_id)
        try:
            result = session.request(
                "tools/call",
                {"name": str(tool), "arguments": dict(arguments or {})},
            )
        except (EOFError, TimeoutError, BrokenPipeError, OSError) as exc:
            with self._lock:
                prior = self._sessions.pop(server_id, None)
                self._tool_cache.pop(server_id, None)
                if prior is not None:
                    prior.close()
            raise MCPCallAmbiguous(
                f"MCP_CALL_AMBIGUOUS_DO_NOT_REPLAY: {type(exc).__name__}: {exc}"
            ) from exc
        return {
            "server_id": server_id,
            "tool": str(tool),
            "result": result,
            "read_only_verified": True,
        }

    def batch_readonly(self, calls: list[dict], *, stop_on_error: bool = True, workspace_id: str | None = None) -> dict:
        if not isinstance(calls, list) or not 1 <= len(calls) <= MAX_BATCH_CALLS:
            raise ValueError("MCP_BATCH_REQUIRES_1_TO_16_CALLS")
        results = []
        complete = True
        for index, call in enumerate(calls):
            if not isinstance(call, dict):
                raise ValueError("MCP_BATCH_CALL_INVALID")
            server_id = str(call.get("server_id") or "")
            tool = str(call.get("tool") or "")
            arguments = call.get("arguments") or {}
            try:
                value = self.call_readonly(server_id, tool, arguments, workspace_id=workspace_id)
                results.append({"index": index, "status": "success", **value})
            except MCPCallAmbiguous as exc:
                complete = False
                results.append({"index": index, "status": "unknown", "error": str(exc)})
                if stop_on_error:
                    break
            except Exception as exc:
                complete = False
                results.append({
                    "index": index,
                    "status": "failed",
                    "error": f"{type(exc).__name__}: {exc}"[:500],
                })
                if stop_on_error:
                    break
        return {
            "count": len(results),
            "requested_count": len(calls),
            "complete": complete and len(results) == len(calls),
            "results": results,
        }

    def capability_rows(self, workspace_id: str | None = None) -> list[dict]:
        rows = []
        for server in self.list_servers(workspace_id):
            server_id = server["server_id"]
            try:
                tools = self.list_tools(server_id, workspace_id)
            except Exception:
                continue
            for tool in tools:
                if tool.get("read_only") is not True:
                    continue
                rows.append({
                    "target": f"mcp:{server_id}:{tool['name']}",
                    "kind": "mcp",
                    "server_id": server_id,
                    "name": tool["name"],
                    "description": tool.get("description") or "",
                    "write": False,
                    "host_mutation": False,
                    "risk": "L1",
                })
        return rows

    def close(self) -> None:
        with self._lock:
            if self.closed:
                return
            self.closed = True
            sessions = list(self._sessions.values())
            self._sessions.clear()
            self._tool_cache.clear()
        for session in sessions:
            session.close()


class MCPGatewayExecutor:
    def __init__(self, gateway: MCPGateway) -> None:
        self.gateway = gateway

    @staticmethod
    def _success(command_id: str, result: dict) -> ExecutionResult:
        return ExecutionResult(
            command_id=command_id,
            status=ExecutionStatus.SUCCESS,
            result=result,
        )

    @staticmethod
    def _failure(
        command_id: str,
        status: ExecutionStatus,
        code: str,
        message: str | None = None,
    ) -> ExecutionResult:
        return ExecutionResult(
            command_id=command_id,
            status=status,
            failure=FailureInfo(
                origin=FailureOrigin.ADAPTER,
                code=code,
                message=message,
            ),
        )

    def execute(self, command: CommandEnvelope) -> ExecutionResult:
        try:
            op = command.operation
            args = command.arguments or {}
            if op == "mcp.server.list":
                return self._success(command.command_id, {"servers": self.gateway.list_servers(command.workspace)})
            if op == "mcp.server.status":
                return self._success(command.command_id, self.gateway.status(str(args.get("server_id") or ""), command.workspace))
            if op == "mcp.tools.list":
                server_id = str(args.get("server_id") or "")
                return self._success(
                    command.command_id,
                    {"server_id": server_id, "tools": self.gateway.list_tools(server_id, command.workspace)},
                )
            if op == "mcp.tool.call":
                return self._success(
                    command.command_id,
                    self.gateway.call_readonly(
                        str(args.get("server_id") or ""),
                        str(args.get("tool") or ""),
                        args.get("arguments") or {},
                        workspace_id=command.workspace,
                    ),
                )
            if op == "mcp.batch":
                return self._success(
                    command.command_id,
                    self.gateway.batch_readonly(
                        args.get("calls") or [],
                        stop_on_error=bool(args.get("stop_on_error", True)),
                        workspace_id=command.workspace,
                    ),
                )
            return self._failure(
                command.command_id,
                ExecutionStatus.DENIED,
                "CAPABILITY_NOT_SUPPORTED",
                op,
            )
        except MCPCallAmbiguous as exc:
            return self._failure(
                command.command_id,
                ExecutionStatus.UNKNOWN,
                "MCP_CALL_AMBIGUOUS_DO_NOT_REPLAY",
                str(exc),
            )
        except ValueError as exc:
            code = str(exc) or "MCP_ARGUMENT_INVALID"
            status = (
                ExecutionStatus.DENIED
                if code.startswith("MCP_TOOL_NOT_READ_ONLY")
                else ExecutionStatus.FAILED
            )
            return self._failure(command.command_id, status, code)
        except Exception as exc:
            return self._failure(
                command.command_id,
                ExecutionStatus.FAILED,
                "MCP_GATEWAY_FAILED",
                f"{type(exc).__name__}: {exc}",
            )


def descriptor() -> AdapterDescriptor:
    capabilities = [
        CapabilityDescriptor(name="mcp.server.list", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
        CapabilityDescriptor(name="mcp.server.status", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
        CapabilityDescriptor(name="mcp.tools.list", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
        CapabilityDescriptor(name="mcp.tool.call", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
        CapabilityDescriptor(name="mcp.batch", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
    ]
    return AdapterDescriptor(
        adapter=ADAPTER_NAME,
        adapter_version="0.1.0",
        endpoint="local://mcp-gateway",
        capabilities=capabilities,
    )
