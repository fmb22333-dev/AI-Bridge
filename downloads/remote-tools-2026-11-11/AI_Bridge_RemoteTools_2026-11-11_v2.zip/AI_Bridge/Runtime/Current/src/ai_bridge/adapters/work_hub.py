from __future__ import annotations

import hashlib
import json
import os
import re
import threading
import uuid
from pathlib import Path
from typing import Any

from ai_bridge.adapters.registry import AdapterDescriptor
from ai_bridge.protocol.capability import CapabilityDescriptor
from ai_bridge.protocol.command import CommandEnvelope, RiskLevel
from ai_bridge.protocol.result import (
    ExecutionResult,
    ExecutionStatus,
    FailureInfo,
    FailureOrigin,
)

ADAPTER_NAME = "work_hub"
EXCLUDED_BRIDGE_ADAPTERS = {"work_hub", "mcp_gateway", "bridge_admin", "bridge_transport"}
MAX_DOC_BYTES = 512 * 1024
MAX_BATCH_CALLS = 12
HANDOFF_MAX_BYTES = 24 * 1024


class WorkHubExecutor:
    def __init__(self, service, mcp_gateway) -> None:
        self.service = service
        self.mcp_gateway = mcp_gateway
        self._locks_guard = threading.RLock()
        self._resource_locks: dict[str, threading.RLock] = {}

    def _lock(self, key: str) -> threading.RLock:
        with self._locks_guard:
            return self._resource_locks.setdefault(key, threading.RLock())

    @staticmethod
    def _success(command_id: str, result: dict) -> ExecutionResult:
        return ExecutionResult(
            command_id=command_id,
            status=ExecutionStatus.SUCCESS,
            result=result,
        )

    @staticmethod
    def _failure(
        command_id: str,
        status: ExecutionStatus,
        code: str,
        message: str | None = None,
        *,
        underlying: Any | None = None,
    ) -> ExecutionResult:
        return ExecutionResult(
            command_id=command_id,
            status=status,
            failure=FailureInfo(
                origin=FailureOrigin.CORE,
                code=code,
                message=message,
                underlying=underlying,
            ),
        )

    def _bridge_rows(self) -> list[dict]:
        rows = []
        for descriptor in self.service.adapter_registry.list():
            if descriptor.adapter in EXCLUDED_BRIDGE_ADAPTERS:
                continue
            for cap in descriptor.capabilities:
                rows.append({
                    "target": f"bridge:{descriptor.adapter}:{cap.name}",
                    "kind": "bridge",
                    "adapter": descriptor.adapter,
                    "name": cap.name,
                    "description": cap.name,
                    "version": cap.version,
                    "write": bool(cap.write),
                    "host_mutation": bool(cap.host_mutation),
                    "risk": cap.risk.value,
                })
        return rows

    def _catalog(self, workspace_id: str) -> list[dict]:
        from ai_bridge.transport.control_catalog import capability_rows
        return self._bridge_rows() + self.mcp_gateway.capability_rows(workspace_id) + capability_rows()

    def _row(self, target: str, workspace_id: str) -> dict:
        for row in self._catalog(workspace_id):
            if row.get("target") == target:
                return row
        raise ValueError("HUB_CAPABILITY_TARGET_NOT_FOUND")

    @staticmethod
    def _score(row: dict, query: str) -> int:
        query = str(query or "").strip().casefold()
        if not query:
            return 1
        hay = " ".join(
            str(row.get(key) or "")
            for key in ("target", "name", "description", "adapter", "server_id")
        ).casefold()
        terms = [x for x in re.split(r"\s+", query) if x]
        if not terms:
            return 1
        return sum(4 if term in str(row.get("name") or "").casefold() else 1 for term in terms if term in hay)

    def capability_search(self, query: str = "", max_results: int = 30, workspace_id: str = "") -> dict:
        max_results = max(1, min(100, int(max_results)))
        scored = []
        for row in self._catalog(workspace_id):
            score = self._score(row, query)
            if score > 0:
                scored.append((score, row))
        scored.sort(key=lambda item: (-item[0], str(item[1].get("target") or "")))
        return {
            "query": query,
            "matches": [{**row, "score": score} for score, row in scored[:max_results]],
            "total_matches": len(scored),
            "authority": "runtime_adapter_registry_plus_trusted_local_mcp",
        }

    @staticmethod
    def _inner_id(command_id: str) -> str:
        clean = re.sub(r"[^A-Za-z0-9_.:-]", "_", str(command_id))[:80]
        return f"hub:{clean}:{uuid.uuid4().hex[:12]}"

    def _resource_key(self, row: dict, call: dict) -> str:
        if row.get("kind") == "mcp":
            return "mcp:" + str(row.get("server_id") or "")
        session = str(call.get("session") or "").strip()
        if session:
            return "session:" + session
        return "bridge:" + str(row.get("adapter") or "") + ":" + str(row.get("name") or "")

    def _run_target(self, outer: CommandEnvelope, call: dict) -> ExecutionResult:
        target = str(call.get("target") or "").strip()
        row = self._row(target, outer.workspace)
        if row.get('kind') == 'transport':
            return self._failure(outer.command_id,ExecutionStatus.DENIED,'TRANSPORT_ENVELOPE_REQUIRED',row['invocation'])
        key = self._resource_key(row, call)
        with self._lock(key):
            if row.get("kind") == "mcp":
                try:
                    payload = self.mcp_gateway.call_readonly(
                        str(row["server_id"]),
                        str(row["name"]),
                        call.get("arguments") or {},
                        workspace_id=outer.workspace,
                    )
                    return self._success(
                        outer.command_id,
                        {"target": target, "kind": "mcp", "data": payload},
                    )
                except Exception as exc:
                    code = (
                        "MCP_CALL_AMBIGUOUS_DO_NOT_REPLAY"
                        if "AMBIGUOUS_DO_NOT_REPLAY" in str(exc)
                        else "MCP_CAPABILITY_RUN_FAILED"
                    )
                    status = (
                        ExecutionStatus.UNKNOWN
                        if code == "MCP_CALL_AMBIGUOUS_DO_NOT_REPLAY"
                        else ExecutionStatus.FAILED
                    )
                    return self._failure(
                        outer.command_id,
                        status,
                        code,
                        f"{type(exc).__name__}: {exc}",
                    )

            adapter = str(row.get("adapter") or "")
            if adapter in EXCLUDED_BRIDGE_ADAPTERS:
                return self._failure(
                    outer.command_id,
                    ExecutionStatus.DENIED,
                    "HUB_RECURSIVE_ROUTE_DENIED",
                    target,
                )
            try:
                descriptor = self.service.adapter_registry.get(adapter)
                cap = next(x for x in descriptor.capabilities if x.name == row["name"])
            except Exception:
                return self._failure(
                    outer.command_id,
                    ExecutionStatus.CONFLICT,
                    "HUB_CAPABILITY_STALE",
                    target,
                )
            if cap.write and not str(call.get("session") or "").strip():
                return self._failure(
                    outer.command_id,
                    ExecutionStatus.DENIED,
                    "HUB_WRITE_REQUIRES_SESSION_OR_DIRECT_ADAPTER",
                    target,
                )
            inner = CommandEnvelope(
                command_id=self._inner_id(outer.command_id),
                workspace=str(call.get("workspace") or outer.workspace),
                adapter=adapter,
                session=(str(call.get("session") or "").strip() or None),
                project_file=(str(call.get("project_file") or "").strip() or None),
                operation=str(row["name"]),
                arguments=dict(call.get("arguments") or {}),
                execution=outer.execution.model_copy(deep=True),
                risk=cap.risk,
            )
            nested = self.service.execute(inner)
            return ExecutionResult(
                command_id=outer.command_id,
                status=nested.status,
                result={
                    "target": target,
                    "kind": "bridge",
                    "inner_command_id": inner.command_id,
                    "data": nested.result,
                    "evidence_id": nested.evidence_id,
                },
                failure=nested.failure,
                last_known_state=nested.last_known_state,
                rollback_available=nested.rollback_available,
            )

    def capability_run(self, command: CommandEnvelope) -> ExecutionResult:
        args = command.arguments or {}
        target = str(args.get("target") or "").strip()
        if target.startswith("bridge:work_hub:") or target.startswith("bridge:mcp_gateway:"):
            return self._failure(
                command.command_id,
                ExecutionStatus.DENIED,
                "HUB_RECURSIVE_ROUTE_DENIED",
                target,
            )
        return self._run_target(command, args)

    def capability_batch(self, command: CommandEnvelope) -> ExecutionResult:
        calls = command.arguments.get("calls") if isinstance(command.arguments, dict) else None
        if not isinstance(calls, list) or not 1 <= len(calls) <= MAX_BATCH_CALLS:
            return self._failure(
                command.command_id,
                ExecutionStatus.DENIED,
                "HUB_BATCH_REQUIRES_1_TO_12_CALLS",
            )
        stop_on_error = bool(command.arguments.get("stop_on_error", True))
        # Acquire all shared resources in stable order so two concurrent hub
        # batches cannot invert lock order while targeting the same Host/MCP.
        rows = []
        try:
            for call in calls:
                if not isinstance(call, dict):
                    raise ValueError("HUB_BATCH_CALL_INVALID")
                row = self._row(str(call.get("target") or ""), command.workspace)
                rows.append((call, row))
        except Exception as exc:
            return self._failure(command.command_id, ExecutionStatus.DENIED, str(exc))

        if any(
            row.get("kind") == "bridge"
            and (bool(row.get("write")) or bool(str(call.get("session") or "").strip()))
            for call, row in rows
        ):
            return self._failure(
                command.command_id,
                ExecutionStatus.DENIED,
                "HUB_BATCH_READ_ONLY_NO_SESSION_REQUIRED",
            )

        keys = sorted({self._resource_key(row, call) for call, row in rows})
        locks = [self._lock(key) for key in keys]
        for lock in locks:
            lock.acquire()
        try:
            results = []
            complete = True
            for index, (call, _) in enumerate(rows):
                result = self._run_target(command, call)
                results.append({
                    "index": index,
                    "target": call.get("target"),
                    "status": result.status.value,
                    "result": result.result,
                    "failure": result.failure.model_dump(mode="json") if result.failure else None,
                })
                if result.status != ExecutionStatus.SUCCESS:
                    complete = False
                    if stop_on_error:
                        break
            status = ExecutionStatus.SUCCESS if complete and len(results) == len(calls) else ExecutionStatus.FAILED
            return ExecutionResult(
                command_id=command.command_id,
                status=status,
                result={
                    "count": len(results),
                    "requested_count": len(calls),
                    "complete": complete and len(results) == len(calls),
                    "results": results,
                },
            )
        finally:
            for lock in reversed(locks):
                lock.release()

    @staticmethod
    def _safe_doc(root: Path, relative: str) -> tuple[Path | None, str | None]:
        text = str(relative or "").strip().replace("\\", "/")
        if not text or "\x00" in text or "://" in text:
            return None, "INVALID_OR_REMOTE_LINK"
        text = text.split("#", 1)[0]
        if not text:
            return None, "ANCHOR_ONLY"
        if Path(text).is_absolute() or re.match(r"^[A-Za-z]:", text):
            return None, "ABSOLUTE_LINK_DENIED"
        candidate = (root / text).resolve(strict=False)
        try:
            inside = candidate.is_relative_to(root)
        except AttributeError:
            inside = str(candidate).casefold().startswith(str(root).casefold() + os.sep)
        if not inside:
            return None, "WORKSPACE_PATH_ESCAPE"
        folded = {part.casefold() for part in candidate.relative_to(root).parts}
        if folded & {".git", ".svn", ".codex", ".ai-bridge", "secrets"}:
            return None, "CONTROL_OR_SECRET_PATH"
        if candidate.suffix.casefold() not in {".md", ".txt", ".json"}:
            return None, "DOCUMENT_TYPE_DENIED"
        return candidate, None

    @staticmethod
    def _read_doc(root: Path, path: Path, max_chars: int = 6000) -> dict:
        raw = path.read_bytes()
        if len(raw) > MAX_DOC_BYTES:
            raise ValueError("TAKEOVER_DOCUMENT_TOO_LARGE")
        text = raw.decode("utf-8-sig", errors="replace")
        rel = str(path.relative_to(root)).replace("\\", "/")
        return {
            "path": rel,
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "text": text[:max_chars],
            "truncated": len(text) > max_chars,
        }

    @staticmethod
    def _links(text: str) -> list[str]:
        return [
            match.group(1).strip()
            for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", text)
        ]

    @staticmethod
    def _stage_number(path: str) -> int:
        match = re.search(r"stage[ _-]?(\d+)", Path(path).name, re.I)
        return int(match.group(1)) if match else -1

    @staticmethod
    def _extract_next_actions(texts: list[str]) -> list[str]:
        actions = []
        for text in texts:
            active = False
            for raw in text.splitlines():
                line = raw.strip()
                if line.startswith("#"):
                    active = bool(re.search(r"下一步|验收缺口|next\s*action|pending|remaining|待验收", line, re.I))
                    continue
                if active and re.match(r"^(?:[-*]|\d+[.)])\s+", line):
                    actions.append(re.sub(r"^(?:[-*]|\d+[.)])\s+", "", line)[:700])
                    if len(actions) >= 8:
                        return actions
        return actions

    @staticmethod
    def _session_brief(session) -> dict:
        return {
            "session_id": session.session_id,
            "adapter": session.adapter,
            "adapter_version": session.adapter_version,
            "host_version": session.host_version,
            "project_file": session.project_file,
            "pid": session.pid,
        }

    def project_takeover(self, command: CommandEnvelope) -> ExecutionResult:
        try:
            workspace = self.service.workspaces.get(command.workspace)
            root = Path(workspace.root).resolve()
            entry_raw = str(command.arguments.get("entry_path") or "README.md")
            entry_path, reason = self._safe_doc(root, entry_raw)
            if entry_path is None or not entry_path.is_file():
                return self._failure(
                    command.command_id,
                    ExecutionStatus.FAILED,
                    reason or "TAKEOVER_ENTRY_NOT_FOUND",
                    entry_raw,
                )
            entry = self._read_doc(root, entry_path, 7000)
            links = []
            valid_candidates = []
            for raw_link in self._links(entry["text"]):
                link_text = str(raw_link or "").strip().replace("\\", "/")
                blocked = None
                resolved = None
                if not link_text or "\x00" in link_text or "://" in link_text:
                    blocked = "INVALID_OR_REMOTE_LINK"
                else:
                    link_path = link_text.split("#", 1)[0]
                    if not link_path:
                        blocked = "ANCHOR_ONLY"
                    elif Path(link_path).is_absolute() or re.match(r"^[A-Za-z]:", link_path):
                        blocked = "ABSOLUTE_LINK_DENIED"
                    else:
                        candidate = (entry_path.parent / link_path).resolve(strict=False)
                        if not candidate.is_relative_to(root):
                            blocked = "WORKSPACE_PATH_ESCAPE"
                        else:
                            workspace_relative = str(candidate.relative_to(root)).replace("\\", "/")
                            resolved, blocked = self._safe_doc(root, workspace_relative)
                row = {"link": raw_link, "blocked": bool(blocked)}
                if blocked:
                    row["reason"] = blocked
                elif resolved is not None and resolved.is_file():
                    rel = str(resolved.relative_to(root)).replace("\\", "/")
                    row["path"] = rel
                    valid_candidates.append((rel, resolved))
                links.append(row)

            # Also inspect sibling docs for the newest Stage/Handoff when README
            # does not link every relevant handoff explicitly.
            sibling = entry_path.parent
            if sibling.is_dir():
                for path in sibling.glob("*.md"):
                    rel = str(path.resolve().relative_to(root)).replace("\\", "/")
                    if rel == entry["path"]:
                        continue
                    if re.search(r"handoff|current[_ -]?state|stage\d+", path.name, re.I):
                        if all(existing[0] != rel for existing in valid_candidates):
                            valid_candidates.append((rel, path.resolve()))

            handoffs = [
                item for item in valid_candidates
                if re.search(r"handoff|current[_ -]?state", Path(item[0]).name, re.I)
            ]
            stages = [item for item in valid_candidates if self._stage_number(item[0]) >= 0]
            stages.sort(key=lambda item: self._stage_number(item[0]), reverse=True)
            non_stage = [
                item for item in valid_candidates
                if self._stage_number(item[0]) < 0 and item not in handoffs
            ]
            ordered = handoffs[:1] + stages[:1] + non_stage
            max_documents = max(0, min(6, int(command.arguments.get("max_documents") or 3)))
            documents = [self._read_doc(root, path, 6000) for _, path in ordered[:max_documents]]

            live_sessions = []
            for session in self.service.active_sessions():
                try:
                    project = Path(session.project_file).resolve(strict=False)
                    if project.is_relative_to(root):
                        live_sessions.append(self._session_brief(session))
                except Exception:
                    continue

            durable_resume = None
            project_key = str(command.arguments.get("project_key") or "").strip()
            if project_key:
                inner = CommandEnvelope(
                    command_id=self._inner_id(command.command_id),
                    workspace=command.workspace,
                    adapter="bridge_admin",
                    operation="bridge.project.resume",
                    arguments={"project": project_key, "history_limit": 30},
                    risk=RiskLevel.L1,
                )
                resumed = self.service.execute(inner)
                if resumed.status == ExecutionStatus.SUCCESS:
                    durable_resume = {
                        "project": (resumed.result.get("project") or {}).get("key"),
                        "safe_to_continue": (resumed.result.get("resume") or {}).get("safe_to_continue"),
                        "warnings": (resumed.result.get("resume") or {}).get("warnings") or [],
                        "evidence_id": resumed.evidence_id,
                    }
                else:
                    durable_resume = {
                        "status": resumed.status.value,
                        "failure": resumed.failure.model_dump(mode="json") if resumed.failure else None,
                    }

            texts = [entry["text"]] + [item["text"] for item in documents]
            status_lines = []
            for text in texts:
                for raw in text.splitlines():
                    line = raw.strip()
                    if re.search(r"^(?:状态|status|state)\s*[:：]|blocker|阻塞", line, re.I):
                        status_lines.append(line[:700])
                        if len(status_lines) >= 6:
                            break
                if len(status_lines) >= 6:
                    break

            return self._success(
                command.command_id,
                {
                    "mode": "takeover",
                    "mutation_performed": False,
                    "workspace": command.workspace,
                    "root": str(root),
                    "entry": entry,
                    "documents": documents,
                    "links": links,
                    "status_lines": status_lines,
                    "next_actions": self._extract_next_actions(texts),
                    "live_sessions": live_sessions,
                    "durable_resume": durable_resume,
                },
            )
        except Exception as exc:
            return self._failure(
                command.command_id,
                ExecutionStatus.FAILED,
                "PROJECT_TAKEOVER_FAILED",
                f"{type(exc).__name__}: {exc}",
            )

    @staticmethod
    def _context_assessment(used_tokens: int | None, context_window: int | None) -> dict:
        if used_tokens is None or context_window is None:
            return {"known": False, "level": "unknown", "handoff_recommended": False, "ratio": None}
        used=max(0,int(used_tokens)); window=max(1,int(context_window))
        ratio=used/window
        if ratio>=0.92: level="critical"
        elif ratio>=0.82: level="urgent"
        elif ratio>=0.70: level="recommended"
        else: level="continue"
        return {
            "known": True,
            "used_tokens": used,
            "context_window": window,
            "ratio": round(ratio,4),
            "level": level,
            "handoff_recommended": ratio>=0.70,
        }

    def _live_sessions_for_workspace(self, workspace_id: str) -> list[dict]:
        try:
            root=Path(self.service.workspaces.get(workspace_id).root).resolve()
        except Exception:
            return []
        rows=[]
        for session in self.service.active_sessions():
            try:
                if Path(session.project_file).resolve(strict=False).is_relative_to(root):
                    rows.append(self._session_brief(session))
            except Exception:
                continue
        return rows

    @staticmethod
    def _compact_takeover(payload: dict | None) -> dict | None:
        if not isinstance(payload,dict):
            return None
        entry=payload.get("entry") if isinstance(payload.get("entry"),dict) else {}
        docs=[]
        for item in payload.get("documents") or []:
            if isinstance(item,dict):
                docs.append({key:item.get(key) for key in ("path","sha256","bytes","truncated")})
        return {
            "workspace":payload.get("workspace"),
            "root":payload.get("root"),
            "entry":{key:entry.get(key) for key in ("path","sha256","bytes","truncated")},
            "documents":docs[:4],
            "status_lines":list(payload.get("status_lines") or [])[:6],
            "next_actions":list(payload.get("next_actions") or [])[:8],
            "live_sessions":list(payload.get("live_sessions") or [])[:8],
            "durable_resume":payload.get("durable_resume"),
            "mutation_performed":False,
        }

    def _recent_task_commands(self, workspace_id: str, limit: int) -> list[dict]:
        rows=self.service.db.list_command_summaries(
            workspace_id,
            limit=max(1,min(20,int(limit))),
            terminal_only=True,
        )
        return [{
            "command_id":item.get("command_id"),
            "adapter":item.get("adapter"),
            "operation":item.get("operation"),
            "status":item.get("status"),
            "evidence_id":item.get("evidence_id"),
            "updated_at":item.get("updated_at"),
        } for item in rows]

    @staticmethod
    def _bounded_snapshot(snapshot: dict) -> dict:
        def size(value): return len(json.dumps(value,ensure_ascii=False,separators=(",",":")).encode("utf-8"))
        if size(snapshot)<=HANDOFF_MAX_BYTES:
            return snapshot
        compact=dict(snapshot)
        takeover=compact.get("takeover")
        if isinstance(takeover,dict):
            takeover=dict(takeover)
            takeover["documents"]=(takeover.get("documents") or [])[:2]
            takeover["status_lines"]=(takeover.get("status_lines") or [])[:4]
            takeover["next_actions"]=(takeover.get("next_actions") or [])[:6]
            compact["takeover"]=takeover
        compact["recent_commands"]=(compact.get("recent_commands") or [])[:6]
        task=dict(compact.get("task") or {})
        for key in ("summary","objective"):
            if isinstance(task.get(key),str):
                task[key]=task[key][:2500]
        for key in ("decisions","blockers","next_actions","artifacts"):
            if isinstance(task.get(key),list):
                task[key]=task[key][:8]
        compact["task"]=task
        if size(compact)>HANDOFF_MAX_BYTES:
            compact["recent_commands"]=[]
            if isinstance(compact.get("takeover"),dict):
                compact["takeover"]["documents"]=[]
        if size(compact)>HANDOFF_MAX_BYTES:
            raise ValueError("HANDOFF_SNAPSHOT_TOO_LARGE")
        return compact

    def task_create(self, command: CommandEnvelope) -> ExecutionResult:
        args=command.arguments or {}
        task=self.service.db.create_hub_task(
            workspace_id=command.workspace,
            title=str(args.get("title") or "Current task"),
            objective=str(args.get("objective") or "Continue current work"),
            project_key=str(args.get("project_key") or "").strip() or None,
            entry_path=str(args.get("entry_path") or "").strip() or None,
        )
        return self._success(command.command_id,{"task":task})

    def task_checkpoint(self, command: CommandEnvelope) -> ExecutionResult:
        args=command.arguments or {}
        task_id=str(args.get("task_id") or "").strip()
        patch={key:args[key] for key in ("title","objective","project_key","entry_path","phase","state","summary","decisions","blockers","next_actions","artifacts") if key in args}
        task=self.service.db.checkpoint_hub_task(
            task_id,
            expected_generation=args.get("expected_generation"),
            patch=patch,
        )
        return self._success(command.command_id,{"task":task})

    def task_handoff_prepare(self, command: CommandEnvelope) -> ExecutionResult:
        args=command.arguments or {}
        task_id=str(args.get("task_id") or "").strip()
        task=self.service.db.get_hub_task(task_id)
        expected=args.get("expected_generation")
        if expected is not None and int(expected)!=int(task["generation"]):
            raise RuntimeError(f"TASK_GENERATION_CONFLICT: expected {expected}, current {task['generation']}")
        takeover=None
        include_durable_resume=bool(args.get("include_durable_resume",False))
        if bool(args.get("include_takeover",True)) and task.get("entry_path"):
            takeover_cmd=CommandEnvelope(
                command_id=self._inner_id(command.command_id),
                workspace=task["workspace_id"],
                adapter=ADAPTER_NAME,
                operation="project.takeover",
                arguments={
                    "entry_path":task["entry_path"],
                    "project_key":task.get("project_key") if include_durable_resume else "",
                    "max_documents":3,
                },
                risk=RiskLevel.L1,
            )
            takeover_result=self.project_takeover(takeover_cmd)
            if takeover_result.status==ExecutionStatus.SUCCESS:
                takeover=self._compact_takeover(takeover_result.result)
        recent_limit=max(0,min(20,int(args.get("recent_command_limit") or 10)))
        snapshot={
            "schema_version":"1.0",
            "task":{
                key:task.get(key) for key in (
                    "task_id","workspace_id","project_key","title","objective","entry_path",
                    "phase","state","generation","summary","decisions","blockers","next_actions","artifacts","updated_at"
                )
            },
            "context_assessment":self._context_assessment(args.get("used_tokens"),args.get("context_window")),
            "durable_resume_requested":include_durable_resume,
            "takeover":takeover,
            "live_sessions":self._live_sessions_for_workspace(task["workspace_id"]),
            "recent_commands":self._recent_task_commands(task["workspace_id"],recent_limit) if recent_limit else [],
            "mutation_performed":False,
        }
        snapshot=self._bounded_snapshot(snapshot)
        handoff=self.service.db.create_hub_handoff(task_id,generation=task["generation"],snapshot=snapshot)
        resume_prompt=(
            f"从 AI Bridge Work Hub 接手任务 task_id={task_id} handoff_id={handoff['handoff_id']}。"
            f"先调用 work_hub/task.resume，严格以返回 generation={task['generation']}、blockers 和 next_actions 为当前权威；"
            "不要重做已完成阶段，不要从旧聊天重新爬进度。"
        )
        return self._success(command.command_id,{
            "task":task,
            "handoff_id":handoff["handoff_id"],
            "snapshot_hash":handoff["snapshot_hash"],
            "snapshot":snapshot,
            "resume_prompt":resume_prompt,
        })

    def task_resume(self, command: CommandEnvelope) -> ExecutionResult:
        args=command.arguments or {}
        handoff_id=str(args.get("handoff_id") or "").strip()
        task_id=str(args.get("task_id") or "").strip()
        handoff=self.service.db.get_hub_handoff(handoff_id) if handoff_id else None
        if handoff is None:
            if not task_id:
                raise ValueError("task_id or handoff_id is required")
            handoff=self.service.db.latest_hub_handoff(task_id)
        if handoff is None:
            raise KeyError("HANDOFF_NOT_FOUND")
        task=self.service.db.get_hub_task(handoff["task_id"])
        return self._success(command.command_id,{
            "task":task,
            "handoff":handoff,
            "stale_handoff":int(task["generation"])!=int(handoff["generation"]),
            "live_sessions":self._live_sessions_for_workspace(task["workspace_id"]),
            "mutation_performed":False,
        })

    def execute(self, command: CommandEnvelope) -> ExecutionResult:
        try:
            op = command.operation
            args = command.arguments or {}
            if op == "capability.search":
                return self._success(
                    command.command_id,
                    self.capability_search(
                        str(args.get("query") or ""),
                        int(args.get("max_results") or 30),
                        command.workspace,
                    ),
                )
            if op == "capability.run":
                return self.capability_run(command)
            if op == "capability.batch":
                return self.capability_batch(command)
            if op == "project.takeover":
                return self.project_takeover(command)
            if op == "task.create":
                return self.task_create(command)
            if op == "task.list":
                return self._success(command.command_id,{"tasks":self.service.db.list_hub_tasks(
                    workspace_id=str(args.get("workspace_id") or command.workspace or "").strip() or None,
                    state=str(args.get("state") or "").strip() or None,
                    limit=int(args.get("limit") or 50),
                )})
            if op == "task.get":
                return self._success(command.command_id,{"task":self.service.db.get_hub_task(str(args.get("task_id") or ""))})
            if op == "task.checkpoint":
                return self.task_checkpoint(command)
            if op == "task.context.assess":
                return self._success(command.command_id,self._context_assessment(args.get("used_tokens"),args.get("context_window")))
            if op == "task.handoff.prepare":
                return self.task_handoff_prepare(command)
            if op == "task.resume":
                return self.task_resume(command)
            if op == "task.complete":
                task=self.service.db.complete_hub_task(
                    str(args.get("task_id") or ""),
                    expected_generation=args.get("expected_generation"),
                )
                return self._success(command.command_id,{"task":task})
            return self._failure(
                command.command_id,
                ExecutionStatus.DENIED,
                "CAPABILITY_NOT_SUPPORTED",
                op,
            )
        except RuntimeError as exc:
            if str(exc).startswith("TASK_GENERATION_CONFLICT"):
                return self._failure(command.command_id,ExecutionStatus.CONFLICT,"TASK_GENERATION_CONFLICT",str(exc))
            return self._failure(command.command_id,ExecutionStatus.FAILED,"WORK_HUB_RUNTIME_ERROR",str(exc))
        except KeyError as exc:
            return self._failure(command.command_id,ExecutionStatus.FAILED,str(exc).strip("'"))
        except ValueError as exc:
            return self._failure(
                command.command_id,
                ExecutionStatus.DENIED,
                str(exc) or "HUB_ARGUMENT_INVALID",
            )
        except Exception as exc:
            return self._failure(
                command.command_id,
                ExecutionStatus.FAILED,
                "WORK_HUB_FAILED",
                f"{type(exc).__name__}: {exc}",
            )


def descriptor() -> AdapterDescriptor:
    return AdapterDescriptor(
        adapter=ADAPTER_NAME,
        adapter_version="0.1.0",
        endpoint="local://work-hub",
        capabilities=[
            CapabilityDescriptor(name="capability.search", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
            CapabilityDescriptor(name="capability.run", version="1.0", write=True, host_mutation=False, risk=RiskLevel.L2, manages_checkpoint=True),
            CapabilityDescriptor(name="capability.batch", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
            CapabilityDescriptor(name="project.takeover", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
            CapabilityDescriptor(name="task.create", version="1.0", write=True, host_mutation=False, risk=RiskLevel.L1),
            CapabilityDescriptor(name="task.list", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
            CapabilityDescriptor(name="task.get", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
            CapabilityDescriptor(name="task.checkpoint", version="1.0", write=True, host_mutation=False, risk=RiskLevel.L1),
            CapabilityDescriptor(name="task.context.assess", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
            CapabilityDescriptor(name="task.handoff.prepare", version="1.0", write=True, host_mutation=False, risk=RiskLevel.L1),
            CapabilityDescriptor(name="task.resume", version="1.0", write=False, host_mutation=False, risk=RiskLevel.L1),
            CapabilityDescriptor(name="task.complete", version="1.0", write=True, host_mutation=False, risk=RiskLevel.L1),
        ],
    )
