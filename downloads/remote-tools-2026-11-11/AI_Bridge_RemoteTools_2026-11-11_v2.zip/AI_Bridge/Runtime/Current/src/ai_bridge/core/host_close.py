"""Normal window close using the Host identity captured for this command."""
import ctypes
import os
from ctypes import wintypes


def _kernel():
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
    kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    kernel.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
    return kernel


def _creation(kernel,handle):
    times=[wintypes.FILETIME() for _ in range(4)]
    if not kernel.GetProcessTimes(handle,*[ctypes.byref(t) for t in times]):
        raise ctypes.WinError(ctypes.get_last_error())
    return (times[0].dwHighDateTime<<32)|times[0].dwLowDateTime


def bind(session):
    if os.name!='nt': return None
    kernel=_kernel(); handle=kernel.OpenProcess(0x1000,False,session.pid)
    if not handle: return None
    try:
        return {'pid':session.pid,'created_ticks':_creation(kernel,handle),'session_id':session.session_id,
                'project_file':session.project_file,'adapter':session.adapter}
    finally: kernel.CloseHandle(handle)


def close(target):
    if not target or os.name!='nt':
        return {'requested':False,'reason':'NO_BOUND_HOST_IDENTITY'}
    kernel=_kernel(); handle=kernel.OpenProcess(0x1000,False,target['pid'])
    if not handle: return {'requested':False,'reason':'HOST_ALREADY_EXITED_OR_UNAVAILABLE'}
    try:
        if _creation(kernel,handle)!=target['created_ticks']:
            return {'requested':False,'reason':'HOST_PROCESS_IDENTITY_CHANGED'}
        user=ctypes.WinDLL('user32',use_last_error=True)
        callback_type=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
        user.EnumWindows.argtypes=[callback_type,wintypes.LPARAM]
        user.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
        user.PostMessageW.argtypes=[wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM]
        user.IsWindowVisible.argtypes=[wintypes.HWND]
        sent=[]
        @callback_type
        def visit(window,_):
            pid=wintypes.DWORD()
            user.GetWindowThreadProcessId(window,ctypes.byref(pid))
            if pid.value==target['pid'] and user.IsWindowVisible(window):
                if user.PostMessageW(window,0x0010,0,0): sent.append(int(window))
            return True
        user.EnumWindows(visit,0)
        return {'requested':bool(sent),'reason':'NORMAL_CLOSE_REQUESTED' if sent else 'NO_VISIBLE_HOST_WINDOW',
                'session_id':target['session_id'],'project_file':target['project_file'],
                'force_used':False,'completion':'pending; unsaved-work dialogs may require the user'}
    finally: kernel.CloseHandle(handle)


def cancel_command(service, command_id, close_host=False):
    from ai_bridge.core.owned_process import cancel
    row=service.db.get_command(command_id)
    if row is None: raise KeyError('COMMAND_NOT_FOUND')
    result=cancel(command_id)
    if close_host:
        target=None
        # The binding was written before dispatch; never select another live Host.
        with service.db._connect() as conn:
            import json
            event=conn.execute("SELECT detail_json FROM command_events WHERE command_id=? AND event='host_bound' ORDER BY seq DESC LIMIT 1",(command_id,)).fetchone()
            if event: target=json.loads(event['detail_json'])
        service.db.record_event(command_id,'host_close_requested',{'bound_host_available':bool(target)})
        result['host_close']=close(target)
        service.db.record_event(command_id,'host_close_response',result['host_close'])
    return result
