"""Asynchronous local submission using the existing durable command identity."""
from threading import Lock, Thread
from ai_bridge.core.service import DuplicateCommandError
from ai_bridge.protocol.result import ExecutionResult, ExecutionStatus, FailureInfo, FailureOrigin


class LocalJobs:
    def __init__(self, service):
        self.service = service
        self.lock = Lock()

    def submit(self, command):
        with self.lock:
            prior = self.service.db.get_command(command.command_id)
            row = self.service.db.accept_transport_command(command)
            if prior is None:
                self.service.db.record_event(command.command_id, 'queued', {'source': 'local_async'})
                Thread(target=self._run, args=(command,), name='BridgeJob-' + command.command_id, daemon=True).start()
        return {'command_id': command.command_id, 'status': row['status'], 'reused': prior is not None,
                'status_url': '/client/jobs/' + command.command_id,
                'note': 'Query this command_id; absence of output is not failure. Accepted jobs are not automatically replayed after a Runtime restart.'}

    def _run(self, command):
        try:
            self.service.execute(command)
        except DuplicateCommandError:
            return
        except Exception as exc:
            result = ExecutionResult(command_id=command.command_id, status=ExecutionStatus.UNKNOWN,
                failure=FailureInfo(origin=FailureOrigin.CORE, code='ASYNC_EXECUTION_INTERRUPTED', message=str(exc)))
            self.service.db.record_event(command.command_id, 'execution_interrupted', {'error_type': type(exc).__name__})
            self.service.db.save_result(result)
