"""An explicit Windows Job owns exactly the process tree started for a command."""
import ctypes
import os
from threading import RLock

_lock = RLock()
_tasks = {}
launch_lock = RLock()


class OwnedProcessBusy(RuntimeError):
    pass


def check_available(key):
    with _lock:
        for command_id, task in _tasks.items():
            if task.get('key') == key:
                raise OwnedProcessBusy('Original command still owns this process tree: '+command_id)


class WindowsJob:
    def __init__(self):
        from ctypes import wintypes
        self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        self.kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        self.kernel.CreateJobObjectW.restype = wintypes.HANDLE
        self.kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        self.kernel.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
        self.kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel.QueryInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p]
        self.handle = self.kernel.CreateJobObjectW(None, None)
        if not self.handle: raise ctypes.WinError(ctypes.get_last_error())

    def assign_and_resume(self, process):
        if not self.kernel.AssignProcessToJobObject(self.handle, int(process._handle)):
            process.kill()
            process.wait()
            raise ctypes.WinError(ctypes.get_last_error())
        native = ctypes.WinDLL('ntdll')
        native.NtResumeProcess.argtypes = [ctypes.c_void_p]
        native.NtResumeProcess.restype = ctypes.c_long
        if native.NtResumeProcess(int(process._handle)) != 0:
            self.terminate()
            raise RuntimeError('OWNED_PROCESS_RESUME_FAILED')

    def terminate(self):
        if not self.kernel.TerminateJobObject(self.handle, 1):
            raise ctypes.WinError(ctypes.get_last_error())

    def active_count(self):
        # JOBOBJECT_BASIC_ACCOUNTING_INFORMATION has four LARGE_INTEGERs,
        # then four DWORDs. ActiveProcesses is the third DWORD.
        buffer = ctypes.create_string_buffer(48)
        if not self.kernel.QueryInformationJobObject(self.handle, 1, buffer, 48, None):
            raise ctypes.WinError(ctypes.get_last_error())
        return ctypes.c_uint32.from_buffer(buffer, 40).value

    def close(self):
        if self.handle:
            self.kernel.CloseHandle(self.handle)
            self.handle = None


def register(command_id, process, job, record, key=None):
    with _lock:
        _tasks[command_id] = {'process': process, 'job': job, 'record': record, 'key': key, 'cancel_requested': False}


def cancel(command_id):
    with _lock:
        task = _tasks.get(command_id)
        if task is None:
            return {'accepted': False, 'reason': 'NO_OWNED_RUNNING_PROCESS', 'command_id': command_id}
        if task['cancel_requested']:
            return {'accepted': True, 'command_id': command_id, 'state': 'cancel_requested'}
        if task['job'] is None:
            return {'accepted': False, 'reason': 'PROCESS_TREE_CANCELLATION_UNSUPPORTED_ON_THIS_PLATFORM', 'command_id': command_id}
        task['record'](command_id, 'cancel_requested', {'scope': 'owned_process_tree'})
        task['job'].terminate()
        task['cancel_requested'] = True
        return {'accepted': True, 'command_id': command_id, 'state': 'cancel_requested', 'scope': 'owned_process_tree'}


def finish(command_id):
    with _lock:
        task = _tasks.pop(command_id, None)
        if task and task['job']:
            task['job'].close()
        return bool(task and task['cancel_requested'])


def status(command_id):
    with _lock:
        task = _tasks.get(command_id)
        return {'cancel_supported': bool(task and task['job']),
                'process_running_now': (task['job'].active_count()>0 if task['job'] else task['process'].poll() is None) if task else None,
                'ownership_available': task is not None,
                'cancel_requested': bool(task and task['cancel_requested'])}
