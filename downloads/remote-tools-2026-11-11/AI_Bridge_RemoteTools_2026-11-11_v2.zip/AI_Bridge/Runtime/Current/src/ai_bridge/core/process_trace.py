"""Stream declared commands without buffering all output until process exit."""
import os
import subprocess
import time
from pathlib import Path
from queue import Queue, Empty
from threading import Thread
from ai_bridge.persistence.command_trace import redact_text
from ai_bridge.core import owned_process


def run_process(argv, *, cwd, env, timeout, command_id, log_root, record):
    root = Path(log_root)
    root.mkdir(parents=True, exist_ok=True)
    import hashlib
    log = root / (hashlib.sha256(command_id.encode()).hexdigest() + '.log')
    output = Queue()
    job = owned_process.WindowsJob() if os.name == 'nt' else None
    flags = {'creationflags': subprocess.CREATE_NO_WINDOW | 0x00000004} if job else {}
    key = (os.path.normcase(os.path.abspath(cwd)), tuple(argv))
    with owned_process.launch_lock:
        try:
            owned_process.check_available(key)
            process = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace',
                bufsize=1, shell=False, **flags)
            if job:
                job.assign_and_resume(process)
            owned_process.register(command_id, process, job, record, key)
        except BaseException:
            if job: job.close()
            raise
    def reader():
        try:
            for line in process.stdout:
                output.put(line)
        finally:
            output.put(None)
    Thread(target=reader, daemon=True).start()
    start = time.monotonic()
    last_event = start
    last_output = None
    tail = ''
    eof = False
    timed_out = False
    def running():
        return job.active_count()>0 if job else process.poll() is None
    record(command_id, 'process_started', {'pid': process.pid, 'log_path': str(log)})
    with log.open('w', encoding='utf-8', buffering=1) as stream:
        while not eof or running():
            now = time.monotonic()
            if now - start >= timeout and running():
                timed_out = True
                # Stop waiting, preserve the process and its reader/output log.
                record(command_id, 'process_budget_exceeded', {'pid': process.pid, 'process_running': True, 'elapsed_seconds': round(now-start, 2), 'log_path': str(log)})
                def drain_remaining():
                    with log.open('a', encoding='utf-8', buffering=1) as remainder:
                        while True:
                            line = output.get()
                            if line is None: break
                            remainder.write(redact_text(line))
                    code = process.wait()
                    while running(): time.sleep(.2)
                    canceled = owned_process.finish(command_id)
                    record(command_id, 'process_exited_after_budget', {'pid': process.pid, 'exit_code': code, 'cancelled': canceled, 'log_path': str(log)})
                Thread(target=drain_remaining, daemon=True).start()
                break
            try:
                line = output.get(timeout=0.2)
                if line is None:
                    eof = True
                else:
                    text = redact_text(line)
                    stream.write(text)
                    tail = (tail + text)[-20000:]
                    last_output = time.monotonic()
            except Empty:
                pass
            now = time.monotonic()
            if now - last_event >= 3:
                record(command_id, 'process_progress', {'pid': process.pid, 'process_running': running(),
                    'elapsed_seconds': round(now-start, 2), 'output_idle_seconds': round(now-(last_output or start), 2),
                    'recent_output': tail[-3000:] if last_output and last_output > last_event else '', 'log_path': str(log)})
                last_event = now
    if not timed_out:
        code = process.wait()
        canceled = owned_process.finish(command_id)
        record(command_id, 'process_exited', {'pid': process.pid, 'exit_code': code, 'cancelled': canceled, 'elapsed_seconds': round(time.monotonic()-start, 2), 'recent_output': tail[-3000:], 'log_path': str(log)})
    else:
        code = None
        canceled = False
    return {'exit_code': code, 'stdout': tail, 'stderr': '', 'log_path': str(log),
            'pid': process.pid, 'timed_out': timed_out, 'cancelled': canceled, 'process_running': True if timed_out else False}
