from __future__ import annotations

import os
import subprocess
import hashlib
import json
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from threading import RLock, Thread

from ai_bridge.core.worker_manifest import ServiceSpec, load_project_manifest


class WorkerError(RuntimeError):
    code = "WORKER_ERROR"


class WorkerAlreadyRunning(WorkerError):
    code = "SERVICE_ALREADY_RUNNING"


class WorkerNotRunning(WorkerError):
    code = "SERVICE_NOT_RUNNING"


class WorkerReloadManual(WorkerError):
    code = "SERVICE_RELOAD_MANUAL"



def _pid_identity(pid: int) -> str | None:
    """A PID plus creation time prevents adopting a reused process identifier."""
    if os.name != "nt":
        try:
            return Path(f"/proc/{int(pid)}/stat").read_text().rsplit(") ", 1)[1].split()[19]
        except FileNotFoundError:
            return None
    import ctypes
    from ctypes import wintypes
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    api.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    api.OpenProcess.restype = wintypes.HANDLE
    api.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    api.WaitForSingleObject.restype = wintypes.DWORD
    api.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    api.GetProcessTimes.restype = wintypes.BOOL
    api.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = api.OpenProcess(0x100000 | 0x1000, False, int(pid))
    if not handle:
        error = ctypes.get_last_error()
        if error in (87, 1168):
            return None
        raise OSError(error, "process identity unavailable")
    try:
        result = api.WaitForSingleObject(handle, 0)
        if result == 0:
            return None
        if result != 0x102:
            raise OSError("process identity wait failed")
        created, exited, kernel, user = (wintypes.FILETIME() for _ in range(4))
        if not api.GetProcessTimes(handle, *(ctypes.byref(v) for v in (created, exited, kernel, user))):
            raise OSError("process creation time unavailable")
        return str((created.dwHighDateTime << 32) | created.dwLowDateTime)
    finally:
        api.CloseHandle(handle)



@dataclass
class _WorkerRecord:
    workspace_id: str
    service_name: str
    process: subprocess.Popen
    spec: ServiceSpec
    root: Path
    logs: deque[str]
    log_thread: Thread | None = None
    lock: RLock = field(default_factory=RLock)
    stopped: bool = False


class WorkerSupervisor:
    def __init__(self, *, max_log_lines: int = 1000, state_path: Path | None = None) -> None:
        self.max_log_lines = max(16, min(int(max_log_lines), 10000))
        self._items: dict[tuple[str, str], _WorkerRecord] = {}
        self._lock = RLock()
        self.state_path = Path(state_path) if state_path is not None else None
        self._intents = {}
        self._restore_errors = {}
        self._restore_attempted = False
        self._state_error = None
        self._load_intents()


    @staticmethod
    def _restore_enabled(spec: ServiceSpec) -> bool:
        return spec.env.get("AI_BRIDGE_RESTORE_ON_RUNTIME_RESTART") == "1"

    @staticmethod
    def _spec_hash(spec: ServiceSpec) -> str:
        raw = json.dumps(spec.model_dump(mode="json"), sort_keys=True, separators=(",", ":")).encode()
        return hashlib.sha256(raw).hexdigest()

    def _load_intents(self) -> None:
        if self.state_path is None or not self.state_path.exists():
            return
        try:
            if self.state_path.stat().st_size > 262144:
                raise ValueError("state too large")
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            rows = data["services"]
            if data.get("version") != 1 or not isinstance(rows, list) or len(rows) > 128:
                raise ValueError("state schema")
            loaded = {}
            for row in rows:
                if not isinstance(row, dict):
                    raise ValueError("state row")
                if set(row) - {"workspace","service","root","spec_hash","pid","identity","pending","last_error"}:
                    raise ValueError("unknown state field")
                if not all(isinstance(row.get(k), str) and 0 < len(row[k]) <= cap for k, cap in (("workspace",128),("service",128),("root",4096),("spec_hash",64))):
                    raise ValueError("state fields")
                if len(row["spec_hash"]) != 64 or any(c not in "0123456789abcdef" for c in row["spec_hash"]):
                    raise ValueError("state hash")
                if row.get("pid") is not None and (type(row["pid"]) is not int or row["pid"] <= 0):
                    raise ValueError("state pid")
                if row.get("identity") is not None and (not isinstance(row["identity"],str) or not row["identity"].isdigit() or len(row["identity"])>32):
                    raise ValueError("state identity")
                if type(row.get("pending",False)) is not bool:
                    raise ValueError("state pending")
                if row.get("last_error") is not None and (not isinstance(row["last_error"],str) or len(row["last_error"])>160):
                    raise ValueError("state error")
                key=(row["workspace"],row["service"])
                if key in loaded:
                    raise ValueError("duplicate state")
                loaded[key]=dict(row)
            self._intents=loaded
        except Exception as error:
            self._state_error="WORKER_STATE_INVALID:"+type(error).__name__

    def _set_intent(self, key, row) -> None:
        if self.state_path is None:
            return
        if self._state_error:
            raise WorkerError(self._state_error)
        previous=dict(self._intents)
        if row is not None and key not in self._intents and len(self._intents) >= 128:
            raise WorkerError("WORKER_INTENT_LIMIT")
        if row is None:
            self._intents.pop(key,None)
        else:
            self._intents[key]=dict(row)
        try:
            self.state_path.parent.mkdir(parents=True,exist_ok=True)
            temporary=self.state_path.with_suffix(self.state_path.suffix+".tmp")
            payload=json.dumps({"version":1,"services":list(self._intents.values())},ensure_ascii=False,indent=2)+"\n"
            for attempt in range(4):
                try:
                    temporary.write_text(payload,encoding="utf-8")
                    temporary.replace(self.state_path)
                    break
                except PermissionError:
                    if attempt == 3:
                        raise
                    time.sleep(0.01 * (attempt + 1))
        except Exception:
            self._intents=previous
            raise

    def _intent_for(self, workspace_id, root, service_name, spec, *, pending=False):
        return {"workspace":str(workspace_id),"service":str(service_name),"root":str(Path(root).resolve()),"spec_hash":self._spec_hash(spec),"pid":None,"identity":None,"pending":pending,"last_error":None}

    def _restore_error(self, key, code) -> None:
        code=str(code)[:160]
        self._restore_errors[key]=code
        if key in self._intents:
            row={**self._intents[key],"last_error":code}
            try:
                self._set_intent(key,row)
            except Exception:
                pass

    def restore(self, workspaces) -> list[dict]:
        """One bounded startup pass. Never infer intent from logs or retry in a loop."""
        with self._lock:
            if self._restore_attempted:
                return []
            self._restore_attempted=True
            reports=[]
            if self._state_error:
                return [{"state":"failed","error":self._state_error}]
            for key,row in list(self._intents.items()):
                try:
                    workspace=workspaces.get(key[0])
                    if str(workspace.root.resolve()) != row["root"]:
                        raise WorkerError("WORKSPACE_ROOT_CHANGED")
                    spec=load_project_manifest(workspace.root).services.get(key[1])
                    if spec is None or not self._restore_enabled(spec):
                        raise WorkerError("SERVICE_RESTORE_NOT_ENABLED")
                    if self._spec_hash(spec) != row["spec_hash"]:
                        raise WorkerError("SERVICE_SPEC_CHANGED")
                    self._resolve_cwd(workspace.root,spec.cwd)
                    if row.get("pending") and row.get("pid") is None:
                        raise WorkerError("INCOMPLETE_START_REQUIRES_REVIEW")
                    current=_pid_identity(row["pid"]) if row.get("pid") else None
                    if current is not None and current == row.get("identity"):
                        raise WorkerError("SERVICE_STILL_RUNNING_RESTORE_BLOCKED")
                    elif current is not None and row.get("identity") is None:
                        raise WorkerError("PROCESS_IDENTITY_UNVERIFIED")
                    else:
                        self.start(key[0],workspace.root,key[1],spec)
                    reports.append(self.status(*key))
                except Exception as error:
                    code=str(error) if isinstance(error,WorkerError) else type(error).__name__
                    self._restore_error(key,code)
                    reports.append(self.status(*key))
            return reports

    @staticmethod
    def _resolve_cwd(root: Path, relative: str) -> Path:
        root = Path(root).expanduser().resolve()
        candidate = (root / relative).resolve(strict=False)
        try:
            candidate.relative_to(root)
        except ValueError as exc:
            raise ValueError("WORKSPACE_PATH_ESCAPE") from exc
        if not candidate.exists():
            raise FileNotFoundError(f"service cwd does not exist: {candidate}")
        if not candidate.is_dir():
            raise NotADirectoryError(str(candidate))
        return candidate

    @staticmethod
    def _reader(record: _WorkerRecord) -> None:
        stream = record.process.stdout
        if stream is None:
            return
        try:
            for line in iter(stream.readline, ""):
                if not line:
                    break
                with record.lock:
                    record.logs.append(line.rstrip("\r\n"))
        finally:
            try:
                stream.close()
            except Exception:
                pass

    @staticmethod
    def _snapshot(record: _WorkerRecord) -> dict:
        exit_code = record.process.poll()
        if exit_code is None:
            state = "running"
        elif record.stopped:
            state = "stopped"
        else:
            state = "exited"
        return {
            "workspace": record.workspace_id,
            "service": record.service_name,
            "state": state,
            "pid": int(record.process.pid),
            "exit_code": exit_code,
            "reload": record.spec.reload,
        }

    @staticmethod
    def _windows_taskkill(pid: int, *, force: bool) -> bool:
        argv = ["taskkill", "/PID", str(int(pid)), "/T"]
        if force:
            argv.append("/F")
        try:
            run = subprocess.run(
                argv,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return False
        return run.returncode == 0

    def start(
        self,
        workspace_id: str,
        workspace_root: Path,
        service_name: str,
        spec: ServiceSpec,
    ) -> dict:
        key = (str(workspace_id), str(service_name))
        with self._lock:
            existing = self._items.get(key)
            if existing is not None and existing.process.poll() is None:
                raise WorkerAlreadyRunning(service_name)

            old = self._intents.get(key)
            if old and old.get("pid"):
                alive = _pid_identity(old["pid"])
                if alive is not None and (alive == old.get("identity") or old.get("identity") is None):
                    raise WorkerAlreadyRunning(service_name)
            cwd = self._resolve_cwd(Path(workspace_root), spec.cwd)
            if self._restore_enabled(spec) and self.state_path is not None:
                self._set_intent(key,self._intent_for(workspace_id,workspace_root,service_name,spec,pending=True))
            elif key in self._intents:
                self._set_intent(key,None)
            env = dict(os.environ)
            env.update(spec.env)
            try:
                process = subprocess.Popen(
                list(spec.argv),
                cwd=str(cwd),
                env=env,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                shell=False,
                )
            except Exception as error:
                if key in self._intents:
                    self._set_intent(key,{**self._intents[key],"pending":False,"last_error":type(error).__name__})
                    self._restore_errors[key]=type(error).__name__
                raise
            if key in self._intents:
                try:
                    identity=_pid_identity(process.pid)
                    if identity is None and process.poll() is None:
                        raise WorkerError("PROCESS_IDENTITY_UNVERIFIED")
                    self._set_intent(key,{**self._intents[key],"pid":process.pid,"identity":identity,"pending":False,"last_error":None})
                except Exception as error:
                    self._restore_error(key,type(error).__name__)
                    if os.name == "nt":
                        self._windows_taskkill(process.pid,force=True)
                    else:
                        process.kill()
                    process.wait(timeout=5)
                    raise
            self._restore_errors.pop(key,None)
            record = _WorkerRecord(
                workspace_id=str(workspace_id),
                service_name=str(service_name),
                process=process,
                spec=spec,
                root=Path(workspace_root).resolve(),
                logs=deque(maxlen=self.max_log_lines),
            )
            thread = Thread(
                target=self._reader,
                args=(record,),
                name=f"ai-bridge-worker-log-{service_name}",
                daemon=True,
            )
            record.log_thread = thread
            self._items[key] = record
            thread.start()
            return self._snapshot(record)

    def status(self, workspace_id: str, service_name: str) -> dict:
        key = (str(workspace_id), str(service_name))
        with self._lock:
            record = self._items.get(key)
            if record is None and self._state_error:
                return {"workspace":str(workspace_id),"service":str(service_name),"state":"failed","pid":None,"exit_code":None,"recovery_error":self._state_error}
            if (key in self._restore_errors or (key in self._intents and self._intents[key].get("last_error"))) and (record is None or record.process.poll() is not None):
                return {"workspace":str(workspace_id),"service":str(service_name),"state":"failed","pid":None,"exit_code":None,"desired_running":key in self._intents,"recovery_error":self._restore_errors.get(key) or self._intents[key]["last_error"]}
            if record is None:
                return {
                    "workspace": str(workspace_id),
                    "service": str(service_name),
                    "state": "stopped",
                    "pid": None,
                    "exit_code": None,
                }
            return self._snapshot(record)

    def logs(self, workspace_id: str, service_name: str, *, tail: int = 200) -> dict:
        key = (str(workspace_id), str(service_name))
        with self._lock:
            record = self._items.get(key)
            if record is None:
                lines: list[str] = []
                status = self.status(workspace_id, service_name)
            else:
                tail = max(1, min(int(tail), self.max_log_lines))
                with record.lock:
                    lines = list(record.logs)[-tail:]
                status = self.status(workspace_id, service_name)
        return {**status, "lines": lines}

    def stop(self, workspace_id: str, service_name: str, *, _preserve_intent: bool = False) -> dict:
        key = (str(workspace_id), str(service_name))
        with self._lock:
            record = self._items.get(key)
            tracked = key in self._intents or key in self._restore_errors
            previous=self._intents.get(key)
            blocked=None
            if record is None and previous:
                if previous.get("pid"):
                    try:
                        current=_pid_identity(previous["pid"])
                        if current is not None and (current == previous.get("identity") or previous.get("identity") is None):
                            blocked="LIVE_PROCESS_NOT_STOPPED_MANUAL_ACTION_REQUIRED"
                    except Exception:
                        blocked="PROCESS_IDENTITY_UNVERIFIED_MANUAL_ACTION_REQUIRED"
                elif previous.get("pending"):
                    blocked="INCOMPLETE_START_MANUAL_ACTION_REQUIRED"
            if not _preserve_intent and key in self._intents:
                self._set_intent(key,None)
            if not _preserve_intent:
                self._restore_errors.pop(key,None)
            if blocked:
                self._restore_errors[key]=blocked
                raise WorkerError(blocked)
            if record is None or record.process.poll() is not None:
                if tracked and not _preserve_intent:
                    if record is not None:
                        record.stopped=True
                    return self.status(workspace_id,service_name)
                raise WorkerNotRunning(service_name)

        process = record.process
        if os.name == "nt":
            if not self._windows_taskkill(process.pid, force=False):
                process.terminate()
        else:
            process.terminate()
        try:
            process.wait(timeout=float(record.spec.stop_timeout_seconds))
        except subprocess.TimeoutExpired:
            if os.name == "nt":
                if not self._windows_taskkill(process.pid, force=True):
                    process.kill()
            else:
                process.kill()
            process.wait(timeout=max(1.0, float(record.spec.stop_timeout_seconds)))
        with record.lock:
            record.stopped = True

        return self._snapshot(record)

    def restart(
        self,
        workspace_id: str,
        workspace_root: Path,
        service_name: str,
        spec: ServiceSpec,
    ) -> dict:
        key=(str(workspace_id),str(service_name))
        with self._lock:
            if self._restore_enabled(spec) and self.state_path is not None and key not in self._intents:
                record=self._items.get(key)
                row=self._intent_for(workspace_id,workspace_root,service_name,spec)
                if record is not None and record.process.poll() is None:
                    row.update(pid=record.process.pid,identity=_pid_identity(record.process.pid))
                self._set_intent(key,row)
        current = self.status(workspace_id, service_name)
        if current["state"] == "running":
            self.stop(workspace_id, service_name, _preserve_intent=True)
        return self.start(workspace_id, workspace_root, service_name, spec)

    def reload(
        self,
        workspace_id: str,
        workspace_root: Path,
        service_name: str,
        spec: ServiceSpec,
    ) -> dict:
        if spec.reload == "manual":
            raise WorkerReloadManual(service_name)
        if spec.reload == "native":
            status = self.status(workspace_id, service_name)
            if status["state"] != "running":
                raise WorkerNotRunning(service_name)
            return {**status, "action": "native"}
        restarted = self.restart(workspace_id, workspace_root, service_name, spec)
        return {**restarted, "action": "restart"}

    def close(self) -> None:
        with self._lock:
            keys = list(self._items)
        for workspace_id, service_name in keys:
            try:
                if self.status(workspace_id, service_name)["state"] == "running":
                    self.stop(workspace_id, service_name, _preserve_intent=True)
            except Exception:
                pass
