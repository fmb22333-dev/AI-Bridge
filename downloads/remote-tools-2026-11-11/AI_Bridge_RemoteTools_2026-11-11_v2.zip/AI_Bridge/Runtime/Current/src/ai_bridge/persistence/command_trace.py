"""Small append-only lifecycle records; full process output lives in files."""
import json
import re
from datetime import datetime, timezone


def redact_text(value):
    value = re.sub(r'(?i)Bearer\s+\S+', 'Bearer [REDACTED]', value)
    return re.sub(r'(?i)(api[_-]?key|access[_-]?token|password|client[_-]?secret)(["\s:=]+)[^\s,;]+', r'\1\2[REDACTED]', value)


def clean(value):
    if isinstance(value, dict):
        return {str(k): ('[REDACTED]' if re.search(r'token|secret|password|authorization', str(k), re.I) else clean(v)) for k, v in value.items()}
    if isinstance(value, list):
        return [clean(v) for v in value[:64]]
    if isinstance(value, str):
        value = redact_text(value)
        return value[-6000:]
    return value


def install(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS command_events (
        seq INTEGER PRIMARY KEY AUTOINCREMENT,
        command_id TEXT NOT NULL, event TEXT NOT NULL,
        recorded_at TEXT NOT NULL, detail_json TEXT NOT NULL)''')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_command_events_cursor ON command_events(command_id,seq)')


def append(conn, command_id, event, detail=None):
    conn.execute('INSERT INTO command_events(command_id,event,recorded_at,detail_json) VALUES (?,?,?,?)',
                 (command_id, event, datetime.now(timezone.utc).isoformat(), json.dumps(clean(detail or {}), ensure_ascii=False)))


def read(conn, command_id, after=0, limit=100):
    limit = max(1, min(int(limit), 200))
    rows = conn.execute('SELECT * FROM command_events WHERE command_id=? AND seq>? ORDER BY seq LIMIT ?',
                        (command_id, max(0, int(after)), limit + 1)).fetchall()
    events = [dict(row) for row in rows[:limit]]
    for event in events:
        event['detail'] = json.loads(event.pop('detail_json'))
    return {'events': events, 'next_cursor': events[-1]['seq'] if events else max(0, int(after)),
            'has_more': len(rows) > limit, 'historical_trace_available': bool(events) or bool(conn.execute('SELECT 1 FROM command_events WHERE command_id=? LIMIT 1', (command_id,)).fetchone())}
