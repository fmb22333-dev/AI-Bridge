import hashlib
import json
import sqlite3
import uuid
from pathlib import Path
from threading import RLock
from typing import Any
from . import command_trace


class CommandIdentityConflict(RuntimeError):
    pass


class BridgeDB:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=10000")
        conn.execute("PRAGMA synchronous=FULL")
        return conn

    @staticmethod
    def _encode_command(command) -> str:
        payload = command.model_dump(mode="json")
        return json.dumps(payload, ensure_ascii=False, sort_keys=True)

    @staticmethod
    def _decode_command_row(row: sqlite3.Row) -> dict[str, Any]:
        data = dict(row)
        if data.get("request_json"):
            data["request"] = json.loads(data.pop("request_json"))
        if data.get("result_json"):
            data["result"] = json.loads(data.pop("result_json"))
        else:
            data.pop("result_json", None)
        return data

    def _init_schema(self) -> None:
        # WAL is persistent at the database level and lets readers proceed
        # while a writer transaction is active. Bridge previously inherited
        # SQLite's DELETE journal, which degraded into multi-second lock waits
        # as the command database grew under multi-lane execution.
        with sqlite3.connect(self.path, timeout=10) as bootstrap:
            bootstrap.execute("PRAGMA busy_timeout=10000")
            mode = str(bootstrap.execute("PRAGMA journal_mode=WAL").fetchone()[0]).lower()
            if mode != "wal":
                raise RuntimeError(f"SQLITE_WAL_REQUIRED: got {mode}")
            bootstrap.execute("PRAGMA synchronous=FULL")
        with self._connect() as conn:
            command_trace.install(conn)
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS commands (
                    command_id TEXT PRIMARY KEY,
                    workspace_id TEXT NOT NULL,
                    adapter TEXT NOT NULL,
                    session_id TEXT,
                    operation TEXT NOT NULL,
                    request_json TEXT NOT NULL,
                    result_json TEXT,
                    status TEXT NOT NULL,
                    evidence_id TEXT,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS transport_publications (
                    transport_key TEXT NOT NULL,
                    command_id TEXT NOT NULL,
                    published_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (transport_key, command_id)
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS transport_ingress_receipts (
                    transport_key TEXT NOT NULL,
                    receipt_id TEXT NOT NULL,
                    command_id TEXT NOT NULL,
                    ingress_kind TEXT NOT NULL,
                    routing_json TEXT NOT NULL,
                    observed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    published_at TEXT,
                    PRIMARY KEY (transport_key, receipt_id)
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_transport_ingress_command
                ON transport_ingress_receipts (transport_key, command_id)
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS transport_contents_indexes (
                    transport_key TEXT PRIMARY KEY,
                    index_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS hub_tasks (
                    task_id TEXT PRIMARY KEY,
                    workspace_id TEXT NOT NULL,
                    project_key TEXT,
                    title TEXT NOT NULL,
                    objective TEXT NOT NULL,
                    entry_path TEXT,
                    phase TEXT NOT NULL,
                    state TEXT NOT NULL,
                    generation INTEGER NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_hub_tasks_workspace_state
                ON hub_tasks (workspace_id, state, updated_at DESC)
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS hub_handoffs (
                    handoff_id TEXT PRIMARY KEY,
                    task_id TEXT NOT NULL,
                    generation INTEGER NOT NULL,
                    snapshot_json TEXT NOT NULL,
                    snapshot_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_hub_handoffs_task_created
                ON hub_handoffs (task_id, created_at DESC)
                """
            )

    @staticmethod
    def _decode_hub_task_row(row: sqlite3.Row) -> dict[str, Any]:
        payload = json.loads(str(row["payload_json"]) or "{}")
        if not isinstance(payload, dict):
            payload = {}
        payload.update({
            "task_id": str(row["task_id"]),
            "workspace_id": str(row["workspace_id"]),
            "project_key": row["project_key"],
            "title": str(row["title"]),
            "objective": str(row["objective"]),
            "entry_path": row["entry_path"],
            "phase": str(row["phase"]),
            "state": str(row["state"]),
            "generation": int(row["generation"]),
            "created_at": str(row["created_at"]),
            "updated_at": str(row["updated_at"]),
        })
        payload.setdefault("summary", "")
        payload.setdefault("decisions", [])
        payload.setdefault("blockers", [])
        payload.setdefault("next_actions", [])
        payload.setdefault("artifacts", [])
        return payload

    def create_hub_task(
        self,
        *,
        workspace_id: str,
        title: str,
        objective: str,
        project_key: str | None = None,
        entry_path: str | None = None,
    ) -> dict[str, Any]:
        workspace = str(workspace_id or "").strip()
        if not workspace:
            raise ValueError("workspace_id is required")
        title = str(title or "").strip() or "Current task"
        objective = str(objective or "").strip() or "Continue current work"
        task_id = "task_" + uuid.uuid4().hex[:20]
        payload = {
            "summary": "",
            "decisions": [],
            "blockers": [],
            "next_actions": [],
            "artifacts": [],
        }
        with self._lock, self._connect() as conn:
            conn.execute(
                """INSERT INTO hub_tasks
                (task_id, workspace_id, project_key, title, objective, entry_path, phase, state, generation, payload_json)
                VALUES (?, ?, ?, ?, ?, ?, 'active', 'active', 1, ?)""",
                (
                    task_id, workspace, str(project_key or "").strip() or None,
                    title, objective, str(entry_path or "").strip() or None,
                    json.dumps(payload, ensure_ascii=False, sort_keys=True),
                ),
            )
        return self.get_hub_task(task_id)

    def get_hub_task(self, task_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM hub_tasks WHERE task_id=?", (str(task_id),)).fetchone()
        if row is None:
            raise KeyError("TASK_NOT_FOUND")
        return self._decode_hub_task_row(row)

    def list_hub_tasks(
        self,
        *,
        workspace_id: str | None = None,
        state: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        clauses=[]; params=[]
        if workspace_id:
            clauses.append("workspace_id=?"); params.append(str(workspace_id))
        if state:
            clauses.append("state=?"); params.append(str(state))
        sql="SELECT * FROM hub_tasks"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY updated_at DESC, rowid DESC LIMIT ?"
        params.append(max(1,min(int(limit),200)))
        with self._connect() as conn:
            rows=conn.execute(sql,tuple(params)).fetchall()
        return [self._decode_hub_task_row(row) for row in rows]

    def checkpoint_hub_task(
        self,
        task_id: str,
        *,
        expected_generation: int | None,
        patch: dict[str, Any],
    ) -> dict[str, Any]:
        allowed={"title","objective","project_key","entry_path","phase","state","summary","decisions","blockers","next_actions","artifacts"}
        clean={key:value for key,value in dict(patch or {}).items() if key in allowed}
        with self._lock, self._connect() as conn:
            row=conn.execute("SELECT * FROM hub_tasks WHERE task_id=?",(str(task_id),)).fetchone()
            if row is None:
                raise KeyError("TASK_NOT_FOUND")
            current=self._decode_hub_task_row(row)
            generation=int(current["generation"])
            if expected_generation is not None and int(expected_generation)!=generation:
                raise RuntimeError(f"TASK_GENERATION_CONFLICT: expected {expected_generation}, current {generation}")
            payload={
                "summary": current.get("summary",""),
                "decisions": list(current.get("decisions") or []),
                "blockers": list(current.get("blockers") or []),
                "next_actions": list(current.get("next_actions") or []),
                "artifacts": list(current.get("artifacts") or []),
            }
            for key in ("summary","decisions","blockers","next_actions","artifacts"):
                if key in clean:
                    payload[key]=clean[key]
            columns={
                "title": clean.get("title",current["title"]),
                "objective": clean.get("objective",current["objective"]),
                "project_key": clean.get("project_key",current.get("project_key")),
                "entry_path": clean.get("entry_path",current.get("entry_path")),
                "phase": clean.get("phase",current["phase"]),
                "state": clean.get("state",current["state"]),
            }
            cursor=conn.execute(
                """UPDATE hub_tasks SET title=?, objective=?, project_key=?, entry_path=?, phase=?, state=?,
                   generation=?, payload_json=?, updated_at=CURRENT_TIMESTAMP
                   WHERE task_id=? AND generation=?""",
                (
                    str(columns["title"] or "Current task"),
                    str(columns["objective"] or "Continue current work"),
                    str(columns["project_key"] or "").strip() or None,
                    str(columns["entry_path"] or "").strip() or None,
                    str(columns["phase"] or "active"),
                    str(columns["state"] or "active"),
                    generation+1,
                    json.dumps(payload,ensure_ascii=False,sort_keys=True),
                    str(task_id),
                    generation,
                ),
            )
            if cursor.rowcount!=1:
                raise RuntimeError("TASK_GENERATION_CONFLICT")
        return self.get_hub_task(task_id)

    def complete_hub_task(self, task_id: str, *, expected_generation: int | None = None) -> dict[str, Any]:
        return self.checkpoint_hub_task(
            task_id,
            expected_generation=expected_generation,
            patch={"state":"completed","phase":"completed"},
        )

    def create_hub_handoff(self, task_id: str, *, generation: int, snapshot: dict[str, Any]) -> dict[str, Any]:
        task=self.get_hub_task(task_id)
        if int(task["generation"])!=int(generation):
            raise RuntimeError(f"TASK_GENERATION_CONFLICT: expected {generation}, current {task['generation']}")
        encoded=json.dumps(snapshot,ensure_ascii=False,sort_keys=True,separators=(",",":"))
        handoff_id="handoff_"+uuid.uuid4().hex[:20]
        digest=hashlib.sha256(encoded.encode("utf-8")).hexdigest()
        with self._lock, self._connect() as conn:
            conn.execute(
                """INSERT INTO hub_handoffs
                (handoff_id, task_id, generation, snapshot_json, snapshot_hash)
                VALUES (?, ?, ?, ?, ?)""",
                (handoff_id,str(task_id),int(generation),encoded,digest),
            )
        return self.get_hub_handoff(handoff_id)

    def get_hub_handoff(self, handoff_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row=conn.execute("SELECT * FROM hub_handoffs WHERE handoff_id=?",(str(handoff_id),)).fetchone()
        if row is None:
            raise KeyError("HANDOFF_NOT_FOUND")
        return {
            "handoff_id":str(row["handoff_id"]),
            "task_id":str(row["task_id"]),
            "generation":int(row["generation"]),
            "snapshot":json.loads(str(row["snapshot_json"])),
            "snapshot_hash":str(row["snapshot_hash"]),
            "created_at":str(row["created_at"]),
        }

    def latest_hub_handoff(self, task_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row=conn.execute(
                "SELECT handoff_id FROM hub_handoffs WHERE task_id=? ORDER BY created_at DESC, rowid DESC LIMIT 1",
                (str(task_id),),
            ).fetchone()
        return None if row is None else self.get_hub_handoff(str(row["handoff_id"]))

    def get_transport_contents_index(self, transport_key: str) -> dict[str, str] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT index_json FROM transport_contents_indexes WHERE transport_key=?",
                (transport_key,),
            ).fetchone()
        if row is None:
            return None
        payload = json.loads(str(row["index_json"]))
        if not isinstance(payload, dict):
            return None
        return {str(name): str(sha) for name, sha in payload.items()}

    def set_transport_contents_index(self, transport_key: str, index: dict[str, str]) -> None:
        encoded = json.dumps(
            {str(name): str(sha) for name, sha in index.items()},
            ensure_ascii=False,
            sort_keys=True,
        )
        with self._lock, self._connect() as conn:
            conn.execute(
                """INSERT INTO transport_contents_indexes (transport_key, index_json, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(transport_key) DO UPDATE SET
                    index_json=excluded.index_json, updated_at=CURRENT_TIMESTAMP""",
                (transport_key, encoded),
            )

    def command_exists(self, command_id: str) -> bool:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT status, result_json FROM commands WHERE command_id=?",
                (command_id,),
            ).fetchone()
            if row is None:
                return False
            return not (row["status"] == "transport_accepted" and row["result_json"] is None)

    def accept_transport_command(self, command) -> dict[str, Any]:
        encoded = self._encode_command(command)
        with self._lock, self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM commands WHERE command_id=?",
                (command.command_id,),
            ).fetchone()
            if row is None:
                try:
                    conn.execute(
                        """INSERT INTO commands
                        (command_id, workspace_id, adapter, session_id, operation, request_json, status)
                        VALUES (?, ?, ?, ?, ?, ?, 'transport_accepted')""",
                        (
                            command.command_id,
                            command.workspace,
                            command.adapter,
                            command.session,
                            command.operation,
                            encoded,
                        ),
                    )
                except sqlite3.IntegrityError:
                    pass
                row = conn.execute(
                    "SELECT * FROM commands WHERE command_id=?",
                    (command.command_id,),
                ).fetchone()
            if row is None:
                raise RuntimeError("transport command acceptance was not persisted")
            if str(row["request_json"]) != encoded:
                raise CommandIdentityConflict(command.command_id)
            return self._decode_command_row(row)

    def claim_transport_command(self, command) -> str:
        encoded = self._encode_command(command)
        with self._lock, self._connect() as conn:
            row = conn.execute(
                "SELECT request_json, status, result_json FROM commands WHERE command_id=?",
                (command.command_id,),
            ).fetchone()
            if row is None:
                conn.execute(
                    """INSERT INTO commands
                    (command_id, workspace_id, adapter, session_id, operation, request_json, status)
                    VALUES (?, ?, ?, ?, ?, ?, 'received')""",
                    (
                        command.command_id,
                        command.workspace,
                        command.adapter,
                        command.session,
                        command.operation,
                        encoded,
                    ),
                )
                return "claimed"
            if str(row["request_json"]) != encoded:
                raise CommandIdentityConflict(command.command_id)
            if row["result_json"] is not None:
                return "terminal"
            if str(row["status"] or "") != "transport_accepted":
                return "already_claimed"
            cursor = conn.execute(
                """UPDATE commands
                SET status='received', updated_at=CURRENT_TIMESTAMP
                WHERE command_id=? AND status='transport_accepted' AND result_json IS NULL""",
                (command.command_id,),
            )
            if cursor.rowcount == 1:
                return "claimed"
            row = conn.execute(
                "SELECT request_json, status, result_json FROM commands WHERE command_id=?",
                (command.command_id,),
            ).fetchone()
            if row is None:
                raise RuntimeError("transport command disappeared during claim")
            if str(row["request_json"]) != encoded:
                raise CommandIdentityConflict(command.command_id)
            return "terminal" if row["result_json"] is not None else "already_claimed"

    def insert_command(self, command, *, status: str = "received") -> None:
        encoded = self._encode_command(command)
        with self._lock, self._connect() as conn:
            try:
                conn.execute(
                    """INSERT INTO commands
                    (command_id, workspace_id, adapter, session_id, operation, request_json, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (
                        command.command_id,
                        command.workspace,
                        command.adapter,
                        command.session,
                        command.operation,
                        encoded,
                        status,
                    ),
                )
            except sqlite3.IntegrityError:
                row = conn.execute(
                    "SELECT request_json, status, result_json FROM commands WHERE command_id=?",
                    (command.command_id,),
                ).fetchone()
                if row is not None and str(row["request_json"]) != encoded:
                    raise CommandIdentityConflict(command.command_id)
                if (
                    row is not None
                    and row["status"] == "transport_accepted"
                    and row["result_json"] is None
                    and status == "received"
                ):
                    cursor = conn.execute(
                        """UPDATE commands
                        SET status='received', updated_at=CURRENT_TIMESTAMP
                        WHERE command_id=? AND status='transport_accepted' AND result_json IS NULL""",
                        (command.command_id,),
                    )
                    if cursor.rowcount == 1:
                        return
                raise

    def record_ingress_receipt(
        self,
        transport_key: str,
        command_id: str,
        receipt_id: str,
        ingress_kind: str,
        routing: dict[str, Any] | None = None,
    ) -> None:
        routing_json = json.dumps(routing or {}, ensure_ascii=False, sort_keys=True)
        with self._lock, self._connect() as conn:
            row = conn.execute(
                """SELECT command_id, ingress_kind FROM transport_ingress_receipts
                WHERE transport_key=? AND receipt_id=?""",
                (transport_key, receipt_id),
            ).fetchone()
            if row is not None:
                if str(row["command_id"]) != str(command_id):
                    raise CommandIdentityConflict(command_id)
                if str(row["ingress_kind"]) != str(ingress_kind):
                    raise RuntimeError("INGRESS_RECEIPT_KIND_CONFLICT")
                conn.execute(
                    """UPDATE transport_ingress_receipts
                    SET routing_json=?, observed_at=CURRENT_TIMESTAMP
                    WHERE transport_key=? AND receipt_id=?""",
                    (routing_json, transport_key, receipt_id),
                )
                return
            conn.execute(
                """INSERT INTO transport_ingress_receipts
                (transport_key, receipt_id, command_id, ingress_kind, routing_json)
                VALUES (?, ?, ?, ?, ?)""",
                (transport_key, receipt_id, command_id, ingress_kind, routing_json),
            )

    def list_ingress_receipts(self, transport_key: str, command_id: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """SELECT transport_key, receipt_id, command_id, ingress_kind,
                          routing_json, observed_at, published_at
                FROM transport_ingress_receipts
                WHERE transport_key=? AND command_id=?
                ORDER BY ingress_kind ASC, receipt_id ASC""",
                (transport_key, command_id),
            ).fetchall()
        result: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["routing"] = json.loads(item.pop("routing_json") or "{}")
            result.append(item)
        return result

    def mark_ingress_receipt_published(self, transport_key: str, receipt_id: str) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                """UPDATE transport_ingress_receipts
                SET published_at=CURRENT_TIMESTAMP
                WHERE transport_key=? AND receipt_id=?""",
                (transport_key, receipt_id),
            )

    def list_pending_terminal_receipts(
        self,
        transport_key: str,
        *,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 500))
        with self._connect() as conn:
            rows = conn.execute(
                """SELECT r.transport_key, r.receipt_id, r.command_id, r.ingress_kind,
                          r.routing_json, r.observed_at, r.published_at,
                          c.request_json, c.result_json
                FROM transport_ingress_receipts AS r
                JOIN commands AS c ON c.command_id = r.command_id
                WHERE r.transport_key=?
                  AND r.published_at IS NULL
                  AND c.result_json IS NOT NULL
                ORDER BY r.observed_at ASC, r.receipt_id ASC
                LIMIT ?""",
                (transport_key, limit),
            ).fetchall()
        pending: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["routing"] = json.loads(item.pop("routing_json") or "{}")
            item["request"] = json.loads(item.pop("request_json"))
            item["result"] = json.loads(item.pop("result_json"))
            pending.append(item)
        return pending

    def save_result(self, result) -> None:
        payload = result.model_dump(mode="json")
        with self._lock, self._connect() as conn:
            prior = conn.execute('SELECT result_json FROM commands WHERE command_id=?', (result.command_id,)).fetchone()
            conn.execute(
                """UPDATE commands
                SET result_json=?, status=?, evidence_id=?, updated_at=CURRENT_TIMESTAMP
                WHERE command_id=?""",
                (
                    json.dumps(payload, ensure_ascii=False, sort_keys=True),
                    result.status.value,
                    result.evidence_id,
                    result.command_id,
                ),
            )
            if prior is not None and prior['result_json'] is None:
                command_trace.append(conn, result.command_id, 'completed', {'status': result.status.value, 'stages': result.stages, 'failure': result.failure.model_dump(mode='json') if result.failure else None, 'evidence_id': result.evidence_id})

    def record_event(self, command_id, event, detail=None):
        with self._lock, self._connect() as conn:
            command_trace.append(conn, command_id, event, detail)

    def command_trace(self, command_id, after=0, limit=100):
        with self._connect() as conn:
            return command_trace.read(conn, command_id, after, limit)

    def is_published(self, transport_key: str, command_id: str) -> bool:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT 1 FROM transport_publications WHERE transport_key=? AND command_id=?",
                (transport_key, command_id),
            ).fetchone()
            return row is not None

    def mark_published(self, transport_key: str, command_id: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO transport_publications (transport_key, command_id) VALUES (?, ?)",
                (transport_key, command_id),
            )

    def task_idle_snapshot(self) -> dict[str, Any]:
        """Return minimal command activity needed by the desktop idle notifier.

        Transport control-plane probes are excluded so health/status checks do
        not postpone a user-facing "task finished" notification.
        """
        terminal_statuses = (
            "success",
            "failed",
            "skipped",
            "denied",
            "conflict",
            "unknown",
        )
        placeholders = ",".join("?" for _ in terminal_statuses)
        business_filter = (
            "NOT (adapter='bridge_transport' "
            "AND operation IN ('transport.ping','command.status'))"
        )
        with self._connect() as conn:
            pending = conn.execute(
                f"SELECT COUNT(*) AS count FROM commands "
                f"WHERE {business_filter} AND status NOT IN ({placeholders})",
                terminal_statuses,
            ).fetchone()
            latest = conn.execute(
                f"""SELECT command_id, workspace_id, adapter, session_id,
                           operation, status, created_at, updated_at
                    FROM commands
                    WHERE {business_filter}
                      AND status IN ({placeholders})
                    ORDER BY updated_at DESC, rowid DESC
                    LIMIT 1""",
                terminal_statuses,
            ).fetchone()
        return {
            "pending_count": int(pending["count"] if pending is not None else 0),
            "latest_terminal": dict(latest) if latest is not None else None,
        }

    def list_commands(self, limit: int = 20) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 200))
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT command_id, workspace_id, adapter, session_id, operation, status, evidence_id, created_at, updated_at FROM commands ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return [dict(row) for row in rows]

    def list_command_summaries(
        self,
        workspace_id: str,
        *,
        limit: int = 20,
        terminal_only: bool = True,
    ) -> list[dict[str, Any]]:
        limit=max(1,min(int(limit),200))
        workspace=str(workspace_id or "").strip()
        if not workspace:
            return []
        params:[Any]=[workspace]
        sql=(
            "SELECT command_id, workspace_id, adapter, session_id, operation, status, "
            "evidence_id, created_at, updated_at FROM commands WHERE workspace_id=?"
        )
        if terminal_only:
            terminal=("success","failed","skipped","denied","conflict","unknown","rejected","cancelled","canceled","rolled_back")
            sql += " AND status IN (" + ",".join("?" for _ in terminal) + ")"
            params.extend(terminal)
        sql += " ORDER BY updated_at DESC, rowid DESC LIMIT ?"
        params.append(limit)
        with self._connect() as conn:
            rows=conn.execute(sql,tuple(params)).fetchall()
        return [dict(row) for row in rows]

    def list_command_records(self, limit: int = 200) -> list[dict[str, Any]]:
        """Return recent command rows with decoded request/result payloads."""
        limit = max(1, min(int(limit), 500))
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM commands ORDER BY created_at DESC, rowid DESC LIMIT ?",
                (limit,),
            ).fetchall()
        records: list[dict[str, Any]] = []
        for row in rows:
            records.append(self._decode_command_row(row))
        return records

    def get_command(self, command_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM commands WHERE command_id=?", (command_id,)).fetchone()
            if row is None:
                return None
            return self._decode_command_row(row)
