from __future__ import annotations
import hashlib
import json
from pathlib import Path


class EvidenceStore:
    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.v2_root = self.root / "v2"

    @staticmethod
    def _evidence_id(command_id: str) -> str:
        return "ev_" + command_id.replace("/", "_").replace(":", "_")

    def _v2_path(self, evidence_id: str) -> Path:
        shard = hashlib.sha256(evidence_id.encode("utf-8")).hexdigest()[:2]
        return self.v2_root / shard / f"{evidence_id}.json"

    def write(self, command, result) -> str:
        evidence_id = self._evidence_id(command.command_id)
        path = self._v2_path(evidence_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "command": command.model_dump(mode="json"),
            "result": result.model_dump(mode="json"),
        }
        path.write_text(
            json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
            encoding="utf-8",
        )
        return evidence_id

    def read(self, evidence_id: str) -> dict:
        path = self._v2_path(evidence_id)
        if not path.is_file():
            # All pre-R4 evidence remains valid and untouched.
            path = self.root / f"{evidence_id}.json"
        return json.loads(path.read_text(encoding="utf-8"))
