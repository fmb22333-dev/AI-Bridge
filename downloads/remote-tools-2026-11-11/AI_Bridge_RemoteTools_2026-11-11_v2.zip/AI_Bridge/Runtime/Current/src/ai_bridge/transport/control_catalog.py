"""One discoverable contract shared by remote presence, ping and capability search."""
import base64
import hashlib


def _object(properties, required=()):
    return {'type':'object','properties':properties,'required':list(required),'additionalProperties':False}


def catalog():
    target={'command_id':{'type':'string','description':'The original task command_id, not the ID of this query.'}}
    entries=[
        ('transport.ping','Probe Bridge liveness and discover transport.capabilities.',_object({}),False),
        ('transport.capabilities','Read remote command schemas, examples and local ta_* mappings.',_object({}),False),
        ('transport.context','Read live workspaces, Host sessions and declared UE/Houdini capabilities; select an explicit target.',_object({}),False),
        ('command.status','Read incremental lifecycle/progress with after cursor; include_result retrieves the terminal receipt.',_object({**target,'after':{'type':'integer','minimum':0},'limit':{'type':'integer','minimum':1,'maximum':200},'include_result':{'type':'boolean'}},['command_id']),False),
        ('command.log','Read the full saved redacted process log in lossless base64 byte pages. Decode and concatenate pages using next_offset; EOF is relative to the observed file size.',_object({**target,'offset':{'type':'integer','minimum':0,'default':0},'count':{'type':'integer','minimum':1,'maximum':3072,'default':2048}},['command_id']),False),
        ('command.cancel','Cancel only the command-owned process tree. close_host=true additionally requests normal closure of the original bound Host; unsaved-work prompts need the user.',_object({**target,'close_host':{'type':'boolean','default':False}},['command_id']),True),
    ]
    return {'protocol':'bridge-remote-controls/1','adapter':'bridge_transport','revision':'2026-11-11.2',
            'commands':[{'name':name,'adapter':'bridge_transport','description':description,'input_schema':schema,'write':write,'risk':'L1'} for name,description,schema,write in entries],
            'mcp_mapping':{'ta_bridge_context':'transport.context','ta_bridge_submit':'original operation in canonical CommandEnvelope',
                           'ta_bridge_status':'command.status','ta_bridge_result':'command.status(include_result=true)',
                           'ta_bridge_cancel':'command.cancel'},
            'submission':'Use a new command_id for each query/page. Keep the original command_id in arguments.command_id. Preserve the same envelope and ID when recovering an uncertain submission.',
            'log_paging':'data_base64 is the authoritative UTF-8 file bytes after redaction. Verify chunk_sha256, concatenate decoded bytes, and advance next_offset. eof_at_read does not prove the task finished.',
            'example':{'protocol':'bridge/1','command_id':'unique-log-query-1','workspace':'Bridge','adapter':'bridge_transport',
                       'operation':'command.log','arguments':{'command_id':'original-task-id','offset':0,'count':2048},'risk':'L1'}}


def capability_rows():
    return [{'target':'transport:bridge_transport:'+entry['name'],'kind':'transport',
             'adapter':'bridge_transport','name':entry['name'],'description':entry['description'],
             'version':'1.0','write':entry['write'],'host_mutation':False,'risk':entry['risk'],
             'input_schema':entry['input_schema'],'invocation':'Send a direct bridge_transport CommandEnvelope; capability.run is not this control-plane entry point.'}
            for entry in catalog()['commands']]


def discovery_hint():
    return {'adapter':'bridge_transport','operation':'transport.capabilities','revision':'2026-11-11.2',
            'new_operations':['transport.context','command.status','command.log','command.cancel']}


def read_log(service, target, offset=0, count=2048):
    if type(offset) is not int or offset<0 or type(count) is not int or not 1<=count<=3072:
        raise ValueError('LOG_RANGE_REQUIRES_NONNEGATIVE_OFFSET_AND_1_TO_3072_BYTES')
    row=service.db.get_command(target)
    if row is None: return {'found':False,'target_command_id':target,'reason':'COMMAND_NOT_FOUND'}
    path=service.db.path.parent/'state'/'command_logs'/(hashlib.sha256(target.encode()).hexdigest()+'.log')
    if not path.is_file():
        return {'found':False,'target_command_id':target,'reason':'NO_SAVED_PROCESS_LOG','terminal':row.get('result') is not None}
    with path.open('rb') as stream:
        stream.seek(offset)
        data=stream.read(count)
        next_offset=stream.tell()
        stream.seek(0,2)
        total=stream.tell()
    return {'found':True,'target_command_id':target,'encoding':'base64','source_encoding':'utf-8',
            'data_base64':base64.b64encode(data).decode('ascii'),'chunk_sha256':hashlib.sha256(data).hexdigest(),
            'offset':offset,'next_offset':next_offset,'total_bytes_observed':total,'eof_at_read':next_offset>=total,
            'terminal':row.get('result') is not None,'redacted':True}
