const $ = (selector) => document.querySelector(selector);
let lastRemote = {};
let latestResumePrompt = "";

async function api(path, options = {}) {
  const response = await fetch(path, {...options, headers:{"Content-Type":"application/json", ...(options.headers||{})}});
  const text = await response.text(); let data={};
  try { data=text?JSON.parse(text):{}; } catch { data={detail:text}; }
  if(!response.ok) throw new Error(data.detail||text||`HTTP ${response.status}`);
  return data;
}
function esc(value){return String(value??"").replace(/[&<>"']/g,(char)=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]);}
function sessionCard(item,historical=false){const busy=!historical&&item.state==="busy_unknown";const visual=historical?"offline":(busy?"busyUnknown":"online");const stateText=historical?"Disconnected":(busy?"BUSY UNKNOWN":"Connected");return `<div class="item session ${visual}"><div class="sessionTitle"><span class="dot"></span><b>${esc(item.adapter)} · ${esc(item.session_id)}</b><span class="stateText">${stateText}</span></div><small>${esc(item.project_file)}</small><small>${esc(item.host_version)} · PID ${esc(item.pid)}</small>${busy?`<small>上一条 Host 操作已超预算，但尚未收到对应终态；Bridge 已暂停该 Session 的后续 Host 命令。</small>`:""}${item.project_file?`<div class="inlineActions"><button class="tiny sessionOpen" data-id="${esc(item.session_id)}">打开工程目录</button></div>`:""}</div>`;}
function remoteCard(remote){if(!remote.configured)return `<div class="item remoteState offline"><div class="sessionTitle"><span class="dot"></span><b>未配置</b><span class="stateText">github_bus</span></div><small>GitHub Bus 尚未连接。</small></div>`;const good=remote.status==="connected";const rate=remote.github_rate||{};const limitText=(rate.remaining!=null&&rate.limit!=null)?`<small>GitHub API: ${esc(rate.remaining)} / ${esc(rate.limit)} remaining · 304 ${esc(Math.round((rate.not_modified_ratio||0)*100))}%</small>`:"";return `<div class="item remoteState ${good?"online":"offline"}"><div class="sessionTitle"><span class="dot"></span><b>${good?"Connected":esc(remote.status)}</b><span class="stateText">github_bus</span></div><small>${esc(remote.repository)} · ${esc(remote.branch)}</small><small>Bridge ID: <b>${esc(remote.bridge_id)}</b></small><small>轮询: ${esc(remote.poll_interval_seconds??2)}s（最低 ${esc(remote.poll_floor_seconds??remote.poll_interval_seconds??2)}s）</small>${limitText}${remote.credential_saved?"<small>凭据：已由 Windows DPAPI 安全保存</small>":""}${remote.detail?`<small>${esc(remote.detail)}</small>`:""}</div>`;}
function pluginManagerCard(data){
  const hosts=data.hosts||[];
  if(!hosts.length)return '<p class="muted">没有发现打包插件。</p>';
  return hosts.map((host)=>{
    const scaffold=host.state!=="ready";
    if(scaffold){
      return `<div class="item pluginCard offline"><div class="sessionTitle"><span class="dot"></span><b>${esc(host.display_name||host.id)}</b><span class="stateText">Scaffold</span></div><small>已包含在 Bridge 包中，但安装器尚未完成。</small><div class="inlineActions"><button class="tiny" disabled>暂不可安装</button></div></div>`;
    }
    if(host.id==="unreal"){
      const targets=host.targets||[];
      const header=`<div class="sessionTitle"><span class="dot"></span><b>${esc(host.display_name||host.id)}</b><span class="stateText">${targets.length?"Ready":"No project"}</span></div><small>Bundled ${esc(host.bundled_version||"?")} · 项目级插件，不会自动关闭或重启 Unreal。</small>`;
      if(!targets.length)return `<div class="item pluginCard offline">${header}<small>在 Workspace 根目录注册一个包含 .uproject 的 UE 工程后即可一键安装。</small></div>`;
      const cards=targets.map((target)=>{
        let stateText="Not installed";
        let summary="尚未安装";
        if(target.installed_newer_than_bundled){stateText="Project newer";summary=`项目 ${esc(target.installed_version||"?")}，高于包内 ${esc(target.bundled_version||"?")}；不会降级覆盖。`;}
        else if(target.installed&&!target.disk_up_to_date){stateText="Update available";summary=`磁盘 ${esc(target.installed_version||"?")} → 包内 ${esc(target.bundled_version||"?")}`;}
        else if(target.installed){stateText="Up to date";summary=`已安装 ${esc(target.installed_version||"?")}`;}
        const label=!target.installed?"安装":(!target.disk_up_to_date?"更新":"重新安装");
        const action=target.installed_newer_than_bundled?"":`<div class="inlineActions"><button class="tiny pluginInstall" data-host="unreal" data-project="${esc(target.project_file||"")}">${label}</button></div>`;
        return `<div class="item ${target.disk_up_to_date?"online":"offline"}"><div class="sessionTitle"><b>${esc((target.project_file||"").split(/[\\\\/]/).pop()||"UE Project")}</b><span class="stateText">${esc(stateText)}</span></div><small>${esc(target.project_file||"")}</small><small>${summary}</small>${action}</div>`;
      }).join("");
      return `<div class="item pluginCard ${host.disk_up_to_date?"online":"offline"}">${header}${cards}</div>`;
    }
    const sessions=host.live_sessions||[];
    let stateText="Ready";let summary="";
    if(!host.installed){stateText="Not installed";summary="尚未安装到 Host 用户目录。";}
    else if(!host.disk_up_to_date){stateText="Update available";summary=`磁盘 ${esc(host.installed_version||"?")} → 包内 ${esc(host.bundled_version||"?")}`;}
    else if(host.restart_required){stateText="Restart required";summary=`磁盘已是 ${esc(host.bundled_version||"?")}，运行中的 Host 仍为 ${esc((host.live_versions||[]).join(", ")||"?")}`;}
    else if(sessions.length){stateText="Up to date";summary=`磁盘 / Live: ${esc(host.bundled_version||"?")}`;}
    else{stateText="Installed";summary=`磁盘已是 ${esc(host.bundled_version||"?")}，Host 当前离线。`;}
    let actions="";
    if(host.supports_install){
      if(sessions.length&&host.supports_restart_apply){
        const primary=sessions[0];const needsUpdate=!host.installed||!host.disk_up_to_date||host.restart_required;
        actions+=`<button class="tiny pluginRestart" data-host="${esc(host.id)}" data-session="${esc(primary.session_id)}" data-force="${needsUpdate?"false":"true"}">${needsUpdate?"更新并重启":"重新安装并重启"}</button>`;
      }else{
        actions+=`<button class="tiny pluginInstall" data-host="${esc(host.id)}">${!host.installed?"安装":(!host.disk_up_to_date?"更新":"重新安装")}</button>`;
      }
    }
    return `<div class="item pluginCard ${host.restart_required?"offline":"online"}"><div class="sessionTitle"><span class="dot"></span><b>${esc(host.display_name||host.id)}</b><span class="stateText">${esc(stateText)}</span></div><small>${summary}</small><small>Bundled ${esc(host.bundled_version||"?")} · Installed ${esc(host.installed_version||"—")}</small>${host.install_path?`<small>${esc(host.install_path)}</small>`:""}${actions?`<div class="inlineActions">${actions}</div>`:""}</div>`;
  }).join("");
}
function executionPolicyCard(policy){const activeProjects=policy.active_projects||[];const activeWorkspaces=policy.active_workspaces||[];const global=`<div class="item"><div class="budgetRow"><div><b>Bridge 默认</b><small>AI、工程和 Workspace 均未指定时使用</small></div><div class="budgetControls"><input id="defaultBudget" type="number" min="1" max="7200" step="1" value="${esc(policy.default_budget_seconds??120)}"><span>秒</span><label class="recoveryToggle"><input id="defaultAutoRecover" type="checkbox" ${policy.default_auto_recover?"checked":""}>超预算自动恢复</label><button id="saveDefaultBudget" class="tiny">保存</button></div></div></div>`;const workspaces=activeWorkspaces.length?activeWorkspaces.map((item)=>`<div class="item"><div class="budgetRow"><div><b>Workspace · ${esc(item.workspace_id)}</b><small>${item.budget_source==="workspace_default"?"Workspace 预算覆盖":"预算继承 Bridge 默认"} · ${item.auto_recover_source==="workspace_default"?"恢复策略覆盖":"恢复策略继承 Bridge 默认"}</small></div><div class="budgetControls"><input class="workspaceBudget" data-workspace="${esc(item.workspace_id)}" type="number" min="1" max="7200" step="1" value="${esc(item.budget_seconds)}"><span>秒</span><label class="recoveryToggle"><input class="workspaceAutoRecover" data-workspace="${esc(item.workspace_id)}" type="checkbox" ${item.auto_recover?"checked":""}>自动恢复</label><button class="tiny saveWorkspaceBudget" data-workspace="${esc(item.workspace_id)}">保存</button><button class="tiny resetWorkspaceBudget" data-workspace="${esc(item.workspace_id)}">继承默认</button></div></div></div>`).join(""):'<p class="muted">当前没有可配置 Workspace。</p>';const projects=activeProjects.length?activeProjects.map((item)=>`<div class="item"><div class="budgetRow"><div><b>${esc(item.project_file)}</b><small>${item.source==="project_default"?"工程精确预算覆盖":"当前未设置工程精确预算覆盖"}</small></div><div class="budgetControls"><input class="projectBudget" data-project="${esc(item.project_file)}" type="number" min="1" max="7200" step="1" value="${item.budget_seconds==null?"":esc(item.budget_seconds)}" placeholder="可选"><span>秒</span><button class="tiny saveProjectBudget" data-project="${esc(item.project_file)}">保存</button><button class="tiny resetProjectBudget" data-project="${esc(item.project_file)}">清除工程覆盖</button></div></div></div>`).join(""):'<p class="muted">当前没有带工程路径的在线 Session。</p>';return global+`<h3>Workspace 默认</h3>`+workspaces+`<h3>当前工程精确预算</h3>`+projects;}
function recoveryHistory(items){if(!items||!items.length)return '<p class="muted">暂无恢复记录</p>';return items.map((item)=>`<div class="recoverySummary"><div><b>${esc(item.status||"unknown")}</b> · ${esc(item.source_operation||"")}</div><small>${esc(item.source_command_id||"")} · checkpoint ${esc(item.checkpoint_id||"none")}</small><small>${item.reason?esc(item.reason)+" · ":""}<a href="/control/recoveries/${encodeURIComponent(item.recovery_id)}" target="_blank">查看完整恢复审计</a></small></div>`).join("");}
async function safeAction(fn){try{$("#remoteError").textContent="";if($("#budgetError"))$("#budgetError").textContent="";if($("#pluginError"))$("#pluginError").textContent="";await fn();}catch(error){$("#remoteError").textContent=error.message;if($("#budgetError"))$("#budgetError").textContent=error.message;if($("#pluginError"))$("#pluginError").textContent=error.message;}}
function refreshHandoffWorkspace(workspaces){
  const select=$("#handoffWorkspace"); if(!select)return;
  const current=select.value;
  select.innerHTML=(workspaces||[]).map((w)=>`<option value="${esc(w.id)}">${esc(w.id)}</option>`).join("");
  if(current && [...select.options].some((o)=>o.value===current))select.value=current;
}
async function refreshHandoffTasks(){
  const workspace=$("#handoffWorkspace")?.value; if(!workspace)return;
  try{
    const data=await api("/control/tasks?workspace_id="+encodeURIComponent(workspace)+"&state=active");
    const task=(data.tasks||[])[0];
    if(task){
      $("#handoffBadge").textContent=`Gen ${task.generation} · ${task.phase||task.state}`;
      if(!$("#handoffTitle").dataset.dirty)$("#handoffTitle").value=task.title||"Current task";
      if(!$("#handoffObjective").dataset.dirty)$("#handoffObjective").value=task.objective||"Continue current work";
      if(task.entry_path)$("#handoffEntryPath").value=task.entry_path;
      if(task.project_key)$("#handoffProjectKey").value=task.project_key;
    }else{$("#handoffBadge").textContent="Ready";}
  }catch(error){$("#handoffError").textContent=error.message;}
}
async function refresh(){try{const [state,supervisor]=await Promise.all([api("/control/status"),api("/control/supervisor/status")]);lastRemote=state.remote||{};refreshHandoffWorkspace(state.workspaces||[]);$("#coreBadge").textContent=state.write_blocked?"WRITE BLOCKED":"CORE OK";$("#coreBadge").className="badge "+(state.write_blocked?"blocked":"ok");$("#status").innerHTML=`<p>Core: <b>${esc(state.core)}</b></p><p>AI 写入: <b>${state.write_blocked?"停止":"允许"}</b></p>`;
$("#workspaces").innerHTML=state.workspaces.length?state.workspaces.map((w)=>`<div class="item ws"><div><b>${esc(w.id)}</b><small>${esc(w.root)}</small></div><div class="inlineActions"><button class="tiny wsOpen" data-id="${esc(w.id)}">打开</button><button class="tiny wsDelete" data-id="${esc(w.id)}">删除</button></div></div>`).join(""):'<p class="muted">尚未配置</p>';
document.querySelectorAll(".wsDelete").forEach((b)=>b.onclick=async()=>{if(!confirm(`取消注册 Workspace「${b.dataset.id}」？磁盘文件不会被删除。`))return;await api("/control/workspaces/"+encodeURIComponent(b.dataset.id),{method:"DELETE"});await refresh();});
document.querySelectorAll(".wsOpen").forEach((b)=>b.onclick=()=>safeAction(()=>api("/control/system/open-workspace/"+encodeURIComponent(b.dataset.id),{method:"POST"})));
const live=state.sessions.filter((i)=>i.state==="connected"||i.state==="busy_unknown"),old=state.sessions.filter((i)=>i.state!=="connected"&&i.state!=="busy_unknown");$("#sessions").innerHTML=(live.length?live.map((i)=>sessionCard(i)).join(""):'<p class="muted">没有在线软件</p>')+(old.length?`<div class="historyHeader">历史 Session</div>${old.map((i)=>sessionCard(i,true)).join("")}`:"");
document.querySelectorAll(".sessionOpen").forEach((b)=>b.onclick=()=>safeAction(()=>api("/control/system/open-session/"+encodeURIComponent(b.dataset.id),{method:"POST"})));
$("#plugins").innerHTML=pluginManagerCard(state.plugins||{});
document.querySelectorAll(".pluginInstall").forEach((b)=>b.onclick=()=>safeAction(async()=>{let path="/control/plugins/"+encodeURIComponent(b.dataset.host)+"/install";if(b.dataset.project)path+="?project_file="+encodeURIComponent(b.dataset.project);await api(path,{method:"POST"});await refresh();}));
document.querySelectorAll(".pluginRestart").forEach((b)=>b.onclick=()=>safeAction(async()=>{if(!confirm("将先创建完整工程 checkpoint，然后关闭并重启该 Host 以安装/加载插件。继续？"))return;const result=await api("/control/plugins/"+encodeURIComponent(b.dataset.host)+"/restart-apply",{method:"POST",body:JSON.stringify({session_id:b.dataset.session,force_restart:b.dataset.force==="true"})});if(result.status!=="applied"&&result.status!=="already_current")throw new Error(result.message||result.reason||"Restart & Apply 未完成");await refresh();}));
$("#remote").innerHTML=remoteCard(lastRemote);$("#disconnectRemote").style.display=lastRemote.configured?"inline-block":"none";$("#openRemoteRepo").disabled=!lastRemote.repository;
const policyState=state.execution_policy||{};$("#executionPolicy").innerHTML=executionPolicyCard(policyState);$("#budgetSummary").textContent=`默认 ${esc(policyState.default_budget_seconds??120)}s · ${policyState.default_auto_recover?"超预算自动恢复":"超预算不自动恢复"}`;
$("#recoveryHistory").innerHTML=recoveryHistory(state.recoveries||[]);
$("#saveDefaultBudget").onclick=()=>safeAction(async()=>{await api("/control/execution-policy/default",{method:"PUT",body:JSON.stringify({budget_seconds:Number($("#defaultBudget").value),auto_recover:$("#defaultAutoRecover").checked})});await refresh();});
document.querySelectorAll(".saveWorkspaceBudget").forEach((b)=>b.onclick=()=>safeAction(async()=>{const selector=CSS.escape(b.dataset.workspace);const input=document.querySelector('.workspaceBudget[data-workspace="'+selector+'"]');const recovery=document.querySelector('.workspaceAutoRecover[data-workspace="'+selector+'"]');await api("/control/execution-policy/workspace",{method:"PUT",body:JSON.stringify({workspace_id:b.dataset.workspace,budget_seconds:Number(input.value),auto_recover:recovery.checked})});await refresh();}));
document.querySelectorAll(".resetWorkspaceBudget").forEach((b)=>b.onclick=()=>safeAction(async()=>{await api("/control/execution-policy/workspace?workspace_id="+encodeURIComponent(b.dataset.workspace),{method:"DELETE"});await refresh();}));
document.querySelectorAll(".saveProjectBudget").forEach((b)=>b.onclick=()=>safeAction(async()=>{const input=document.querySelector('.projectBudget[data-project="'+CSS.escape(b.dataset.project)+'"]');await api("/control/execution-policy/project",{method:"PUT",body:JSON.stringify({project_file:b.dataset.project,budget_seconds:Number(input.value)})});await refresh();}));
document.querySelectorAll(".resetProjectBudget").forEach((b)=>b.onclick=()=>safeAction(async()=>{await api("/control/execution-policy/project?project_file="+encodeURIComponent(b.dataset.project),{method:"DELETE"});await refresh();}));
const updateSource=supervisor.update_source||{};const updateRate=supervisor.update_rate_limit||{};$("#supervisor").innerHTML=`<div class="item ${supervisor.state==="running"?"online":"offline"}"><div class="sessionTitle"><span class="dot"></span><b>${esc(supervisor.state||"unknown")}</b><span class="stateText">Supervisor ${esc(supervisor.supervisor_version||"")}</span></div><small>Runtime: ${esc(supervisor.runtime_version||"unknown")}</small>${updateSource.repository?`<small>Update: ${esc(updateSource.repository)} · ${esc(updateSource.branch||"bridge-runtime")}</small>`:"<small>自动更新源将在 GitHub Bus 配置后自动建立。</small>"}${supervisor.last_update_version?`<small>Last update: ${esc(supervisor.last_update_version)}</small>`:""}${supervisor.last_update_error?`<small>${esc(supervisor.last_update_error)}</small>`:""}${updateRate.remaining!=null?`<small>Update API: ${esc(updateRate.remaining)} / ${esc(updateRate.limit||"?")} remaining</small>`:""}</div>`;
const recentCommands=(state.commands||[]).slice(0,5);$("#commands").innerHTML=recentCommands.length?recentCommands.map((c)=>`<tr><td>${esc(c.command_id)}</td><td>${esc(c.adapter)}</td><td>${esc(c.operation)}</td><td>${esc(c.status)}</td><td>${c.evidence_id?`<a href="/control/evidence/${encodeURIComponent(c.evidence_id)}" target="_blank">${esc(c.evidence_id)}</a>`:""}</td></tr>`).join(""):'<tr><td colspan="5" class="muted">暂无命令</td></tr>';$("#remoteError").textContent="";}catch(error){$("#remoteError").textContent=error.message;}}
$("#stop").onclick=async()=>{await api("/control/emergency-stop",{method:"POST"});await refresh();};$("#resume").onclick=async()=>{await api("/control/emergency-resume",{method:"POST"});await refresh();};
$("#workspaceForm").onsubmit=async(event)=>{event.preventDefault();await api("/control/workspaces",{method:"POST",body:JSON.stringify({workspace_id:$("#wsName").value,root:$("#wsRoot").value})});event.target.reset();await refresh();};
$("#pickWorkspace").onclick=()=>safeAction(async()=>{const data=await api("/control/system/pick-folder",{method:"POST"});if(data.path)$("#wsRoot").value=data.path;});
$("#openDataDir").onclick=()=>safeAction(()=>api("/control/system/open-data-dir",{method:"POST"}));$("#openHoudiniDir").onclick=()=>safeAction(()=>api("/control/system/open-houdini-dir",{method:"POST"}));
$("#editRemote").onclick=()=>{window.location.href="/setup";};$("#openRemoteRepo").onclick=()=>{if(lastRemote.repository)window.open('/setup/github-open-repository?repository='+encodeURIComponent(lastRemote.repository),'_blank','noopener');};$("#manageRemoteToken").onclick=()=>window.open('/setup/github-token-settings','_blank','noopener');
$("#disconnectRemote").onclick=async()=>{if(!confirm("断开 GitHub Bus 并删除本机保存的 GitHub 凭据？"))return;await api("/control/remote",{method:"DELETE"});window.location.href="/setup";};
$("#installAllPlugins").onclick=()=>safeAction(async()=>{await api("/control/plugins/install-all",{method:"POST"});await refresh();});
$("#openCommandHistory").onclick=()=>window.open("/commands","_blank","noopener");
$("#handoffWorkspace").onchange=()=>refreshHandoffTasks();
$("#handoffTitle").oninput=()=>$("#handoffTitle").dataset.dirty="1";
$("#handoffObjective").oninput=()=>$("#handoffObjective").dataset.dirty="1";
$("#oneClickHandoff").onclick=async()=>{
  $("#handoffError").textContent="";
  try{
    const used=Number($("#handoffUsedTokens").value),win=Number($("#handoffContextWindow").value);
    const body={
      workspace_id:$("#handoffWorkspace").value,
      title:$("#handoffTitle").value,
      objective:$("#handoffObjective").value,
      project_key:$("#handoffProjectKey").value,
      entry_path:$("#handoffEntryPath").value
    };
    if(Number.isFinite(used)&&used>=0&&$("#handoffUsedTokens").value!=="")body.used_tokens=used;
    if(Number.isFinite(win)&&win>0&&$("#handoffContextWindow").value!=="")body.context_window=win;
    const data=await api("/control/tasks/handoff",{method:"POST",body:JSON.stringify(body)});
    latestResumePrompt=data.resume_prompt||"";
    $("#resumePrompt").value=latestResumePrompt;
    $("#copyResumePrompt").disabled=!latestResumePrompt;
    const ctx=data.snapshot?.context_assessment||{};
    const ratio=ctx.known?` · Context ${Math.round((ctx.ratio||0)*100)}% / ${ctx.level}`:"";
    $("#handoffBadge").textContent=`Gen ${data.task?.generation||"?"}${ratio}`;
    $("#handoffResult").textContent=`Handoff ${data.handoff_id} · snapshot ${String(data.snapshot_hash||"").slice(0,12)}…`;
    await refreshHandoffTasks();
  }catch(error){$("#handoffError").textContent=error.message;}
};
$("#copyResumePrompt").onclick=async()=>{
  if(!latestResumePrompt)return;
  try{await navigator.clipboard.writeText(latestResumePrompt);$("#handoffResult").textContent="接手指令已复制到剪贴板。";}
  catch(error){$("#handoffError").textContent="复制失败："+error.message;}
};
refresh();refreshHandoffTasks();setInterval(refresh,2000);
