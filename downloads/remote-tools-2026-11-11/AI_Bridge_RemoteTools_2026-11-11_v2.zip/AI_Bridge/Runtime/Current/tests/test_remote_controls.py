import base64
import hashlib
from types import SimpleNamespace

from ai_bridge.core.service import BridgeService
from ai_bridge.core.workspace import WorkspaceRegistry
from ai_bridge.persistence.db import BridgeDB
from ai_bridge.protocol.command import CommandEnvelope
from ai_bridge.protocol.result import ExecutionResult
from ai_bridge.transport.control_catalog import catalog, read_log
from ai_bridge.transport.runner import TransportRunner
from ai_bridge.adapters.work_hub import WorkHubExecutor
from ai_bridge.transport.result_delivery import prepare_result_delivery


def setup(tmp_path):
    workspaces=WorkspaceRegistry();workspaces.register('Bridge',tmp_path)
    service=BridgeService(db=BridgeDB(tmp_path/'bridge.db'),workspaces=workspaces)
    command=CommandEnvelope(command_id='original',workspace='Bridge',adapter='workspace',operation='workspace.command.run')
    service.db.insert_command(command)
    service.db.save_result(ExecutionResult(command_id='original',status='success'))
    return service


def query(operation,args=None):
    return CommandEnvelope(command_id='query-'+operation,workspace='Bridge',adapter='bridge_transport',operation=operation,arguments=args or {})


def test_discovery_matches_normal_capability_search_and_live_context(tmp_path):
    service=setup(tmp_path)
    runner=TransportRunner(service,SimpleNamespace(key='test'))
    ping=runner._ping_query(query('transport.ping'))
    assert ping.result['remote_controls']['operation']=='transport.capabilities'
    result=runner._status_query(query('transport.capabilities'))
    operations={r['name']:r for r in result.result['commands']}
    assert operations['command.log']['input_schema']['properties']['count']['maximum']==3072
    assert operations['command.cancel']['input_schema']['properties']['close_host']['default'] is False
    hub=WorkHubExecutor(service,SimpleNamespace(capability_rows=lambda workspace:[]))
    matches=hub.capability_search('command.log')['matches']
    assert any(m['adapter']=='bridge_transport' and m['name']=='command.log' for m in matches)
    context=runner._status_query(query('transport.context'))
    assert 'Bridge' in context.result['workspaces']
    runner.shutdown(wait=True)


def test_full_log_pages_reconstruct_every_byte_and_stay_below_delivery_compaction(tmp_path):
    service=setup(tmp_path)
    root=tmp_path/'state/command_logs';root.mkdir(parents=True)
    raw=('完整日志🙂：'+('x'*100)+'\r\n').encode()*200
    (root/(hashlib.sha256(b'original').hexdigest()+'.log')).write_bytes(raw)
    offset=0;received=b''
    runner=TransportRunner(service,SimpleNamespace(key='test'))
    # Model the GitHub V5 compaction gate too; Supabase returns this result directly.
    transport=SimpleNamespace(_comment_refs={'query-command.log':{'mode':'issue_channel_v5','channel_id':'test'}},config=SimpleNamespace(bridge_id='test'))
    while True:
        command=query('command.log',{'command_id':'original','offset':offset,'count':3072})
        result=runner._status_query(command)
        delivered=prepare_result_delivery(transport,command,result)
        page=delivered.result
        data=base64.b64decode(page['data_base64'],validate=True)
        assert hashlib.sha256(data).hexdigest()==page['chunk_sha256']
        received+=data;offset=page['next_offset']
        if page['eof_at_read']:break
    assert received==raw
    runner.shutdown(wait=True)


def test_missing_log_and_invalid_ranges_are_explicit(tmp_path):
    service=setup(tmp_path)
    assert read_log(service,'original')['reason']=='NO_SAVED_PROCESS_LOG'
    runner=TransportRunner(service,SimpleNamespace(key='test'))
    for args in ({'offset':-1},{'count':3073},{'offset':'0'},{'count':True}):
        result=runner._status_query(query('command.log',{'command_id':'original',**args}))
        assert result.failure.code=='INVALID_LOG_RANGE'
    runner.shutdown(wait=True)
