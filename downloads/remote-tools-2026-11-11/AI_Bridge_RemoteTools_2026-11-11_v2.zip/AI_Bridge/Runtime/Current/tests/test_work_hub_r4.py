from __future__ import annotations

import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from ai_bridge.adapters.registry import AdapterDescriptor, AdapterRegistry
from ai_bridge.core.workspace import WorkspaceRegistry
from ai_bridge.protocol.capability import CapabilityDescriptor
from ai_bridge.protocol.command import CommandEnvelope, RiskLevel
from ai_bridge.protocol.result import ExecutionResult, ExecutionStatus


def _load_hub():
    try:
        from ai_bridge.adapters.work_hub import WorkHubExecutor, descriptor
    except ImportError as exc:
        raise AssertionError(f"R4 work hub missing: {exc}") from exc
    return WorkHubExecutor, descriptor


class FakeGateway:
    def __init__(self):
        self.calls=[]
    def capability_rows(self,workspace_id=None):
        return [
            {"target":"mcp:workspace:UE58:ta:ta_resume","kind":"mcp","server_id":"workspace:UE58:ta","name":"ta_resume","description":"project takeover","write":False,"risk":"L1"},
            {"target":"mcp:workspace:UE58:ta:ta_read","kind":"mcp","server_id":"workspace:UE58:ta","name":"ta_read","description":"read files","write":False,"risk":"L1"},
        ]
    def call_readonly(self,server_id,tool,arguments,workspace_id=None):
        self.calls.append((server_id,tool,arguments,workspace_id))
        return {"server_id":server_id,"tool":tool,"content":"ok"}
    def batch_readonly(self,calls):
        return {"count":len(calls),"complete":True,"results":[self.call_readonly(x["server_id"],x["tool"],x.get("arguments") or {}) for x in calls]}


class FakeService:
    def __init__(self,root):
        self.workspaces=WorkspaceRegistry();self.workspaces.register("UE58",root)
        self.adapter_registry=AdapterRegistry()
        self.adapter_registry.register(AdapterDescriptor(
            adapter="demo",adapter_version="1",endpoint="local://demo",
            capabilities=[
                CapabilityDescriptor(name="scene.inspect",version="1",write=False,host_mutation=False,risk=RiskLevel.L1),
                CapabilityDescriptor(name="scene.write",version="1",write=True,host_mutation=True,risk=RiskLevel.L2,rollback=True),
            ],
        ))
        self.executed=[]
        self._sessions=[SimpleNamespace(session_id="UE-1",adapter="unreal",adapter_version="1",host_version="5.8",project_file=str(root/"Demo.uproject"),pid=100)]
    def active_sessions(self,adapter=None):
        return [x for x in self._sessions if adapter is None or x.adapter==adapter]
    def execute(self,command):
        self.executed.append(command)
        if command.adapter=="bridge_admin" and command.operation=="bridge.project.resume":
            return ExecutionResult(command_id=command.command_id,status=ExecutionStatus.SUCCESS,result={"project":{"key":command.arguments["project"]},"resume":{"safe_to_continue":True}})
        return ExecutionResult(command_id=command.command_id,status=ExecutionStatus.SUCCESS,result={"routed":True,"adapter":command.adapter,"operation":command.operation})


class WorkHubR4Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/"UE";self.root.mkdir()
        (self.root/"Demo.uproject").write_text("{}",encoding="utf-8")
        docs=self.root/"Docs/Systems/WorldResource";docs.mkdir(parents=True)
        character_docs=self.root/"Docs/Systems/CharacterAnimation";character_docs.mkdir(parents=True)
        (character_docs/"Inside.md").write_text("# CharacterAnimation\ninside",encoding="utf-8")
        (docs/"README.md").write_text(
            "# WorldResource\n\n状态：阶段 16 待 PIE。\n\n"
            "- [交接](SessionHandoff.md)\n"
            "- [旧阶段](Stage15Old.md)\n"
            "- [新阶段](Stage16New.md)\n"
            "- [同工作区上层](../CharacterAnimation/Inside.md)\n"
            "- [越界](../../../../outside.md)\n",encoding="utf-8")
        (docs/"SessionHandoff.md").write_text(
            "# Handoff\n\n## 当前验收缺口与下一步\n1. 先做 PIE 视觉验收。\n2. 然后实现慢走。\n",encoding="utf-8")
        (docs/"Stage15Old.md").write_text("# Stage 15\n旧",encoding="utf-8")
        (docs/"Stage16New.md").write_text("# Stage 16\n## 验证状态\n尚无 PIE。",encoding="utf-8")
        self.service=FakeService(self.root);self.gateway=FakeGateway()
        WorkHubExecutor,_=_load_hub();self.hub=WorkHubExecutor(self.service,self.gateway)
    def tearDown(self):self.tmp.cleanup()

    def cmd(self,operation,args=None,cid="outer"):
        return CommandEnvelope(command_id=cid,workspace="UE58",adapter="work_hub",operation=operation,arguments=args or {},risk=RiskLevel.L2)

    def test_capability_search_unifies_bridge_and_mcp(self):
        r=self.hub.execute(self.cmd("capability.search",{"query":"scene"}))
        self.assertEqual(r.status,ExecutionStatus.SUCCESS)
        targets=[x["target"] for x in r.result["matches"]]
        self.assertIn("bridge:demo:scene.inspect",targets)
        r2=self.hub.execute(self.cmd("capability.search",{"query":"takeover"}))
        self.assertIn("mcp:workspace:UE58:ta:ta_resume",[x["target"] for x in r2.result["matches"]])

    def test_capability_run_routes_bridge_through_service(self):
        r=self.hub.execute(self.cmd("capability.run",{"target":"bridge:demo:scene.write","arguments":{"x":1},"session":"UE-1","project_file":str(self.root/"Demo.uproject")}))
        self.assertEqual(r.status,ExecutionStatus.SUCCESS)
        inner=self.service.executed[-1]
        self.assertEqual((inner.adapter,inner.operation),("demo","scene.write"))
        self.assertEqual(inner.risk,RiskLevel.L2)
        self.assertEqual(inner.session,"UE-1")
        self.assertNotEqual(inner.command_id,"outer")

    def test_capability_run_routes_mcp_and_blocks_recursive_hub(self):
        r=self.hub.execute(self.cmd("capability.run",{"target":"mcp:workspace:UE58:ta:ta_read","arguments":{"path":"A"}}))
        self.assertEqual(r.status,ExecutionStatus.SUCCESS)
        self.assertEqual(self.gateway.calls[-1][1],"ta_read")
        blocked=self.hub.execute(self.cmd("capability.run",{"target":"bridge:work_hub:capability.run","arguments":{}},"recursive"))
        self.assertEqual(blocked.status,ExecutionStatus.DENIED)

    def test_capability_batch_keeps_one_outer_round(self):
        r=self.hub.execute(self.cmd("capability.batch",{"calls":[
            {"target":"bridge:demo:scene.inspect","arguments":{}},
            {"target":"mcp:workspace:UE58:ta:ta_read","arguments":{"path":"B"}},
        ]}))
        self.assertEqual(r.status,ExecutionStatus.SUCCESS)
        self.assertEqual(r.result["count"],2)
        self.assertTrue(r.result["complete"])

    def test_capability_batch_rejects_write_or_session_targets(self):
        r=self.hub.execute(self.cmd("capability.batch",{"calls":[
            {"target":"bridge:demo:scene.write","arguments":{},"session":"UE-1","project_file":str(self.root/"Demo.uproject")},
        ]}))
        self.assertEqual(r.status,ExecutionStatus.DENIED)
        self.assertEqual(r.failure.code,"HUB_BATCH_READ_ONLY_NO_SESSION_REQUIRED")

    def test_project_takeover_prefers_handoff_and_latest_stage_and_blocks_escape(self):
        r=self.hub.execute(self.cmd("project.takeover",{
            "entry_path":"Docs/Systems/WorldResource/README.md",
            "project_key":"bridge_self",
            "max_documents":3,
        }))
        self.assertEqual(r.status,ExecutionStatus.SUCCESS)
        self.assertFalse(r.result["mutation_performed"])
        paths=[x["path"] for x in r.result["documents"]]
        self.assertEqual(paths[0],"Docs/Systems/WorldResource/SessionHandoff.md")
        self.assertIn("Docs/Systems/WorldResource/Stage16New.md",paths)
        self.assertNotIn("Docs/Systems/WorldResource/Stage15Old.md",paths)
        inside=[x for x in r.result["links"] if x.get("link")=="../CharacterAnimation/Inside.md"][0]
        self.assertFalse(inside.get("blocked"))
        self.assertEqual(inside.get("path"),"Docs/Systems/CharacterAnimation/Inside.md")
        self.assertTrue(any(x.get("blocked") for x in r.result["links"]))
        self.assertTrue(any("PIE" in x for x in r.result["next_actions"]))
        self.assertEqual(r.result["live_sessions"][0]["session_id"],"UE-1")
        self.assertTrue(r.result["durable_resume"]["safe_to_continue"])

    def test_descriptor_marks_run_batch_as_orchestrated_writes(self):
        _,descriptor=_load_hub();d=descriptor();by={x.name:x for x in d.capabilities}
        self.assertFalse(by["capability.search"].write)
        self.assertFalse(by["project.takeover"].write)
        self.assertTrue(by["capability.run"].write)
        self.assertTrue(by["capability.run"].manages_checkpoint)
        self.assertFalse(by["capability.batch"].write)

class LaneAndAppR4Tests(unittest.TestCase):
    def test_transport_lanes_are_per_server_or_target(self):
        try:
            from ai_bridge.transport.runner import TransportRunner
        except ImportError as exc:
            self.fail(str(exc))
        a=CommandEnvelope(command_id="a",workspace="UE58",adapter="mcp_gateway",operation="mcp.tool.call",arguments={"server_id":"S1","tool":"x"})
        b=CommandEnvelope(command_id="b",workspace="UE58",adapter="mcp_gateway",operation="mcp.tool.call",arguments={"server_id":"S2","tool":"x"})
        c=CommandEnvelope(command_id="c",workspace="UE58",adapter="mcp_gateway",operation="mcp.tools.list",arguments={"server_id":"S1"})
        self.assertNotEqual(TransportRunner._lane_key(a),TransportRunner._lane_key(b))
        self.assertEqual(TransportRunner._lane_key(a),TransportRunner._lane_key(c))
        h1=CommandEnvelope(command_id="h1",workspace="UE58",adapter="work_hub",operation="capability.run",arguments={"target":"bridge:demo:one"})
        h2=CommandEnvelope(command_id="h2",workspace="UE58",adapter="work_hub",operation="capability.run",arguments={"target":"bridge:demo:two"})
        self.assertNotEqual(TransportRunner._lane_key(h1),TransportRunner._lane_key(h2))
        hs=CommandEnvelope(command_id="hs",workspace="UE58",adapter="work_hub",operation="capability.run",arguments={"target":"bridge:demo:write","session":"UE-1"})
        native=CommandEnvelope(command_id="native",workspace="UE58",adapter="demo",session="UE-1",operation="write")
        self.assertEqual(TransportRunner._lane_key(hs),TransportRunner._lane_key(native))

    def test_build_runtime_registers_hub_and_closes_gateway(self):
        try:
            from ai_bridge.app import build_runtime
        except ImportError as exc:
            self.fail(str(exc))
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as d:
            import os
            old=os.environ.get("AI_BRIDGE_ROOT");os.environ["AI_BRIDGE_ROOT"]=d
            try:
                app,service,connection,state=build_runtime(data_dir=Path(d)/"data",port=9876)
                names={x.adapter for x in service.adapter_registry.list()}
                self.assertIn("mcp_gateway",names);self.assertIn("work_hub",names)
                gateway=app.state.mcp_gateway
                async def cycle():
                    async with app.router.lifespan_context(app):
                        self.assertFalse(gateway.closed)
                    self.assertTrue(gateway.closed)
                asyncio.run(cycle())
            finally:
                if old is None:os.environ.pop("AI_BRIDGE_ROOT",None)
                else:os.environ["AI_BRIDGE_ROOT"]=old

if __name__=="__main__":
    unittest.main()
