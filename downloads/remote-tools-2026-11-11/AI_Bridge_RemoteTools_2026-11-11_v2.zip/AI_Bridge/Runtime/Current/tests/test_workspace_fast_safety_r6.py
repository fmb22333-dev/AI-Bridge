from __future__ import annotations

from ai_bridge.adapters.workspace_worker import WorkspaceWorkerExecutor
from ai_bridge.core.worker_supervisor import WorkerSupervisor
from ai_bridge.core.workspace import WorkspaceRegistry
from ai_bridge.protocol.command import CommandEnvelope
from ai_bridge.protocol.result import ExecutionStatus


def _runtime(tmp_path):
    registry=WorkspaceRegistry()
    registry.register("Dev",tmp_path)
    supervisor=WorkerSupervisor(max_log_lines=16)
    return WorkspaceWorkerExecutor(workspaces=registry,supervisor=supervisor),supervisor


def _cmd(cid,op,args):
    return CommandEnvelope(command_id=cid,workspace="Dev",adapter="workspace",operation=op,arguments=args)


def test_hashless_patch_uses_bridge_guarded_compare_and_swap(tmp_path):
    path=tmp_path/"a.txt"
    path.write_text("alpha old omega\n",encoding="utf-8")
    ex,sup=_runtime(tmp_path)
    try:
        r=ex.execute(_cmd("p1","workspace.file.patch",{
            "path":"a.txt","old_text":"old","new_text":"new"
        }))
        assert r.status==ExecutionStatus.SUCCESS
        assert path.read_text(encoding="utf-8")=="alpha new omega\n"
        assert r.result["guard_mode"]=="bridge_cas"
        assert r.result["caller_expected_hash"] is False
        assert r.result["verified"] is True
    finally:sup.close()


def test_expected_hash_remains_strict_when_caller_supplies_it(tmp_path):
    path=tmp_path/"a.txt"; path.write_text("old",encoding="utf-8")
    ex,sup=_runtime(tmp_path)
    try:
        r=ex.execute(_cmd("p2","workspace.file.patch",{
            "path":"a.txt","expected_hash":"stale","old_text":"old","new_text":"new"
        }))
        assert r.status==ExecutionStatus.CONFLICT
        assert r.failure.code=="EXPECTED_HASH_MISMATCH"
        assert path.read_text(encoding="utf-8")=="old"
    finally:sup.close()


def test_patch_can_apply_multiple_sequential_edits_in_one_call(tmp_path):
    path=tmp_path/"a.txt"; path.write_text("A one B two C\n",encoding="utf-8")
    ex,sup=_runtime(tmp_path)
    try:
        r=ex.execute(_cmd("p3","workspace.file.patch",{
            "path":"a.txt",
            "edits":[
                {"old_text":"one","new_text":"ONE"},
                {"old_text":"two","new_text":"TWO"},
            ],
        }))
        assert r.status==ExecutionStatus.SUCCESS
        assert r.result["applied_edits"]==2
        assert path.read_text(encoding="utf-8")=="A ONE B TWO C\n"
    finally:sup.close()


def test_patch_treats_lf_and_crlf_as_equivalent_without_normalizing_whole_file(tmp_path):
    path=tmp_path/"a.txt"; path.write_bytes(b"line1\r\nold line\r\nline3\r\n")
    ex,sup=_runtime(tmp_path)
    try:
        r=ex.execute(_cmd("p4","workspace.file.patch",{
            "path":"a.txt",
            "old_text":"line1\nold line\n",
            "new_text":"line1\nnew line\n",
        }))
        assert r.status==ExecutionStatus.SUCCESS
        assert path.read_bytes()==b"line1\r\nnew line\r\nline3\r\n"
        assert r.result["newline_equivalent_match"] is True
    finally:sup.close()


def test_hashless_patch_fails_if_file_changes_between_plan_and_commit(tmp_path):
    path=tmp_path/"a.txt"; path.write_text("old",encoding="utf-8")
    ex,sup=_runtime(tmp_path)
    original=ex._atomic_replace_if_unchanged
    def race(target,before_raw,after_raw,*,temp_tag):
        target.write_text("external",encoding="utf-8")
        return original(target,before_raw,after_raw,temp_tag=temp_tag)
    ex._atomic_replace_if_unchanged=race
    try:
        r=ex.execute(_cmd("p5","workspace.file.patch",{
            "path":"a.txt","old_text":"old","new_text":"new"
        }))
        assert r.status==ExecutionStatus.CONFLICT
        assert r.failure.code=="WORKSPACE_FILE_CHANGED_DURING_WRITE"
        assert path.read_text(encoding="utf-8")=="external"
    finally:sup.close()


def test_create_is_idempotent_only_when_existing_bytes_are_identical(tmp_path):
    path=tmp_path/"a.txt"; path.write_text("same\n",encoding="utf-8",newline="")
    ex,sup=_runtime(tmp_path)
    try:
        same=ex.execute(_cmd("c1","workspace.file.create",{"path":"a.txt","text":"same\n"}))
        assert same.status==ExecutionStatus.SUCCESS
        assert same.result["created"] is False
        assert same.result["unchanged"] is True
        different=ex.execute(_cmd("c2","workspace.file.create",{"path":"a.txt","text":"different\n"}))
        assert different.status==ExecutionStatus.CONFLICT
        assert different.failure.code=="WORKSPACE_FILE_ALREADY_EXISTS"
        assert path.read_text(encoding="utf-8")=="same\n"
    finally:sup.close()


def test_fast_patch_still_cannot_touch_bridge_control_files(tmp_path):
    control=tmp_path/".ai-bridge";control.mkdir()
    path=control/"project.json";path.write_text('{"x":1}',encoding="utf-8")
    ex,sup=_runtime(tmp_path)
    try:
        r=ex.execute(_cmd("p6","workspace.file.patch",{
            "path":".ai-bridge/project.json","old_text":"1","new_text":"2"
        }))
        assert r.status==ExecutionStatus.DENIED
        assert r.failure.code=="WORKSPACE_CONTROL_FILE_PROTECTED"
        assert path.read_text(encoding="utf-8")=='{"x":1}'
    finally:sup.close()
