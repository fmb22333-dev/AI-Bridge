﻿param([ValidateSet('backup','cleanup','verify')][string]$Mode,[string]$ProjectFile,[string]$ReportPath,[string]$ScopeFile='',[string]$Selection='',[string]$Revision='',[string]$BackupId='')
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'LandscapeRepair_FileHash.ps1')
$backupProject=[IO.Path]::GetFullPath($ProjectFile)
$backupProjectRoot=Split-Path $backupProject -Parent
$backupStorage=Join-Path $backupProjectRoot 'Backups/AIBridgeMapRepair'
function Backup-Read([string]$Path){if(Test-Path -LiteralPath $Path){return ([IO.File]::ReadAllText($Path)|ConvertFrom-Json)};return $null}
function Backup-Write([string]$Path,$Value){[IO.Directory]::CreateDirectory((Split-Path $Path -Parent))|Out-Null;$temporary=$Path+'.'+[Guid]::NewGuid().ToString('N')+'.tmp';[IO.File]::WriteAllText($temporary,($Value|ConvertTo-Json -Depth 20),[Text.UTF8Encoding]::new($false));Move-Item -LiteralPath $temporary -Destination $Path -Force}
function Backup-Hash([string]$Path){return (Get-AIBridgeFileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Backup-Contained([string]$Base,[string]$Relative){$prefix=[IO.Path]::GetFullPath($Base).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar;$path=[IO.Path]::GetFullPath((Join-Path $Base $Relative));if(!$path.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){throw 'BACKUP_PATH_OUTSIDE_ROOT'};return $path}
function Backup-NoLinks([string]$Path){
 $item=Get-Item -LiteralPath $Path -Force
 if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'BACKUP_REPARSE_POINT_REJECTED'}
 if($item.PSIsContainer){foreach($child in (Get-ChildItem -LiteralPath $Path -Force)){Backup-NoLinks $child.FullName}}
}
function Backup-StorageGuard {
 foreach($segment in @('Backups','Backups/AIBridgeMapRepair','Backups/AIBridgeMapRepair/Snapshots','Backups/AIBridgeMapRepair/Runs')){$path=Join-Path $backupProjectRoot $segment;if(Test-Path -LiteralPath $path){if((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'BACKUP_STORAGE_LINK_REJECTED'}}}
}
function Backup-EditorClosed {
 $processes=@(Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {$_.Name -in @('UnrealEditor.exe','UnrealEditor-Cmd.exe') -and $_.CommandLine -and $_.CommandLine.Replace('/','\').Contains($backupProject.Replace('/','\'))})
 if($processes.Count){throw 'TARGET_UE_PROCESS_RUNNING'}
}
$backupReport=Backup-Read $ReportPath
if(!$backupReport -or $backupReport.job_id -notmatch '^[a-f0-9]{32}$' -or $backupReport.map -notlike '/Game/*'){throw 'BACKUP_REPORT_INVALID'}
if(!$backupReport.PSObject.Properties['phase']){$backupReport|Add-Member -NotePropertyName phase -NotePropertyValue 'preparing'}
Backup-StorageGuard
if($Mode -in @('backup','verify')){Backup-EditorClosed}
try{
 if($Mode -eq 'verify'){
  if($BackupId -notmatch '^[a-f0-9]{32}$'){throw 'BACKUP_VERIFY_ID_INVALID'}
  $directory=Backup-Contained $backupStorage ('Snapshots/'+$BackupId)
  Backup-NoLinks $directory
  $journalPath=Join-Path $directory 'journal.json';$journal=Backup-Read $journalPath
  if(!$journal -or $journal.schema -ne 'landscape_manual_backup/1' -or $journal.project_file -ne $backupProject -or $journal.map -ne $backupReport.map -or !@($journal.packages).Count){throw 'BACKUP_VERIFY_OWNERSHIP_INVALID'}
  $originalReport=Backup-Read (Join-Path $backupProjectRoot ('Saved/AIBridgeLandscapeRepair/Offline/Jobs/'+$BackupId+'/report.json'))
  $expected=@($originalReport.landscape_packages|ForEach-Object {'Content/'+$_.Substring(6)+'.uasset'})
  if(!$expected.Count -or $expected.Count -ne ($originalReport.descriptor_proxy_count+$originalReport.descriptor_parent_count)){throw 'BACKUP_VERIFY_INVENTORY_MISSING'}
  $seen=@{};$verifiedBytes=0L;$changedSources=0
  foreach($entry in $journal.packages){
   if($seen.ContainsKey($entry.relative) -or $entry.original_sha256 -notmatch '^[a-fA-F0-9]{64}$'){throw 'BACKUP_VERIFY_ENTRY_INVALID'}
   $seen[$entry.relative]=$true
   if(!$entry.relative.StartsWith('Content/__ExternalActors__/'+$journal.map.Substring(6)+'/')){throw 'BACKUP_VERIFY_PATH_OUTSIDE_MAP'}
   $copy=Backup-Contained $directory ('original/'+$entry.relative)
   if((Backup-Hash $copy) -ne $entry.original_sha256 -or (Get-Item -LiteralPath $copy).Length -ne [long]$entry.bytes){throw 'BACKUP_VERIFY_HASH_OR_SIZE_MISMATCH'}
   if((Backup-Hash (Backup-Contained $backupProjectRoot $entry.relative)) -ne $entry.original_sha256){$changedSources++}
   $verifiedBytes+=[long]$entry.bytes
  }
  foreach($relative in $expected){if(!$seen.ContainsKey($relative)){throw 'BACKUP_VERIFY_INCOMPLETE_SCOPE'}}
  $journal|Add-Member -NotePropertyName verified_utc -NotePropertyValue ([DateTime]::UtcNow.ToString('o')) -Force
  $journal|Add-Member -NotePropertyName previous_phase -NotePropertyValue $journal.phase -Force
  $journal|Add-Member -NotePropertyName previous_error -NotePropertyValue $journal.error -Force
  $journal.phase='verified';$journal.PSObject.Properties.Remove('error');Backup-Write $journalPath $journal
  $backupReport|Add-Member -NotePropertyName backup_id -NotePropertyValue $BackupId -Force
  $backupReport|Add-Member -NotePropertyName backup_packages -NotePropertyValue @($journal.packages).Count -Force
  $backupReport|Add-Member -NotePropertyName backup_bytes -NotePropertyValue $verifiedBytes -Force
  $backupReport|Add-Member -NotePropertyName changed_source_files -NotePropertyValue $changedSources -Force
  $backupReport|Add-Member -NotePropertyName verification_recovery -NotePropertyValue $true -Force
  $backupReport.phase='backup_verified'
 }elseif($Mode -eq 'cleanup'){
  $ids=@($Selection -split ',' | Sort-Object -Unique)
  if(!$Selection -or $ids.Count -gt 100 -or $Revision -notmatch '^[a-f0-9]{64}$'){throw 'BACKUP_CLEANUP_SELECTION_INVALID'}
  $lastSnapshot=Backup-Read (Join-Path $backupStorage 'last_snapshot.json')
  $lastRun=Backup-Read (Join-Path $backupStorage 'last_run.json')
  $plan=@();$revisionLines=@()
  foreach($id in $ids){
   if($id -notmatch '^(snapshot|repair):([a-f0-9]{32})$'){throw 'BACKUP_ID_INVALID'}
   $kind=$Matches[1];$batch=$Matches[2];$folder=if($kind -eq 'snapshot'){'Snapshots'}else{'Runs'}
   $group=Backup-Contained $backupStorage $folder
   if((Get-Item -LiteralPath $group -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'BACKUP_GROUP_LINK_REJECTED'}
   $directory=Backup-Contained $group $batch
   Backup-NoLinks $directory
   $journalPath=Join-Path $directory 'journal.json';$journal=Backup-Read $journalPath
   $schema=if($kind -eq 'snapshot'){'landscape_manual_backup/1'}else{'landscape_material_transaction/1'}
   if(!$journal -or $journal.schema -ne $schema -or $journal.project_file -ne $backupProject -or $journal.map -ne $backupReport.map){throw 'BACKUP_OWNERSHIP_MISMATCH'}
   if(($kind -eq 'snapshot' -and $lastSnapshot -and $lastSnapshot.backup_id -eq $batch) -or ($kind -eq 'repair' -and $lastRun -and $lastRun.job_id -eq $batch -and $journal.phase -ne 'restored')){throw 'BACKUP_LATEST_RECOVERY_PROTECTED'}
   $files=@(Get-ChildItem -LiteralPath $directory -File -Recurse -Force)
   $size=($files|Measure-Object -Property Length -Sum).Sum
   $revisionLines+=($id+':'+(Backup-Hash $journalPath)+':'+[string][long]$size+':'+[string]$files.Count)
   $plan+=@{id=$id;directory=$directory;bytes=[long]$size;files=$files.Count;kind=$kind;batch=$batch}
  }
  $algorithm=[Security.Cryptography.SHA256]::Create()
  try{$actualRevision=([BitConverter]::ToString($algorithm.ComputeHash([Text.Encoding]::UTF8.GetBytes(($revisionLines -join "`n"))))).Replace('-','').ToLowerInvariant()}finally{$algorithm.Dispose()}
  if($actualRevision -ne $Revision){throw 'BACKUP_SELECTION_CHANGED_REFRESH_REQUIRED'}
  $backupReport|Add-Member -NotePropertyName deleted_backups -NotePropertyValue @() -Force
  $backupReport|Add-Member -NotePropertyName deleted_bytes -NotePropertyValue 0 -Force
  foreach($item in $plan){
   # Resolve and verify every recursive delete target inside this project's owned batch directory.
   $batchFolder=if($item.kind -eq 'snapshot'){'Snapshots'}else{'Runs'}
   $resolved=Backup-Contained $backupStorage ($batchFolder+'/'+$item.batch)
   if($resolved -ne $item.directory){throw 'BACKUP_DELETE_TARGET_CHANGED'}
   Backup-NoLinks $resolved
   Remove-Item -LiteralPath $resolved -Recurse -Force
   $backupReport.deleted_backups+= $item.id;$backupReport.deleted_bytes+=$item.bytes
   Backup-Write $ReportPath $backupReport
   if($item.kind -eq 'repair' -and $lastRun -and $lastRun.job_id -eq $item.batch){Remove-Item -LiteralPath (Join-Path $backupStorage 'last_run.json')}
  }
  $backupReport.phase='backups_cleaned'
 }else{
  $packages=@();$scope='all'
  if($ScopeFile){
   $inputScope=Backup-Read $ScopeFile
   if(!$inputScope -or $inputScope.map -ne $backupReport.map){throw 'BACKUP_SCOPE_MAP_MISMATCH'}
   $packages=@($inputScope.targets|ForEach-Object {$name=[string]$_.package;if(!$name.StartsWith('/Game/')){$name='/Game/'+$name};$name}|Sort-Object -Unique)
   $scope='known'
  }else{
   if(!$backupReport.ok -or $backupReport.action -ne 'inventory' -or $backupReport.descriptor_parent_count -ne 1 -or @($backupReport.landscape_packages).Count -ne ($backupReport.descriptor_proxy_count+1)){throw 'BACKUP_FRESH_INVENTORY_REQUIRED'}
   $packages=@($backupReport.landscape_packages|Sort-Object -Unique)
  }
  if(!$packages.Count){throw 'BACKUP_SCOPE_EMPTY'}
  $relativeMap=$backupReport.map.Substring(6)
  $mapActorPrefix='Content/__ExternalActors__/'+$relativeMap+'/'
  $relativeFiles=@()
  foreach($package in $packages){
   if(!$package.StartsWith('/Game/__ExternalActors__/'+$relativeMap+'/')){throw 'BACKUP_PACKAGE_OUTSIDE_MAP'}
   $relative='Content/'+$package.Substring(6)+'.uasset'
   if(!$relative.StartsWith($mapActorPrefix)){throw 'BACKUP_PACKAGE_PATH_INVALID'}
   $source=Backup-Contained $backupProjectRoot $relative
   if(!(Test-Path -LiteralPath $source -PathType Leaf)){throw 'BACKUP_SOURCE_MISSING'}
   $relativeFiles+=$relative
   foreach($extension in @('.uexp','.ubulk','.uptnl')){if(Test-Path -LiteralPath ([IO.Path]::ChangeExtension($source,$extension))){$relativeFiles+=[IO.Path]::ChangeExtension($relative,$extension)}}
  }
  $batch=$backupReport.job_id;$directory=Backup-Contained $backupStorage ('Snapshots/'+$batch)
  if(Test-Path -LiteralPath $directory){throw 'BACKUP_BATCH_ALREADY_EXISTS'}
  [IO.Directory]::CreateDirectory($directory)|Out-Null
  $journalPath=Join-Path $directory 'journal.json'
  $journal=[ordered]@{schema='landscape_manual_backup/1';backup_id=$batch;project_file=$backupProject;map=$backupReport.map;scope=$scope;created_utc=[DateTime]::UtcNow.ToString('o');phase='copying';packages=@()}
  Backup-Write $journalPath $journal
  foreach($relative in ($relativeFiles|Sort-Object -Unique)){
   $source=Backup-Contained $backupProjectRoot $relative
   $target=Backup-Contained $directory ('original/'+$relative)
   $hash=Backup-Hash $source
   [IO.Directory]::CreateDirectory((Split-Path $target -Parent))|Out-Null
   Copy-Item -LiteralPath $source -Destination $target
   if((Backup-Hash $target) -ne $hash -or (Backup-Hash $source) -ne $hash){throw 'BACKUP_COPY_VERIFY_FAILED'}
   $journal.packages+=@{relative=$relative;original_sha256=$hash;bytes=(Get-Item -LiteralPath $target).Length;phase='backed_up'}
   Backup-Write $journalPath $journal
  }
  Backup-EditorClosed
  foreach($entry in $journal.packages){if((Backup-Hash (Backup-Contained $backupProjectRoot $entry.relative)) -ne $entry.original_sha256){throw 'BACKUP_SOURCE_CHANGED_DURING_BATCH'}}
  $verifiedBytes=0L;foreach($entry in $journal.packages){$verifiedBytes+=[long]$entry.bytes}
  $journal.phase='verified';Backup-Write $journalPath $journal
  $backupReport|Add-Member -NotePropertyName backup_id -NotePropertyValue $batch -Force
  $backupReport|Add-Member -NotePropertyName backup_packages -NotePropertyValue $journal.packages.Count -Force
  $backupReport|Add-Member -NotePropertyName backup_bytes -NotePropertyValue $verifiedBytes -Force
  $backupReport.phase='backup_verified'
 }
 $backupReport.action=if($Mode -eq 'cleanup'){'backup_cleanup'}else{'material_backup'}
 $backupReport.ok=$true;$backupReport|Add-Member -NotePropertyName map_saved -NotePropertyValue $false -Force
 $backupReport|Add-Member -NotePropertyName finished_utc -NotePropertyValue ([DateTime]::UtcNow.ToString('o')) -Force
 Backup-Write $ReportPath $backupReport
 if($Mode -in @('backup','verify')){Backup-Write (Join-Path $backupStorage 'last_snapshot.json') @{backup_id=$backupReport.backup_id;map=$backupReport.map}}
}catch{
 if($journalPath -and $Mode -eq 'backup' -and $journal){$journal.phase='failed';$journal['error']=$_.Exception.Message;Backup-Write $journalPath $journal}
 $backupReport.ok=$false;$backupReport.phase='failed';$backupReport|Add-Member -NotePropertyName error -NotePropertyValue $_.Exception.Message -Force;Backup-Write $ReportPath $backupReport
 throw
}
