# Keep maintenance hashing independent of PowerShell module autoloading.
function Get-AIBridgeFileHash {
 param([Parameter(Mandatory=$true,Position=0)][Alias('Path')][string]$LiteralPath,[ValidateSet('SHA1','SHA256')][string]$Algorithm='SHA256')
 $filePath=[IO.Path]::GetFullPath($LiteralPath)
 $stream=[IO.File]::Open($filePath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
 $algorithmInstance=if($Algorithm -eq 'SHA1'){[Security.Cryptography.SHA1]::Create()}else{[Security.Cryptography.SHA256]::Create()}
 try{
  [pscustomobject]@{Algorithm=$Algorithm;Hash=([BitConverter]::ToString($algorithmInstance.ComputeHash($stream))).Replace('-','');Path=$filePath}
 }finally{$algorithmInstance.Dispose();$stream.Dispose()}
}
