﻿param([ValidateSet('install','restore')][string]$Mode,[string]$ProjectFile,[string]$ReportPath,[string]$BackupRoot='',[switch]$ResumeBackup)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'LandscapeRepair_FileHash.ps1')
$materialProjectRoot = [IO.Path]::GetFullPath((Split-Path ([IO.Path]::GetFullPath($ProjectFile)) -Parent))
if (!$BackupRoot) { $BackupRoot = Join-Path $materialProjectRoot 'Backups/AIBridgeMapRepair' }
$materialBackupRoot = [IO.Path]::GetFullPath($BackupRoot)
function Read-MaterialJson([string]$Path) { return ([IO.File]::ReadAllText($Path) | ConvertFrom-Json) }
function Write-MaterialJson([string]$Path,$Value) {
    [IO.Directory]::CreateDirectory((Split-Path $Path -Parent)) | Out-Null
    $tempPath=$Path+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
    [IO.File]::WriteAllText($tempPath,($Value|ConvertTo-Json -Depth 20),[Text.UTF8Encoding]::new($false))
    $oldPath=$tempPath+'.old'
    $published=$false
    try {
        for ($attempt=0; $attempt -lt 20; ++$attempt) {
            try {
                # Replace atomically; Web readers can briefly deny Windows delete sharing.
                if ([IO.File]::Exists($Path)) { [IO.File]::Replace($tempPath,$Path,$oldPath) }
                else { [IO.File]::Move($tempPath,$Path) }
                $published=$true; break
            } catch [IO.IOException] {
                if (![IO.File]::Exists($tempPath) -or $attempt -eq 19) { throw }
                Start-Sleep -Milliseconds 100
            }
        }
    } finally {
        if ($published -and [IO.File]::Exists($oldPath)) {
            try { [IO.File]::Delete($oldPath) } catch [IO.IOException] { }
        }
    }
}
function Resolve-MaterialContained([string]$Base,[string]$Relative) {
    $basePath=[IO.Path]::GetFullPath($Base).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
    $resolved=[IO.Path]::GetFullPath((Join-Path $Base $Relative))
    if (!$resolved.StartsWith($basePath,[StringComparison]::OrdinalIgnoreCase)) { throw 'MATERIAL_PATH_OUTSIDE_ROOT' }
    return $resolved
}
function Material-Hash([string]$Path,[string]$Algorithm='SHA256') { return (Get-AIBridgeFileHash -LiteralPath $Path -Algorithm $Algorithm).Hash }
function Replace-MaterialFile([string]$Source,[string]$Destination,[string]$ExpectedHash,[string]$ReplacementHash) {
    if ((Material-Hash $Destination) -ne $ExpectedHash) { throw 'MATERIAL_PACKAGE_CHANGED_BEFORE_REPLACE' }
    $temporary=$Destination+'.maprepair-'+[Guid]::NewGuid().ToString('N')+'.tmp'
    $replacementBackup=$temporary+'.old'
    try {
        Copy-Item -LiteralPath $Source -Destination $temporary
        if ((Material-Hash $temporary) -ne $ReplacementHash -or (Material-Hash $Destination) -ne $ExpectedHash) { throw 'MATERIAL_REPLACEMENT_HASH_MISMATCH' }
        # PowerShell can bind $null to an empty string for File.Replace's backup path.
        # Use an owned sibling file; the durable original backup was already verified.
        [IO.File]::Replace($temporary,$Destination,$replacementBackup)
        if ((Material-Hash $Destination) -ne $ReplacementHash) { throw 'MATERIAL_REPLACE_RESULT_UNKNOWN' }
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary }
        if (Test-Path -LiteralPath $replacementBackup) { Remove-Item -LiteralPath $replacementBackup }
    }
}
$materialReport=Read-MaterialJson $ReportPath
if ($Mode -eq 'restore') {
    $pointer=Read-MaterialJson (Join-Path $materialBackupRoot 'last_run.json')
    if ($pointer.job_id -notmatch '^[a-fA-F0-9]{32}$') { throw 'MATERIAL_RESTORE_BATCH_INVALID' }
    $runDirectory=Resolve-MaterialContained $materialBackupRoot ('Runs/'+$pointer.job_id)
    $journalPath=Join-Path $runDirectory 'journal.json'
    $journal=Read-MaterialJson $journalPath
    if ($journal.project_file -ne [IO.Path]::GetFullPath($ProjectFile) -or $journal.map -ne $materialReport.map) { throw 'MATERIAL_RESTORE_PROJECT_OR_MAP_MISMATCH' }
    # Reconcile actual hashes; a crash may have happened after replacement and before journal persistence.
    foreach ($entry in @($journal.packages)) {
        if ($entry.relative -notlike 'Content/__ExternalActors__/*.uasset') { throw 'MATERIAL_RESTORE_PATH_INVALID' }
        $target=Resolve-MaterialContained $materialProjectRoot $entry.relative
        $backup=Resolve-MaterialContained $runDirectory ('original/'+$entry.relative)
        $current=Material-Hash $target
        if ($current -ne $entry.original_sha256 -and $current -ne $entry.staged_sha256) { throw ('MATERIAL_RESTORE_CONFLICT: '+$entry.relative) }
        if ((Material-Hash $backup) -ne $entry.original_sha256) { throw 'MATERIAL_BACKUP_HASH_MISMATCH' }
    }
    $restored=0
    foreach ($entry in @($journal.packages)) {
        $target=Resolve-MaterialContained $materialProjectRoot $entry.relative
        if ((Material-Hash $target) -ne $entry.original_sha256) {
            Replace-MaterialFile (Resolve-MaterialContained $runDirectory ('original/'+$entry.relative)) $target $entry.staged_sha256 $entry.original_sha256
            ++$restored
        }
        $entry.phase='restored'; Write-MaterialJson $journalPath $journal
    }
    $journal.phase='restored'; Write-MaterialJson $journalPath $journal
    $materialReport.ok=$true; $materialReport.map_saved=($restored -gt 0)
    $materialReport | Add-Member -NotePropertyName restored_packages -NotePropertyValue $restored -Force
    $materialReport | Add-Member -NotePropertyName restored_job_id -NotePropertyValue $pointer.job_id -Force
    $materialReport.phase='restored'; Write-MaterialJson $ReportPath $materialReport
    return
}
if (!$materialReport.ok -or $materialReport.phase -ne 'staged_not_installed' -or $materialReport.action -notin @('material_repair','grass_repair')) { throw 'MATERIAL_STAGING_NOT_VERIFIED' }
if ($materialReport.job_id -notmatch '^[a-fA-F0-9]{32}$') { throw 'MATERIAL_BATCH_INVALID' }
if (@($materialReport.packages).Count -eq 0) {
    $materialReport.phase='no_changes'; Write-MaterialJson $ReportPath $materialReport; return
}
$runDirectory=Resolve-MaterialContained $materialBackupRoot ('Runs/'+$materialReport.job_id)
$journalPath=Join-Path $runDirectory 'journal.json'
$priorJournal=$null
if (Test-Path -LiteralPath $journalPath) {
    if (!$ResumeBackup) { throw 'MATERIAL_BATCH_ALREADY_STARTED: reconcile journal before replay' }
    $priorJournal=Read-MaterialJson $journalPath
    if ($priorJournal.schema -ne 'landscape_material_transaction/1' -or $priorJournal.phase -ne 'backing_up' -or
        $priorJournal.job_id -ne $materialReport.job_id -or $priorJournal.project_file -ne [IO.Path]::GetFullPath($ProjectFile) -or
        $priorJournal.map -ne $materialReport.map) { throw 'MATERIAL_BACKUP_RESUME_STATE_INVALID' }
} elseif ($ResumeBackup) { throw 'MATERIAL_BACKUP_RESUME_NOT_FOUND' }
$stageDirectory=Resolve-MaterialContained $materialProjectRoot ('Saved/AIBridgeLandscapeRepair/Offline/Jobs/'+$materialReport.job_id+'/material-staged')
$journal=[ordered]@{schema='landscape_material_transaction/1';action=$materialReport.action;job_id=$materialReport.job_id;project_file=[IO.Path]::GetFullPath($ProjectFile);map=$materialReport.map;phase='backing_up';packages=@()}
$seen=@{}
foreach ($entry in @($materialReport.packages)) {
    if ($entry.relative -notlike 'Content/__ExternalActors__/*.uasset' -or $seen.ContainsKey($entry.relative)) { throw 'MATERIAL_PACKAGE_PATH_INVALID_OR_DUPLICATE' }
    $seen[$entry.relative]=$true
    $target=Resolve-MaterialContained $materialProjectRoot $entry.relative
    $staged=Resolve-MaterialContained $stageDirectory $entry.relative
    if ([IO.Path]::GetFullPath($entry.staged) -ne $staged -or (Material-Hash $target 'SHA1') -ne $entry.original_sha1 -or (Material-Hash $staged 'SHA1') -ne $entry.staged_sha1) { throw 'MATERIAL_STAGING_INPUT_CHANGED' }
    $journal.packages+= [ordered]@{relative=$entry.relative;original_sha256=(Material-Hash $target);staged_sha256=(Material-Hash $staged);phase='pending'}
}
if ($priorJournal) {
    if (@($priorJournal.packages).Count -ne $journal.packages.Count) { throw 'MATERIAL_BACKUP_RESUME_SCOPE_CHANGED' }
    $priorEntries=@{}
    foreach ($entry in @($priorJournal.packages)) {
        if ($priorEntries.ContainsKey($entry.relative) -or $entry.phase -notin @('pending','backed_up')) { throw 'MATERIAL_BACKUP_RESUME_ENTRY_INVALID' }
        $priorEntries[$entry.relative]=$entry
    }
    foreach ($entry in $journal.packages) {
        $prior=$priorEntries[$entry.relative]
        if (!$prior -or $prior.original_sha256 -ne $entry.original_sha256 -or $prior.staged_sha256 -ne $entry.staged_sha256) { throw 'MATERIAL_BACKUP_RESUME_INPUT_CHANGED' }
        $backup=Resolve-MaterialContained $runDirectory ('original/'+$entry.relative)
        if (Test-Path -LiteralPath $backup) {
            if ((Material-Hash $backup) -ne $entry.original_sha256) { throw 'MATERIAL_BACKUP_RESUME_HASH_MISMATCH' }
            $entry.phase='backed_up'
        } elseif ($prior.phase -eq 'backed_up') { throw 'MATERIAL_BACKUP_RESUME_FILE_MISSING' }
    }
    $historyPath=Join-Path $runDirectory 'journal-before-resume.json'
    if (!(Test-Path -LiteralPath $historyPath)) { Copy-Item -LiteralPath $journalPath -Destination $historyPath }
    $journal.resumed_utc=[DateTime]::UtcNow.ToString('o')
    $journal.resume_count=([int]$priorJournal.resume_count)+1
}
Write-MaterialJson $journalPath $journal
foreach ($entry in $journal.packages) {
    $backup=Resolve-MaterialContained $runDirectory ('original/'+$entry.relative)
    [IO.Directory]::CreateDirectory((Split-Path $backup -Parent)) | Out-Null
    if ($entry.phase -ne 'backed_up') { Copy-Item -LiteralPath (Resolve-MaterialContained $materialProjectRoot $entry.relative) -Destination $backup }
    if ((Material-Hash $backup) -ne $entry.original_sha256) { throw 'MATERIAL_BACKUP_VERIFY_FAILED' }
    $entry.phase='backed_up'; Write-MaterialJson $journalPath $journal
}
$journal.phase='backups_verified'; Write-MaterialJson $journalPath $journal
Write-MaterialJson (Join-Path $materialBackupRoot 'last_run.json') @{job_id=$journal.job_id;map=$journal.map}
try {
    foreach ($entry in $journal.packages) {
        $entry.phase='installing'; Write-MaterialJson $journalPath $journal
        Replace-MaterialFile (Resolve-MaterialContained $stageDirectory $entry.relative) (Resolve-MaterialContained $materialProjectRoot $entry.relative) $entry.original_sha256 $entry.staged_sha256
        $entry.phase='installed'; Write-MaterialJson $journalPath $journal
    }
    $journal.phase='installed'; Write-MaterialJson $journalPath $journal
    $materialReport.phase='installed'; $materialReport.map_saved=$true
    $materialReport | Add-Member -NotePropertyName installed_utc -NotePropertyValue ([DateTime]::UtcNow.ToString('o')) -Force
    $materialReport | Add-Member -NotePropertyName backup_journal -NotePropertyValue $journalPath -Force
    Write-MaterialJson $ReportPath $materialReport
} catch {
    $journal.phase='failed_requires_reconciliation'; $journal['error']=$_.Exception.Message
    Write-MaterialJson $journalPath $journal
    $materialReport.ok=$false; $materialReport.phase='failed_requires_reconciliation'
    $materialReport | Add-Member -NotePropertyName error -NotePropertyValue $_.Exception.Message -Force
    $materialReport | Add-Member -NotePropertyName backup_journal -NotePropertyValue $journalPath -Force
    Write-MaterialJson $ReportPath $materialReport
    throw
}
