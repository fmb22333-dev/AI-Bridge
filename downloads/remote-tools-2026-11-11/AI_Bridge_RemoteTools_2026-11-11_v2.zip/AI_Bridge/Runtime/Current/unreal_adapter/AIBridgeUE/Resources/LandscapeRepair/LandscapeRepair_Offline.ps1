﻿param([ValidateSet('inventory','scan','repair','normalize','verify','status','material_scan','material_repair','grass_scan','grass_repair','material_restore','material_backup','backup_cleanup')][string]$Action='status',[switch]$ScheduledWorker,[string]$ProjectFile='',[string]$Map='',[int]$ExpectedProxies=0,[string]$EditorExecutable='',[string]$MaterialTargets='',[switch]$MaterialPrepareOnly,[switch]$GrassProbeBaseline,[string]$BackupSelection='',[string]$BackupRevision='',[string]$BackupVerifyId='',[ValidateRange(0,1024)][double]$MemoryBudgetGiB=0,[ValidateRange(1,128)][double]$ReservePhysicalGiB=8,[ValidateRange(1,128)][double]$ReserveCommitGiB=8,[ValidateRange(1,16)][int]$MaterialBatchProxies=16)
$ErrorActionPreference='Stop'
if([string]::IsNullOrWhiteSpace($ProjectFile)){throw 'PROJECT_FILE_REQUIRED'}
$project=[IO.Path]::GetFullPath($ProjectFile)
$root=[IO.Path]::GetFullPath((Split-Path $project -Parent))
if([string]::IsNullOrWhiteSpace($Map)){throw 'MAP_REQUIRED'}
$map=$Map
$expectedProxyCount=if($ExpectedProxies -ge 0){$ExpectedProxies}else{0}
if([string]::IsNullOrWhiteSpace($EditorExecutable)){throw 'EDITOR_EXECUTABLE_REQUIRED'}
$editorExe=[IO.Path]::GetFullPath($EditorExecutable)
$engine=Split-Path (Split-Path (Split-Path $editorExe -Parent) -Parent) -Parent
if($Action -in @('scan','repair','normalize','verify','material_scan','material_repair','grass_scan','grass_repair','material_restore','material_backup','backup_cleanup') -and !$ScheduledWorker){
 if($MaterialTargets -or $MaterialPrepareOnly){throw 'MATERIAL_SCOPED_PREPARATION_REQUIRES_DIRECT_WORKER'}
 $launch=@{Mode='launch';Action=$Action;ProjectFile=$project;Map=$map;ExpectedProxies=$expectedProxyCount;EditorExecutable=$editorExe}
 if($Action -in @('material_scan','material_repair','grass_scan','grass_repair')){$launch.MemoryBudgetGiB=$MemoryBudgetGiB;$launch.ReservePhysicalGiB=$ReservePhysicalGiB;$launch.ReserveCommitGiB=$ReserveCommitGiB;$launch.MaterialBatchProxies=$MaterialBatchProxies}
 if($Action -eq 'backup_cleanup'){$launch.BackupSelection=$BackupSelection;$launch.BackupRevision=$BackupRevision}
 & (Join-Path $PSScriptRoot 'LandscapeRepair_ScheduledJob.ps1') @launch
 exit 0
}
$out=Join-Path $root 'Saved/AIBridgeLandscapeRepair/Offline'
[IO.Directory]::CreateDirectory($out)|Out-Null
function Write-Json($p,$v){[IO.Directory]::CreateDirectory((Split-Path $p -Parent))|Out-Null;[IO.File]::WriteAllText(($p+'.tmp'),($v|ConvertTo-Json -Depth 14),[Text.UTF8Encoding]::new($false));Move-Item ($p+'.tmp') $p -Force}
function Assert-Closed {
 $p=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -in @('UnrealEditor.exe','UnrealEditor-Cmd.exe') -and $_.CommandLine -and $_.CommandLine.Replace('/','\').Contains($project.Replace('/','\'))})
 if($p.Count){throw 'TARGET_UE_PROCESS_RUNNING: do not overlap offline jobs or the GUI editor'}
}
function Invoke-MaterialBatches {
 . (Join-Path $PSScriptRoot 'LandscapeRepair_FileHash.ps1')
 $masterReport=Join-Path $dir 'report.json'
 $aggregate=[ordered]@{schema_version=$(if($Action.StartsWith('grass_')){'landscape_grass_repair/1'}else{'landscape_material_repair/1'});job_id=$job;action=$Action;map=$map;phase='preparing_batches';ok=$false;map_saved=$false;recurrence_verified=$false;started_utc=[DateTime]::UtcNow.ToString('o');loaded_proxies=0;selected_components=0;candidate_components=0;removed_allocations=0;staged_packages=0;batches_completed=0;peak_private_bytes=0;components=@();packages=@();batches=@();input_packages=@()}
 $offset=0;$batchLimit=$MaterialBatchProxies;$total=$null;$inputs=@{};$seen=@{}
 $script:materialBatchExit=0
 Write-Json $masterReport $aggregate
 while($null -eq $total -or $offset -lt $total){
  Assert-Closed
  $child=[Guid]::NewGuid().ToString('N');$childDir=Join-Path $out ('Jobs/'+$child)
  [IO.Directory]::CreateDirectory($childDir)|Out-Null
  $childArgs=@($argv|Where-Object {$_ -notlike '-RepairJob=*' -and $_ -notlike '-log=*'})
  $childArgs+=@(('-RepairJob='+$child),('-log='+$childDir+'/worker.log'),('-MaterialBatchOffset='+$offset),('-MaterialBatchLimit='+$batchLimit))
  $aggregate.current_batch_job=$child;$aggregate.batch_size=$batchLimit
  Write-Json $masterReport $aggregate
  & (Join-Path $engine 'Binaries/Win64/UnrealEditor-Cmd.exe') @childArgs 2>&1 | Tee-Object (Join-Path $childDir 'stdout.log') | Tee-Object (Join-Path $dir 'stdout.log') -Append
  $nativeExit=$LASTEXITCODE
  $childReport=Join-Path $childDir 'report.json'
  $native=if(Test-Path -LiteralPath $childReport){Get-Content -LiteralPath $childReport -Raw|ConvertFrom-Json}else{$null}
  $aggregate.batches+=@{job_id=$child;offset=$offset;limit=$batchLimit;exit_code=$nativeExit;ok=[bool]($native -and $native.ok);error=if($native){$native.error}else{'OFFLINE_BATCH_REPORT_MISSING'}}
  if($native){
   $aggregate.peak_private_bytes=[Math]::Max([double]$aggregate.peak_private_bytes,[double]$native.peak_private_bytes)
   $aggregate.current_private_bytes=$native.current_private_bytes;$aggregate.shader_cache_mode=$native.shader_cache_mode
   $aggregate.available_physical_bytes=$native.available_physical_bytes;$aggregate.map_load_error_count=$native.map_load_error_count
   $aggregate.memory_budget_bytes=$native.memory_budget_bytes;$aggregate.reserve_physical_bytes=$native.reserve_physical_bytes;$aggregate.reserve_commit_bytes=$native.reserve_commit_bytes
   $aggregate.available_commit_bytes=$native.available_commit_bytes;$aggregate.memory_guard_reason=$native.memory_guard_reason
  }
  if($nativeExit -ne 0 -or !$native -or !$native.ok){
   if($native -and $native.error -eq 'MATERIAL_MEMORY_GUARD' -and $batchLimit -gt 1){
    $batchLimit=[Math]::Max(1,[int][Math]::Floor($batchLimit/2));$aggregate.last_retry_reason='MATERIAL_MEMORY_GUARD';Write-Json $masterReport $aggregate;continue
   }
   $aggregate.error=if($native -and $native.error){$native.error}else{'OFFLINE_BATCH_FAILED'}
   $aggregate.failed_batch_job=$child;$aggregate.phase='batch_failed';$aggregate.finished_utc=[DateTime]::UtcNow.ToString('o')
   if($native){$aggregate.error_component=$native.error_component;$aggregate.error_package=$native.error_package;$aggregate.components+=@($native.components)}
   Write-Json $masterReport $aggregate;$script:materialBatchExit=1;return
  }
  if($native.phase -ne 'batch_staged_not_installed' -or $native.map_saved -or [int]$native.batch_offset -ne $offset -or [int]$native.loaded_proxies -le 0){throw 'MATERIAL_BATCH_RECEIPT_INVALID'}
  if($null -eq $total){
   $total=[int]$native.total_scope_proxy_count
   foreach($inputPackage in $native.input_packages){if($inputs.ContainsKey($inputPackage.package)){throw 'MATERIAL_BATCH_DUPLICATE_INPUT'};$inputs[$inputPackage.package]=[string]$inputPackage.original_sha1}
   if($total -ne $inputs.Count){throw 'MATERIAL_BATCH_INPUT_COVERAGE_INVALID'}
   $aggregate.scope_proxy_count=$total;$aggregate.descriptor_proxy_count=$native.descriptor_proxy_count;$aggregate.input_packages=@($native.input_packages)
  }else{
   if($total -ne [int]$native.total_scope_proxy_count -or @($native.input_packages).Count -ne $inputs.Count){throw 'MATERIAL_BATCH_SCOPE_CHANGED'}
   foreach($inputPackage in $native.input_packages){if(!$inputs.ContainsKey($inputPackage.package) -or $inputs[$inputPackage.package] -ne $inputPackage.original_sha1){throw 'MATERIAL_BATCH_INPUT_CHANGED'}}
  }
  $processed=@($native.components|Select-Object -ExpandProperty package -Unique)
  if($processed.Count -ne [int]$native.loaded_proxies -or [int]$native.loaded_proxies -gt $batchLimit){throw 'MATERIAL_BATCH_COMPONENT_COVERAGE_INVALID'}
  foreach($packageName in $processed){if($seen.ContainsKey($packageName) -or !$inputs.ContainsKey($packageName)){throw 'MATERIAL_BATCH_PACKAGE_COVERAGE_INVALID'};$seen[$packageName]=$true}
  foreach($entry in @($native.packages)){
   if($entry.relative -notlike 'Content/__ExternalActors__/*.uasset' -or $entry.relative.Contains('..') -or [IO.Path]::IsPathRooted($entry.relative)){throw 'MATERIAL_BATCH_STAGED_PATH_INVALID'}
   $source=[IO.Path]::GetFullPath((Join-Path (Join-Path $childDir 'material-staged') $entry.relative))
   $destination=[IO.Path]::GetFullPath((Join-Path (Join-Path $dir 'material-staged') $entry.relative))
   if([IO.Path]::GetFullPath($entry.staged) -ne $source -or !$source.StartsWith([IO.Path]::GetFullPath($childDir)+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or !$destination.StartsWith([IO.Path]::GetFullPath($dir)+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'MATERIAL_BATCH_STAGED_PATH_OUTSIDE_JOB'}
   if((Get-AIBridgeFileHash $source -Algorithm SHA1).Hash -ne $entry.staged_sha1){throw 'MATERIAL_BATCH_STAGED_HASH_MISMATCH'}
   [IO.Directory]::CreateDirectory((Split-Path $destination -Parent))|Out-Null
   if(Test-Path -LiteralPath $destination){throw 'MATERIAL_BATCH_DUPLICATE_STAGED_PACKAGE'}
   Copy-Item -LiteralPath $source -Destination $destination
   if((Get-AIBridgeFileHash $destination -Algorithm SHA1).Hash -ne $entry.staged_sha1){throw 'MATERIAL_BATCH_COPY_HASH_MISMATCH'}
   $aggregate.packages+=@{relative=$entry.relative;original_sha1=$entry.original_sha1;staged=$destination;staged_sha1=$entry.staged_sha1}
  }
  $aggregate.components+=@($native.components)
  $aggregate.loaded_proxies+=[int]$native.loaded_proxies;$aggregate.selected_components+=[int]$native.selected_components
  $aggregate.candidate_components+=[int]$native.candidate_components;$aggregate.removed_allocations+=[int]$native.removed_allocations
  $aggregate.staged_packages=$aggregate.packages.Count;$aggregate.batches_completed++
  $offset+=[int]$native.loaded_proxies
  Write-Json $masterReport $aggregate
 }
 if($seen.Count -ne $total -or $aggregate.loaded_proxies -ne $total){throw 'MATERIAL_BATCH_FINAL_COVERAGE_INVALID'}
 $aggregate.phase='staged_not_installed';$aggregate.ok=$true;$aggregate.finished_utc=[DateTime]::UtcNow.ToString('o')
 Write-Json $masterReport $aggregate
}
if($Action -eq 'status'){
 $diagnostic=[ordered]@{utc=[DateTime]::UtcNow.ToString('o')}
 # Keep status independent of WMI/CIM, which timed out in the preceding resume.
 $diagnostic.processes=@(Get-Process -Name UnrealEditor,UnrealEditor-Cmd -ErrorAction SilentlyContinue | ForEach-Object {[ordered]@{pid=$_.Id;name=$_.ProcessName;private_bytes=$_.PrivateMemorySize64;working_set=$_.WorkingSet64;executable=$_.Path}})
 Write-Json (Join-Path $out 'status_progress.json') @{phase='processes_read';diagnostic=$diagnostic}
 $jp=Join-Path $out 'last_job.json';if(Test-Path $jp){$jobState=Get-Content $jp -Raw|ConvertFrom-Json;$log=Join-Path $out ('Jobs/'+$jobState.job_id+'/worker.log');if(!(Test-Path $log)){$log=Join-Path $out ('Jobs/'+$jobState.job_id+'/stdout.log')};if(Test-Path $log){$diagnostic.log_bytes=(Get-Item $log).Length;$stream=[IO.File]::Open($log,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite);try{$count=[int][Math]::Min(65536L,$stream.Length);$buffer=New-Object byte[] $count;[void]$stream.Seek(-$count,[IO.SeekOrigin]::End);$read=$stream.Read($buffer,0,$count);$encoding=[Text.Encoding]::UTF8;if($read -ge 4 -and $buffer[1] -eq 0 -and $buffer[3] -eq 0){$encoding=[Text.Encoding]::Unicode};$tail=@(($encoding.GetString($buffer,0,$read) -split '
?
')|Select-Object -Last 128)}finally{$stream.Dispose()};$diagnostic.log_tail=@($tail|Select-Object -Last 16);$diagnostic.recent_log_errors=@($tail|Select-String -Pattern ': Error:|Fatal error:|Commandlet->Main|Failure -|Success -' | Select-Object -Last 24 | ForEach-Object {$_.Line})}}
 Write-Json (Join-Path $out 'status_progress.json') @{phase='log_tail_read';diagnostic=$diagnostic}
 $ip=Join-Path $out 'inventory_pointer.json';$dp=Join-Path $out 'disk_delta.json';if((Test-Path $ip) -and (Test-Path $dp)){
  $inv=Get-Content ((Get-Content $ip -Raw|ConvertFrom-Json).report) -Raw|ConvertFrom-Json;$delta=Get-Content $dp -Raw|ConvertFrom-Json
  $set=@{};foreach($pkg in $inv.landscape_packages){$set[('Content/'+$pkg.Substring(6)+'.uasset')]=$true}
  $terrain=@($delta.changed|Where-Object {$set.ContainsKey($_.relative.Replace('\','/'))});$diagnostic.changed_landscape_count=$terrain.Count;$diagnostic.changed_other_count=$delta.changed.Count-$terrain.Count;$diagnostic.changed_parent=@($terrain|Where-Object {$_.relative -like '*BD3WB5VDY56KJ3Z4LR7FD9.uasset'})
  $diagnostic.descriptor_parents=$inv.descriptor_parent_count;$diagnostic.descriptor_proxies=$inv.descriptor_proxy_count
 }
 Write-Json (Join-Path $out 'diagnostic.json') $diagnostic
 # Keep transport output bounded; raw log diagnostics remain in diagnostic.json.
 [pscustomobject]$diagnostic|Select-Object utc,processes,log_bytes,descriptor_parents,descriptor_proxies|ConvertTo-Json -Depth 5 -Compress
 $p=Join-Path $out 'last_job.json';if(Test-Path $p){$j=Get-Content $p -Raw|ConvertFrom-Json;$r=Join-Path $out ('Jobs/'+$j.job_id+'/report.json');if(Test-Path $r){$v=Get-Content $r -Raw|ConvertFrom-Json;[ordered]@{job_id=$j.job_id;action=$j.action;ok=$v.ok;error=$v.error;run_id=$v.run_id;last_step=$v.last_step;private_bytes=$v.private_bytes;peak_private_bytes=$v.peak_private_bytes;map_saved=$v.map_saved;scan=$v.scan|Select-Object ready_to_apply,missing_final_snapshots,recoverable_components,data_error,component_count,loaded_proxy_count,layer_policy_error}|ConvertTo-Json -Depth 5 -Compress}else{$j|ConvertTo-Json -Compress}}
 & (Join-Path $PSScriptRoot 'LandscapeRepair_ReadOfflineProgress.ps1') -ProjectFile $project
 exit 0
}
if($Action -ne 'backup_cleanup'){Assert-Closed}
$job=[Guid]::NewGuid().ToString('N');$dir=Join-Path $out ('Jobs/'+$job);[IO.Directory]::CreateDirectory($dir)|Out-Null
if($Action -eq 'backup_cleanup' -or ($Action -eq 'material_backup' -and ($MaterialTargets -or $BackupVerifyId))){
 Write-Json (Join-Path $out 'last_job.json') @{job_id=$job;action=$Action;phase='running'}
 $backupReport=Join-Path $dir 'report.json'
 Write-Json $backupReport @{job_id=$job;action=$Action;map=$map;ok=$false;map_saved=$false;phase='preparing';started_utc=[DateTime]::UtcNow.ToString('o')}
 if($Action -eq 'backup_cleanup'){& (Join-Path $PSScriptRoot 'LandscapeRepair_Backups.ps1') -Mode cleanup -ProjectFile $project -ReportPath $backupReport -Selection $BackupSelection -Revision $BackupRevision}
 elseif($BackupVerifyId){& (Join-Path $PSScriptRoot 'LandscapeRepair_Backups.ps1') -Mode verify -ProjectFile $project -ReportPath $backupReport -BackupId $BackupVerifyId}
 else{& (Join-Path $PSScriptRoot 'LandscapeRepair_Backups.ps1') -Mode backup -ProjectFile $project -ReportPath $backupReport -ScopeFile $MaterialTargets}
 Write-Json (Join-Path $out 'last_job.json') @{job_id=$job;action=$Action;phase='exited';exit_code=0}
 exit 0
}
if($Action -eq 'material_restore'){
 Write-Json (Join-Path $out 'last_job.json') @{job_id=$job;action=$Action;phase='restoring'}
 Write-Json (Join-Path $out $(if($Action.StartsWith('grass_')){'last_grass_job.json'}else{'last_material_job.json'})) @{job_id=$job;action=$Action}
 $restoreReport=Join-Path $dir 'report.json';Write-Json $restoreReport @{schema_version='landscape_material_restore/1';job_id=$job;action=$Action;map=$map;ok=$false;map_saved=$false;phase='restoring'}
 & (Join-Path $PSScriptRoot 'LandscapeRepair_MaterialPackages.ps1') -Mode restore -ProjectFile $project -ReportPath $restoreReport
 Write-Json (Join-Path $out 'last_job.json') @{job_id=$job;action=$Action;phase='exited';exit_code=0}
 exit 0
}
$nativeAction=if($Action -eq 'material_backup'){'inventory'}else{$Action}
$argv=@($project,$map,'-run=WorldPartitionBuilderCommandlet','-builder=AIBridgeUELandscapeOfflineBuilder','-AllowCommandletRendering','-RenderOffscreen','-unattended','-nosound','-NoSplash','-SCCProvider=None','-stdout','-FullStdOutLogOutput',('-RepairAction='+$nativeAction),('-RepairJob='+$job),('-ExpectedProxies='+$expectedProxyCount),('-log='+$dir+'/worker.log'))
if($Action -in @('repair','normalize')){$argv+='-AuthorizeRepair'}
if($Action -eq 'material_repair'){$argv+='-AuthorizeMaterialRepair'}
if($Action -eq 'grass_repair'){$argv+='-AuthorizeGrassRepair'}
if($GrassProbeBaseline){$argv+='-GrassProbeBaseline'}
if($Action -in @('material_scan','material_repair','grass_scan','grass_repair')){$argv+='-forceAllowShaderCompilerJobCache'}
if($Action -in @('material_scan','material_repair','grass_scan','grass_repair')){
 $numberCulture=[Globalization.CultureInfo]::InvariantCulture
 $argv+=@(('-MaterialMemoryBudgetGiB='+$MemoryBudgetGiB.ToString('R',$numberCulture)),('-MaterialReservePhysicalGiB='+$ReservePhysicalGiB.ToString('R',$numberCulture)),('-MaterialReserveCommitGiB='+$ReserveCommitGiB.ToString('R',$numberCulture)))
}
if($MaterialTargets){$argv+=('-MaterialTargets='+[IO.Path]::GetFullPath($MaterialTargets))}
if($Action -eq 'verify'){$run=Get-Content (Join-Path $out 'last_saved_run.json') -Raw|ConvertFrom-Json;$argv+=('-RepairRunId='+$run.run_id)}
$state=@{job_id=$job;action=$Action;phase='launching';started_utc=[DateTime]::UtcNow.ToString('o')};Write-Json (Join-Path $out 'last_job.json') $state
if(($Action.StartsWith('material_') -or $Action.StartsWith('grass_')) -and $Action -ne 'material_backup'){Write-Json (Join-Path $out $(if($Action.StartsWith('grass_')){'last_grass_job.json'}else{'last_material_job.json'})) @{job_id=$job;action=$Action}}
$env:AIBRIDGE_UE_DISABLE_SESSION='1'
if($Action -in @('material_repair','grass_repair')){
 try{Invoke-MaterialBatches;$exit=$script:materialBatchExit}
 catch{
  $failedReport=Get-Content -LiteralPath (Join-Path $dir 'report.json') -Raw|ConvertFrom-Json
  $failedReport|Add-Member -NotePropertyName error -NotePropertyValue $_.Exception.Message -Force
  $failedReport|Add-Member -NotePropertyName finished_utc -NotePropertyValue ([DateTime]::UtcNow.ToString('o')) -Force
  $failedReport.phase='batch_failed';$failedReport.ok=$false
  Write-Json (Join-Path $dir 'report.json') $failedReport;$exit=1
 }
}
else{& (Join-Path $engine 'Binaries/Win64/UnrealEditor-Cmd.exe') @argv 2>&1 | Tee-Object (Join-Path $dir 'stdout.log');$exit=$LASTEXITCODE}
$report=Join-Path $dir 'report.json';$state.exit_code=$exit;$state.phase='exited';Write-Json (Join-Path $out 'last_job.json') $state
if(!(Test-Path $report)){throw ('OFFLINE_REPORT_MISSING: '+$report)}
$r=Get-Content $report -Raw|ConvertFrom-Json
if($Action -eq 'material_backup' -and $r.ok){
 Assert-Closed
 & (Join-Path $PSScriptRoot 'LandscapeRepair_Backups.ps1') -Mode backup -ProjectFile $project -ReportPath $report
 $r=Get-Content $report -Raw|ConvertFrom-Json
 if($r.ok){$exit=0;$state.exit_code=0;Write-Json (Join-Path $out 'last_job.json') $state}
}
if($exit -eq 0 -and $r.ok -and $Action -in @('material_repair','grass_repair') -and !$MaterialPrepareOnly){
 Assert-Closed
 & (Join-Path $PSScriptRoot 'LandscapeRepair_MaterialPackages.ps1') -Mode install -ProjectFile $project -ReportPath $report
 $r=Get-Content $report -Raw|ConvertFrom-Json
}
if($r.ok -and $Action -eq 'inventory'){Write-Json (Join-Path $out 'inventory_pointer.json') @{report=$report;job_id=$job}}
[ordered]@{job_id=$job;action=$Action;exit_code=$exit;ok=$r.ok;error=$r.error;run_id=$r.run_id;map_saved=$r.map_saved;cold_reopen_verified=$r.cold_reopen_verified;private_bytes=$r.private_bytes;peak_private_bytes=$r.peak_private_bytes;report=$report}|ConvertTo-Json -Compress
if($exit -ne 0){exit $exit};if(!$r.ok){exit 1};exit 0
