Landscape Repair runtime resources

These scripts are launched by the Unreal Editor panel. They do not require AI Bridge.
Supported release path: Windows Editor, Unreal Engine 5.8, World Partition, one registered Landscape parent,
one identity persistent Edit Layer, and no Landscape Blueprint Brush layer.

Write actions run only after the GUI editor exits. The worker creates backups, applies guarded native repair,
saves only after verification gates pass, and can cold-verify the last saved run.

Map maintenance now includes material_scan, material_repair and material_restore.
Material actions enumerate World Partition proxies and release them between batches.
They preserve source Edit Layers, nonzero weight channels and height data, stage packages,
check the post-save RVT shader, then back up and install via MaterialPackages.ps1.
Persistent material backups: Project/Backups/AIBridgeMapRepair.
Results and limits: Scripts/Landscape/README.md. This does not certify unrelated map assets.
