param(
    [ValidateSet('LocalStatus', 'CheckUpdate')]
    [string] $Operation = 'CheckUpdate',
    [string] $EngineRoot = 'D:\softwave\UE Engine\UE_5.8',
    [string] $SvnExecutable
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path

if (-not $SvnExecutable) {
    $candidate = Join-Path $EngineRoot 'Engine/Binaries/ThirdParty/svn/Win64/svn.exe'
    if (Test-Path -LiteralPath $candidate) {
        $SvnExecutable = $candidate
    }
    else {
        $command = Get-Command svn.exe -ErrorAction SilentlyContinue
        if ($command) { $SvnExecutable = $command.Source }
    }
}
if (-not $SvnExecutable -or -not (Test-Path -LiteralPath $SvnExecutable)) {
    throw "SVN executable not found. Pass -EngineRoot or -SvnExecutable. Checked: $EngineRoot"
}
$SvnExecutable = (Resolve-Path -LiteralPath $SvnExecutable).Path

function Invoke-SvnReadOnly {
    param([string[]] $Arguments)
    $output = & $SvnExecutable @Arguments 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "svn $($Arguments -join ' ') failed (exit $LASTEXITCODE): $($output -join ' ')"
    }
    return ($output -join "`n")
}

Push-Location $projectRoot
try {
    $workingCopyRoot = (Invoke-SvnReadOnly @('info', '--show-item', 'wc-root')).Trim()
    if ($workingCopyRoot.Replace('/', '\') -ne $projectRoot) {
        throw "Script project root $projectRoot differs from SVN working copy root $workingCopyRoot"
    }
    $localRevision = [int](Invoke-SvnReadOnly @('info', '--show-item', 'revision')).Trim()
    [xml]$statusXml = Invoke-SvnReadOnly @('status', '--xml', '--ignore-externals')
    $localCounts = [ordered]@{}
    $localStates = @{}
    $conflicts = [System.Collections.Generic.List[string]]::new()
    foreach ($entry in $statusXml.SelectNodes('//entry')) {
        $path = $entry.GetAttribute('path').Replace('/', '\')
        $wc = $entry.SelectSingleNode('wc-status')
        if ($null -eq $wc) { continue }
        $item = $wc.GetAttribute('item')
        $props = $wc.GetAttribute('props')
        if (-not $localCounts.Contains($item)) { $localCounts[$item] = 0 }
        $localCounts[$item]++
        $localStates[$path] = [pscustomobject]@{ item = $item; props = $props }
        if ($item -eq 'conflicted' -or $props -eq 'conflicted') {
            $conflicts.Add($path)
        }
    }

    $report = [ordered]@{
        schema = 'aibridge_svn_audit/1'
        read_only = $true
        operation = $Operation
        checked_at = (Get-Date).ToUniversalTime().ToString('o')
        svn_executable = $SvnExecutable
        working_copy_root = $workingCopyRoot
        local_revision = $localRevision
        local_entry_counts = $localCounts
        local_conflicts = @($conflicts.ToArray())
        remote_head_revision = $null
        incoming_changes = @()
        incoming_local_overlaps = @()
        incoming_add_obstructions = @()
    }

    if ($Operation -eq 'CheckUpdate') {
        $remoteRevision = [int](Invoke-SvnReadOnly @('info', '-r', 'HEAD', '--show-item', 'revision', '--non-interactive')).Trim()
        if ($remoteRevision -lt $localRevision) {
            throw "Remote revision $remoteRevision is older than working copy revision $localRevision"
        }
        $report.remote_head_revision = $remoteRevision
        $incoming = [System.Collections.Generic.List[object]]::new()
        $overlaps = [System.Collections.Generic.List[object]]::new()
        $addObstructions = [System.Collections.Generic.List[string]]::new()
        if ($remoteRevision -gt $localRevision) {
            $range = '{0}:{1}' -f ($localRevision + 1), $remoteRevision
            [xml]$logXml = Invoke-SvnReadOnly @('log', '-v', '-r', $range, '--xml', '--non-interactive')
            foreach ($logEntry in $logXml.SelectNodes('//logentry')) {
                $revision = [int]$logEntry.GetAttribute('revision')
                foreach ($pathNode in $logEntry.SelectNodes('paths/path')) {
                    $action = $pathNode.GetAttribute('action')
                    $path = $pathNode.InnerText.TrimStart('/').Replace('/', '\')
                    $incoming.Add([pscustomobject]@{ revision = $revision; action = $action; path = $path })
                    if ($localStates.ContainsKey($path)) {
                        $state = $localStates[$path]
                        if ($state.item -notin @('normal', 'unversioned', 'ignored') -or
                            $state.props -eq 'modified' -or $state.props -eq 'conflicted') {
                            $overlaps.Add([pscustomobject]@{
                                revision = $revision; action = $action; path = $path
                                local_item = $state.item; local_props = $state.props
                            })
                        }
                    }
                    if ($action -eq 'A' -and (Test-Path -LiteralPath (Join-Path $projectRoot $path))) {
                        $addStatus = & $SvnExecutable status --depth empty -- $path 2>&1
                        if ($LASTEXITCODE -ne 0 -or ($addStatus -join "`n") -match '^\s*[?I~C]') {
                            $addObstructions.Add($path)
                        }
                    }
                }
            }
        }
        $report.incoming_changes = @($incoming.ToArray())
        $report.incoming_local_overlaps = @($overlaps.ToArray())
        $report.incoming_add_obstructions = @($addObstructions.ToArray())
    }

    $report | ConvertTo-Json -Depth 8
}
finally {
    Pop-Location
}
