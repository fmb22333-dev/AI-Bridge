param([switch] $IncludeRemote)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$tool = Join-Path $PSScriptRoot 'Invoke-SvnAudit.ps1'
$svn = 'D:\softwave\UE Engine\UE_5.8\Engine\Binaries\ThirdParty\svn\Win64\svn.exe'

Push-Location $projectRoot
try {
    $expectedRoot = (& $svn info --show-item wc-root).Trim()
    $expectedRevision = [int](& $svn info --show-item revision)
    $local = (& $tool -Operation LocalStatus | Out-String | ConvertFrom-Json)
    if ($local.schema -ne 'aibridge_svn_audit/1' -or -not $local.read_only) {
        throw 'Local audit does not return the expected read-only schema.'
    }
    if ($local.working_copy_root -ne $expectedRoot -or $local.local_revision -ne $expectedRevision) {
        throw 'Local audit does not match the SVN working copy.'
    }
    $knownConflict = & $svn status 'Plugins/AIBridgeUE/README.md'
    if ($knownConflict -match '^C' -and
        @($local.local_conflicts) -notcontains 'Plugins\AIBridgeUE\README.md') {
        throw 'Local audit missed an existing SVN conflict.'
    }
    'LocalStatus passed'

    if ($IncludeRemote) {
        $expectedHead = [int](& $svn info -r HEAD --show-item revision --non-interactive)
        $remote = (& $tool -Operation CheckUpdate | Out-String | ConvertFrom-Json)
        if ($remote.remote_head_revision -ne $expectedHead -or
            $remote.local_revision -ne $expectedRevision) {
            throw 'Update audit revisions do not match SVN.'
        }
        if ($expectedHead -gt $expectedRevision -and @($remote.incoming_changes).Count -eq 0) {
            throw 'Update audit omitted incoming paths.'
        }
        'CheckUpdate passed'
    }
}
finally {
    Pop-Location
}
