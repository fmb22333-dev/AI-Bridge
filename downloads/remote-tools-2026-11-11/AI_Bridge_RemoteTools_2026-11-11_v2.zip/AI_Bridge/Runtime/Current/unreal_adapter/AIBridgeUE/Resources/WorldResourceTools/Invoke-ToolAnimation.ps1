param(
    [Parameter(Mandatory)]
    [ValidateSet('PreviewAssets', 'ApplyAssets', 'ReadbackAssets',
        'PreviewAxeChop', 'ApplyAxeChop', 'ReadbackAxeChop', 'ProbeChopSeams',
        'PreviewAxeLoop', 'ApplyAxeLoop', 'ReadbackAxeLoop',
        'PreviewAxeGrip', 'ApplyAxeGrip', 'ReadbackAxeGrip', 'ProbeAxeGripPose',
        'PreviewToolOverlayDefaults', 'ApplyToolOverlayDefaults', 'ReadbackToolOverlayDefaults',
        'ProbeToolOverlayCurves',
        'ProbeToolOverlayCurves',
        'PreviewToolDraws', 'ApplyToolDraws', 'ReadbackToolDraws',
        'PreviewToolReleaseGraph', 'ApplyToolReleaseGraph',
        'ApplyToolUpperBody',
        'PreviewGraph', 'ApplyGraph', 'ReadbackGraph',
        'ReadbackCharacterComponent', 'RepairCharacterComponent', 'Test')]
    [string] $Operation,
    [string] $EngineRoot = 'D:\softwave\UE Engine\UE_5.8',
    [switch] $AuthorizedCharacterEdit,
    [switch] $PersistentCache
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$scripts = Join-Path $projectRoot 'Scripts/WorldResource'

function Invoke-CharacterComponentScript {
    param([ValidateSet('Readback', 'Repair')][string] $Mode)

    $projectFile = Join-Path $projectRoot 'Demo01.uproject'
    $editorCmd = Join-Path $EngineRoot 'Engine/Binaries/Win64/UnrealEditor-Cmd.exe'
    if ($Mode -eq 'Readback') {
        $pythonFile = Join-Path $scripts 'readback_character_tool_component.py'
        $reportFile = Join-Path $scripts 'character_tool_component_readback.json'
        $logFile = Join-Path $scripts 'character_tool_component_readback.log'
        $marker = 'WORLDRESOURCE_CHARACTER_COMPONENT_READBACK='
    }
    else {
        $pythonFile = Join-Path $scripts 'attach_tool_component_in_editor.py'
        $reportFile = Join-Path $scripts 'character_tool_component_result.json'
        $logFile = Join-Path $scripts 'character_tool_component_repair.log'
        $marker = 'WORLDRESOURCE_CHARACTER_COMPONENT='
    }
    $started = Get-Date
    $arguments = @($projectFile, "-ExecutePythonScript=$pythonFile",
        '-unattended', '-nop4', '-nosplash', '-NullRHI')
    if (-not $PersistentCache) { $arguments += '-DDC-ForceMemoryCache' }
    $arguments += "-abslog=$logFile"
    $process = Start-Process -FilePath $editorCmd -ArgumentList $arguments -WindowStyle Hidden -PassThru
    try {
        $deadline = (Get-Date).AddMinutes(6)
        while ((Get-Date) -lt $deadline) {
            Start-Sleep -Seconds 2
            $process.Refresh()
            if ($process.HasExited) { break }
        }
        if (-not $process.HasExited) { throw "Character component $Mode timed out; inspect $logFile" }
        if (-not (Test-Path -LiteralPath $logFile) -or
            (Get-Item -LiteralPath $logFile).LastWriteTime -lt $started.AddSeconds(-1) -or
            -not (Select-String -LiteralPath $logFile -SimpleMatch $marker -Quiet)) {
            throw "Character component $Mode did not produce a fresh log marker; inspect $logFile"
        }
        if (-not (Test-Path -LiteralPath $reportFile) -or
            (Get-Item -LiteralPath $reportFile).LastWriteTime -lt $started.AddSeconds(-1)) {
            throw "Character component $Mode did not produce a fresh report; inspect $logFile"
        }
        $report = Get-Content -LiteralPath $reportFile -Raw | ConvertFrom-Json
        if (-not $report.ok -or @($report.components).Count -ne 1) {
            throw "Character component $Mode failed: $(Get-Content -LiteralPath $reportFile -Raw)"
        }
        $report | ConvertTo-Json -Depth 5
    }
    finally {
        $process.Refresh()
        if (-not $process.HasExited) { Stop-Process -Id $process.Id -Force }
    }
}

switch ($Operation) {
    'PreviewAssets' { & (Join-Path $scripts 'run_tool_attacks.ps1') -Mode Preview -EngineRoot $EngineRoot; break }
    'ApplyAssets' { & (Join-Path $scripts 'run_tool_attacks.ps1') -Mode Apply -EngineRoot $EngineRoot; break }
    'ReadbackAssets' { & (Join-Path $scripts 'run_tool_attacks.ps1') -Mode Readback -EngineRoot $EngineRoot; break }
    'PreviewAxeChop' { & (Join-Path $scripts 'run_axe_chop_authoring.ps1') -Mode Preview -EngineRoot $EngineRoot; break }
    'ApplyAxeChop' { & (Join-Path $scripts 'run_axe_chop_authoring.ps1') -Mode Apply -EngineRoot $EngineRoot; break }
    'ReadbackAxeChop' { & (Join-Path $scripts 'run_axe_chop_authoring.ps1') -Mode Readback -EngineRoot $EngineRoot; break }
    'ProbeChopSeams' { & (Join-Path $scripts 'run_chop_seam_probe.ps1') -EngineRoot $EngineRoot; break }
    'PreviewAxeLoop' { & (Join-Path $scripts 'run_axe_loop_authoring.ps1') -Mode Preview -EngineRoot $EngineRoot; break }
    'ApplyAxeLoop' { & (Join-Path $scripts 'run_axe_loop_authoring.ps1') -Mode Apply -EngineRoot $EngineRoot; break }
    'ReadbackAxeLoop' { & (Join-Path $scripts 'run_axe_loop_authoring.ps1') -Mode Readback -EngineRoot $EngineRoot; break }
    'PreviewAxeGrip' { & (Join-Path $scripts 'run_axe_grip_authoring.ps1') -Mode Preview -EngineRoot $EngineRoot; break }
    'ApplyAxeGrip' { & (Join-Path $scripts 'run_axe_grip_authoring.ps1') -Mode Apply -EngineRoot $EngineRoot; break }
    'ReadbackAxeGrip' { & (Join-Path $scripts 'run_axe_grip_authoring.ps1') -Mode Readback -EngineRoot $EngineRoot; break }
    'ProbeAxeGripPose' { & (Join-Path $scripts 'run_axe_grip_pose_probe.ps1') -EngineRoot $EngineRoot; break }
    'PreviewToolOverlayDefaults' { & (Join-Path $scripts 'run_tool_overlay_defaults.ps1') -Mode Preview -EngineRoot $EngineRoot; break }
    'ApplyToolOverlayDefaults' { & (Join-Path $scripts 'run_tool_overlay_defaults.ps1') -Mode Apply -EngineRoot $EngineRoot; break }
    'ReadbackToolOverlayDefaults' { & (Join-Path $scripts 'run_tool_overlay_defaults.ps1') -Mode Readback -EngineRoot $EngineRoot; break }
    'ProbeToolOverlayCurves' { & (Join-Path $scripts 'run_tool_overlay_curve_probe.ps1') -EngineRoot $EngineRoot; break }
    'ProbeToolOverlayCurves' { & (Join-Path $scripts 'run_tool_overlay_curve_probe.ps1') -EngineRoot $EngineRoot; break }
    'PreviewToolDraws' {
        & (Join-Path $scripts 'run_tool_draw_authoring.ps1') -Mode Preview -EngineRoot $EngineRoot
        & (Join-Path $scripts 'run_two_hand_grip_protocol.ps1') -Mode Preview -EngineRoot $EngineRoot
        break
    }
    'ApplyToolDraws' {
        & (Join-Path $scripts 'run_tool_draw_authoring.ps1') -Mode Apply -EngineRoot $EngineRoot
        & (Join-Path $scripts 'run_two_hand_grip_protocol.ps1') -Mode Apply -EngineRoot $EngineRoot
        break
    }
    'ReadbackToolDraws' {
        & (Join-Path $scripts 'run_tool_draw_authoring.ps1') -Mode Readback -EngineRoot $EngineRoot
        & (Join-Path $scripts 'run_two_hand_grip_protocol.ps1') -Mode Readback -EngineRoot $EngineRoot
        break
    }
    'PreviewToolReleaseGraph' { & (Join-Path $scripts 'run_tool_release_graph_patch.ps1') -Mode Preview -EngineRoot $EngineRoot; break }
    'ApplyToolReleaseGraph' {
        if (-not $AuthorizedCharacterEdit) {
            throw 'ApplyToolReleaseGraph edits /Game/Blueprints/CBP_SandboxCharacter. Pass -AuthorizedCharacterEdit only after the asset owner authorizes this specific edit.'
        }
        & (Join-Path $scripts 'run_tool_release_graph_patch.ps1') -Mode Apply -EngineRoot $EngineRoot
        break
    }
    'ApplyToolUpperBody' {
        if (-not $AuthorizedCharacterEdit) {
            throw 'ApplyToolUpperBody edits the main character AnimBP and skeleton.'
        }
        $projectFile = Join-Path $projectRoot 'Demo01.uproject'
        $editorCmd = Join-Path $EngineRoot 'Engine/Binaries/Win64/UnrealEditor-Cmd.exe'
        $logFile = Join-Path $projectRoot 'Saved/WorldResource/Stage18/tool_upper_body_apply.log'
        $reportFile = Join-Path $projectRoot 'Saved/WorldResource/Stage18/tool_upper_body_patch.txt'
        New-Item -ItemType Directory -Path (Split-Path $logFile) -Force | Out-Null
        $arguments = @($projectFile, '-ExecCmds="WorldResource.PatchToolGraph UpperBody"',
            '-unattended', '-nop4', '-nosplash', '-NullRHI')
        if (-not $PersistentCache) { $arguments += '-DDC-ForceMemoryCache' }
        $arguments += "-abslog=$logFile"
        $started = Get-Date
        $process = Start-Process -FilePath $editorCmd -ArgumentList $arguments -WindowStyle Hidden -PassThru
        try {
            $deadline = (Get-Date).AddMinutes(6)
            $found = $false
            while ((Get-Date) -lt $deadline) {
                Start-Sleep -Seconds 3
                $process.Refresh()
                if ((Test-Path -LiteralPath $logFile) -and
                    (Get-Item -LiteralPath $logFile).LastWriteTime -ge $started.AddSeconds(-1) -and
                    (Select-String -LiteralPath $logFile -SimpleMatch 'WORLDRESOURCE_TOOL_UPPER_BODY_PATCH=' -Quiet)) {
                    $found = $true
                    break
                }
                if ($process.HasExited) { break }
            }
            if (-not $found -or -not (Test-Path -LiteralPath $reportFile) -or
                (Get-Item -LiteralPath $reportFile).LastWriteTime -lt $started.AddSeconds(-1)) {
                throw "Tool upper-body patch failed or stale; inspect $logFile"
            }
            Get-Content -LiteralPath $reportFile -Raw
        }
        finally {
            $process.Refresh()
            if (-not $process.HasExited) { Stop-Process -Id $process.Id -Force }
        }
        break
    }
    'PreviewGraph' { & (Join-Path $scripts 'run_stage9_tool_graph_patch.ps1') -Mode Preview -EngineRoot $EngineRoot -PersistentCache:$PersistentCache; break }
    'ApplyGraph' {
        if (-not $AuthorizedCharacterEdit) {
            throw 'ApplyGraph edits /Game/Blueprints/CBP_SandboxCharacter. Pass -AuthorizedCharacterEdit only after the asset owner authorizes this specific edit.'
        }
        & (Join-Path $scripts 'run_stage9_tool_graph_patch.ps1') -Mode Apply -EngineRoot $EngineRoot -PersistentCache:$PersistentCache
        break
    }
    'ReadbackGraph' {
        $projectFile = Join-Path $projectRoot 'Demo01.uproject'
        $editorCmd = Join-Path $EngineRoot 'Engine/Binaries/Win64/UnrealEditor-Cmd.exe'
        $logFile = Join-Path $scripts 'stage9_tool_graph_readback.log'
        $reportFile = Join-Path $scripts 'tool_animation_graph_probe.txt'
        $arguments = @($projectFile, '-ExecCmds="WorldResource.ProbeAnimationGraph"',
            '-unattended', '-nop4', '-nosplash', '-NullRHI')
        if (-not $PersistentCache) { $arguments += '-DDC-ForceMemoryCache' }
        $arguments += "-abslog=$logFile"
        $started = Get-Date
        $process = Start-Process -FilePath $editorCmd -ArgumentList $arguments -WindowStyle Hidden -PassThru
        try {
            $deadline = (Get-Date).AddMinutes(6)
            $found = $false
            while ((Get-Date) -lt $deadline) {
                Start-Sleep -Seconds 3
                $process.Refresh()
                if ((Test-Path -LiteralPath $logFile) -and
                    (Get-Item -LiteralPath $logFile).LastWriteTime -ge $started.AddSeconds(-1) -and
                    (Select-String -LiteralPath $logFile -Pattern 'WORLDRESOURCE_ANIMATION_GRAPH_PROBE saved=1' -Quiet)) {
                    $found = $true
                    break
                }
                if ($process.HasExited) { break }
            }
            if (-not $found -or -not (Test-Path -LiteralPath $reportFile) -or
                (Get-Item -LiteralPath $reportFile).LastWriteTime -lt $started.AddSeconds(-1)) {
                throw "Animation graph readback failed or stale; inspect $logFile"
            }
            Get-Item -LiteralPath $reportFile | Select-Object FullName, Length, LastWriteTime
        }
        finally {
            $process.Refresh()
            if (-not $process.HasExited) { Stop-Process -Id $process.Id -Force }
        }
        break
    }
    'ReadbackCharacterComponent' { Invoke-CharacterComponentScript -Mode Readback; break }
    'RepairCharacterComponent' {
        if (-not $AuthorizedCharacterEdit) {
            throw 'RepairCharacterComponent edits /Game/Blueprints/CBP_SandboxCharacter. Pass -AuthorizedCharacterEdit only after the asset owner authorizes this specific edit.'
        }
        Invoke-CharacterComponentScript -Mode Repair
        break
    }
    'Test' { & (Join-Path $scripts 'run_stage9_tool_tests.ps1') -EngineRoot $EngineRoot -PersistentCache:$PersistentCache; break }
}
