#include "Modules/ModuleManager.h"

#include "AIBridgeUEAnimCurveExportMenu.h"
#include "AIBridgeUEAnimCurveFbxExporter.h"
#include "AIBridgeUEInspector.h"
#include "AIBridgeUESessionClient.h"
#include "Animation/AnimSequence.h"
#include "ContentBrowserMenuContexts.h"
#include "Editor.h"
#include "EngineUtils.h"
#include "Framework/Docking/TabManager.h"
#include "HAL/PlatformProcess.h"
#include "Landscape.h"
#include "LandscapeStreamingProxy.h"
#include "DesktopPlatformModule.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Commands/UIAction.h"
#include "HAL/FileManager.h"
#include "IDesktopPlatform.h"
#include "Interfaces/IPluginManager.h"
#include "Misc/MessageDialog.h"
#include "Misc/PackageName.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"
#include "HAL/PlatformTime.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "ToolMenu.h"
#include "ToolMenuSection.h"
#include "ToolMenus.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Text/STextBlock.h"

#define LOCTEXT_NAMESPACE "FAIBridgeUEEditorModule"

DEFINE_LOG_CATEGORY_STATIC(LogAIBridgeUE, Log, All);

namespace AIBridgeUE
{
const FName LandscapeRepairTabName(TEXT("AIBridgeUE.LandscapeRepair"));

bool IsAnimSequenceOnlySelection(const TArray<FAssetData>& SelectedAssets)
{
    if (SelectedAssets.IsEmpty())
    {
        return false;
    }

    const FTopLevelAssetPath AnimSequenceClassPath = UAnimSequence::StaticClass()->GetClassPathName();
    for (const FAssetData& AssetData : SelectedAssets)
    {
        if (AssetData.AssetClassPath != AnimSequenceClassPath)
        {
            return false;
        }
    }
    return true;
}
}

class FAIBridgeUEEditorModule final : public IModuleInterface
{
public:
    virtual void StartupModule() override
    {
        MenuStartupHandle = UToolMenus::RegisterStartupCallback(
            FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FAIBridgeUEEditorModule::RegisterMenus));

        FGlobalTabmanager::Get()->RegisterNomadTabSpawner(
            AIBridgeUE::LandscapeRepairTabName,
            FOnSpawnTab::CreateRaw(this, &FAIBridgeUEEditorModule::SpawnLandscapeRepairTab))
            .SetDisplayName(LOCTEXT("LandscapeRepairTabTitle", "地图诊断与修复"))
            .SetTooltipText(LOCTEXT("LandscapeRepairTabTooltip", "检查地形数据与材质，离线修复并保留备份。"))
            .SetMenuType(ETabSpawnerMenuType::Hidden);

        SessionClient = MakeUnique<FAIBridgeUESessionClient>();
        SessionClient->Start();

        UE_LOG(
            LogAIBridgeUE,
            Display,
            TEXT("AI Bridge UE Editor V0.5.2 loaded; curve-preserving AnimSequence FBX export enabled."));
    }

    virtual void ShutdownModule() override
    {
        if (SessionClient)
        {
            SessionClient->Stop();
            SessionClient.Reset();
        }

        FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(AIBridgeUE::LandscapeRepairTabName);

        if (UToolMenus::TryGet() != nullptr)
        {
            UToolMenus::UnRegisterStartupCallback(MenuStartupHandle);
            UToolMenus::UnregisterOwner(this);
        }
    }

private:
    void RegisterMenus()
    {
        FToolMenuOwnerScoped OwnerScoped(this);

        if (UToolMenu* WindowMenu = UToolMenus::Get()->ExtendMenu(TEXT("LevelEditor.MainMenu.Window")))
        {
            FToolMenuSection& Section = WindowMenu->FindOrAddSection(TEXT("AIBridgeUE"));
            Section.AddMenuEntry(
                TEXT("AIBridgeUE_InspectCurrentLevel"),
                LOCTEXT("InspectCurrentLevelLabel", "Inspect Current Level"),
                LOCTEXT(
                    "InspectCurrentLevelTooltip",
                    "Read the current level and write a shallow read-only scene manifest."),
                FSlateIcon(),
                FUIAction(FExecuteAction::CreateRaw(this, &FAIBridgeUEEditorModule::InspectCurrentLevel)),
                EUserInterfaceActionType::Button,
                NAME_None);

            Section.AddMenuEntry(
                TEXT("AIBridgeUE_LandscapeRepair"),
                LOCTEXT("LandscapeRepairLabel", "地图诊断与修复"),
                LOCTEXT(
                    "LandscapeRepairTooltip",
                    "检查地形数据与材质，无需 AI 连接。"),
                FSlateIcon(),
                FUIAction(FExecuteAction::CreateRaw(this, &FAIBridgeUEEditorModule::OpenLandscapeRepairPanel)),
                EUserInterfaceActionType::Button,
                NAME_None);
        }

        if (UToolMenu* AssetContextMenu = UToolMenus::Get()->ExtendMenu(TEXT("ContentBrowser.AssetContextMenu")))
        {
            FToolMenuSection& Section = AssetContextMenu->FindOrAddSection(TEXT("AIBridgeUE"));
            Section.AddDynamicEntry(
                TEXT("AIBridgeUE_AnimCurveExportDynamic"),
                FNewToolMenuSectionDelegate::CreateRaw(
                    this,
                    &FAIBridgeUEEditorModule::PopulateAnimSequenceCurveExportMenu));
        }
    }

    void OpenLandscapeRepairPanel()
    {
        FGlobalTabmanager::Get()->TryInvokeTab(AIBridgeUE::LandscapeRepairTabName);
    }

    bool ResolveLandscapeRepairTarget(
        FString& OutMap,
        FString& OutLandscapePath,
        int32& OutProxyCount,
        int32& OutComponentCount,
        FString& OutError) const
    {
        OutMap.Reset();
        OutLandscapePath.Reset();
        OutProxyCount = 0;
        OutComponentCount = 0;
        OutError.Reset();

        if (GEditor == nullptr || GEditor->PlayWorld != nullptr)
        {
            OutError = TEXT("Editor world is not available.");
            return false;
        }

        UWorld* World = GEditor->GetEditorWorldContext().World();
        if (World == nullptr || World->IsGameWorld())
        {
            OutError = TEXT("Open an editor world before using Landscape Repair.");
            return false;
        }

        TArray<ALandscape*> Parents;
        for (TActorIterator<ALandscape> It(World); It; ++It)
        {
            if (It->GetLandscapeInfo() != nullptr)
            {
                Parents.Add(*It);
            }
        }

        if (Parents.Num() != 1)
        {
            OutError = FString::Printf(
                TEXT("This release intentionally supports exactly one registered Landscape parent per map; found %d."),
                Parents.Num());
            return false;
        }

        ALandscape* Parent = Parents[0];
        for (TActorIterator<ALandscapeStreamingProxy> It(World); It; ++It)
        {
            ALandscapeStreamingProxy* Proxy = *It;
            if (Proxy != nullptr && Proxy->GetLandscapeActor() == Parent && !Proxy->LandscapeComponents.IsEmpty())
            {
                ++OutProxyCount;
                OutComponentCount += Proxy->LandscapeComponents.Num();
            }
        }

        OutMap = World->GetOutermost()->GetName();
        OutLandscapePath = Parent->GetPathName();
        return true;
    }

    FText GetLandscapeRepairStatusText() const
    {
        FString Map;
        FString LandscapePath;
        FString Error;
        int32 ProxyCount = 0;
        int32 ComponentCount = 0;
        if (!ResolveLandscapeRepairTarget(Map, LandscapePath, ProxyCount, ComponentCount, Error))
        {
            return FText::FromString(TEXT("Target unavailable: ") + Error);
        }

        return FText::FromString(FString::Printf(
            TEXT("Map: %s\nLandscape: %s\nLoaded streaming proxies: %d\nLoaded components: %d\n\n")
            TEXT("Repair jobs are executed in an independent UnrealEditor-Cmd process after this editor exits."),
            *Map,
            *LandscapePath,
            ProxyCount,
            ComponentCount));
    }

    FReply QueueLandscapeRepairAction(const FString Action)
    {
        FString Map;
        FString LandscapePath;
        FString Error;
        int32 ProxyCount = 0;
        int32 ComponentCount = 0;
        if (!ResolveLandscapeRepairTarget(Map, LandscapePath, ProxyCount, ComponentCount, Error))
        {
            FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Error));
            return FReply::Handled();
        }

#if !PLATFORM_WINDOWS
        FMessageDialog::Open(
            EAppMsgType::Ok,
            LOCTEXT("LandscapeRepairWindowsOnly", "The first public/manual scheduler currently supports Windows Editor only."));
        return FReply::Handled();
#else
        FString ProjectFile = FPaths::ConvertRelativePathToFull(FPaths::GetProjectFilePath());
        FPaths::NormalizeFilename(ProjectFile);
        const TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(TEXT("AIBridgeUE"));
        if (!Plugin.IsValid())
        {
            FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("LandscapeRepairPluginMissing", "AIBridgeUE plugin directory could not be resolved."));
            return FReply::Handled();
        }
        FString ScriptPath = FPaths::ConvertRelativePathToFull(
            FPaths::Combine(Plugin->GetBaseDir(), TEXT("Resources/LandscapeRepair/LandscapeRepair_ScheduledJob.ps1")));
        FPaths::NormalizeFilename(ScriptPath);
        FString EditorExecutable = FString(FPlatformProcess::ExecutablePath());
        FPaths::NormalizeFilename(EditorExecutable);

        if (ProjectFile.IsEmpty() || !FPaths::FileExists(ProjectFile))
        {
            FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("LandscapeRepairProjectMissing", "Project file could not be resolved."));
            return FReply::Handled();
        }
        if (!FPaths::FileExists(ScriptPath))
        {
            FMessageDialog::Open(
                EAppMsgType::Ok,
                FText::FromString(TEXT("Landscape repair scheduler is missing:\n") + ScriptPath));
            return FReply::Handled();
        }

        const FString Arguments = FString::Printf(
            TEXT("-NoProfile -NonInteractive -ExecutionPolicy Bypass -File \"%s\" -Mode launch -Action %s ")
            TEXT("-RequesterPid %u -WaitForRequesterExit -ProjectFile \"%s\" -Map \"%s\" ")
            TEXT("-ExpectedProxies %d -EditorExecutable \"%s\" -Reopen"),
            *ScriptPath,
            *Action,
            FPlatformProcess::GetCurrentProcessId(),
            *ProjectFile,
            *Map,
            0,
            *EditorExecutable);

        FProcHandle Handle = FPlatformProcess::CreateProc(
            TEXT("powershell.exe"),
            *Arguments,
            true,
            true,
            false,
            nullptr,
            0,
            *FPaths::ProjectDir(),
            nullptr);

        if (!Handle.IsValid())
        {
            FMessageDialog::Open(
                EAppMsgType::Ok,
                LOCTEXT("LandscapeRepairQueueFailed", "Failed to start the Landscape repair scheduler."));
            return FReply::Handled();
        }

        FPlatformProcess::CloseProc(Handle);
        FMessageDialog::Open(
            EAppMsgType::Ok,
            FText::FromString(
                FString::Printf(
                    TEXT("Queued offline Landscape action: %s\n\n")
                    TEXT("Close this Unreal Editor normally. The job waits for this process to exit, ")
                    TEXT("runs in UnrealEditor-Cmd, then reopens the project.\n\n")
                    TEXT("Unsaved unrelated work should be saved or discarded normally before closing."),
                    *Action)));
        return FReply::Handled();
#endif
    }

    FText GetMaterialRepairStatusText() const
    {
        // This attribute is evaluated while painting; bound file reads to once every two seconds.
        static double LastRead = -10.0;
        static FText Cached;
        const double Now = FPlatformTime::Seconds();
        if (Now - LastRead < 2.0) return Cached;
        LastRead = Now;
        Cached = LOCTEXT("MaterialRepairNoJob", "材质修复：尚未运行");
        const FString Base = FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("AIBridgeLandscapeRepair/Offline"));
        FString Text; TSharedPtr<FJsonObject> Pointer, Report;
        if (!FFileHelper::LoadFileToString(Text, *FPaths::Combine(Base, TEXT("last_material_job.json")))
            || !FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text), Pointer)) return Cached;
        FString Job; FGuid Guid;
        if (!Pointer->TryGetStringField(TEXT("job_id"), Job) || !FGuid::ParseExact(Job, EGuidFormats::Digits, Guid)) return Cached;
        if (!FFileHelper::LoadFileToString(Text, *FPaths::Combine(Base, TEXT("Jobs"), Job, TEXT("report.json")))
            || !FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text), Report))
        { Cached = LOCTEXT("MaterialRepairWaiting", "材质任务：等待编辑器退出或正在启动"); return Cached; }
        double Checked = 0, Candidates = 0, Removed = 0, MapErrors = 0;
        Report->TryGetNumberField(TEXT("selected_components"), Checked);
        Report->TryGetNumberField(TEXT("candidate_components"), Candidates);
        Report->TryGetNumberField(TEXT("removed_allocations"), Removed);
        Report->TryGetNumberField(TEXT("map_load_error_count"), MapErrors);
        FString Phase, Error;
        Report->TryGetStringField(TEXT("phase"), Phase); Report->TryGetStringField(TEXT("error"), Error);
        const FString State = Phase == TEXT("installed") ? TEXT("已修复")
            : Phase == TEXT("scan_complete") ? TEXT("检查完成")
            : Phase == TEXT("no_changes") ? TEXT("无需修改")
            : Phase == TEXT("restored") ? TEXT("已撤销")
            : Phase == TEXT("staged_not_installed") ? TEXT("副本已准备，尚未写回") : TEXT("处理中／未完成");
        FString Status = FString::Printf(TEXT("%s：检查 %.0f，候选 %.0f，清理分配 %.0f%s"), *State, Checked, Candidates, Removed,
            Error.IsEmpty() ? TEXT("") : *(TEXT("\n") + Error));
        if (MapErrors > 0) Status += FString::Printf(TEXT("\n地图另有 %.0f 条载入错误，详见本次日志。"), MapErrors);
        Cached = FText::FromString(Status);
        return Cached;
    }

    TSharedRef<SDockTab> SpawnLandscapeRepairTab(const FSpawnTabArgs&)
    {
        return SNew(SDockTab)
            .TabRole(ETabRole::NomadTab)
            [
                SNew(SScrollBox)
                + SScrollBox::Slot()
                [
                    SNew(SVerticalBox)
                    + SVerticalBox::Slot()
                    .AutoHeight()
                    .Padding(12.0f)
                    [
                        SNew(STextBlock)
                        .Text(LOCTEXT(
                            "LandscapeRepairIntro",
                            "检查与修复地图。任务排队后保存并退出 UE，完成后自动重开。"))
                        .AutoWrapText(true)
                    ]
                    + SVerticalBox::Slot()
                    .AutoHeight()
                    .Padding(12.0f, 0.0f, 12.0f, 12.0f)
                    [
                        SNew(STextBlock)
                        .Text_Lambda([this]() { return GetLandscapeRepairStatusText(); })
                        .AutoWrapText(true)
                    ]
                    + SVerticalBox::Slot()
                    .AutoHeight().Padding(12.0f, 4.0f)
                    [ SNew(STextBlock).Text(LOCTEXT("MaterialRepairGroup", "地形材质")) ]
                    + SVerticalBox::Slot()
                    .AutoHeight().Padding(12.0f, 4.0f)
                    [ SNew(STextBlock).Text_Lambda([this]() { return GetMaterialRepairStatusText(); }).AutoWrapText(true) ]
                    + SVerticalBox::Slot()
                    .AutoHeight().Padding(12.0f, 4.0f)
                    [ SNew(SButton).Text(LOCTEXT("MaterialRepairScan", "检查全图材质分配"))
                        .ToolTipText(LOCTEXT("MaterialRepairScanTip", "分批读取所有地形代理，包含未加载内容；不保存资产。"))
                        .OnClicked_Lambda([this]() { return QueueLandscapeRepairAction(TEXT("material_scan")); }) ]
                    + SVerticalBox::Slot()
                    .AutoHeight().Padding(12.0f, 4.0f)
                    [ SNew(SButton).Text(LOCTEXT("MaterialRepairApply", "一键修复空分配"))
                        .ToolTipText(LOCTEXT("MaterialRepairApplyTip", "保留原始绘制层、非零权重与高度；验证副本并自动备份后写回。"))
                        .OnClicked_Lambda([this]() { return QueueLandscapeRepairAction(TEXT("material_repair")); }) ]
                    + SVerticalBox::Slot()
                    .AutoHeight().Padding(12.0f, 4.0f)
                    [ SNew(SButton).Text(LOCTEXT("MaterialRepairRestore", "撤销最近材质修复"))
                        .ToolTipText(LOCTEXT("MaterialRepairRestoreTip", "恢复最近批次备份；发现后续修改时停止，保留你的新工作。"))
                        .OnClicked_Lambda([this]() { return QueueLandscapeRepairAction(TEXT("material_restore")); }) ]
                    + SVerticalBox::Slot()
                    .AutoHeight().Padding(12.0f, 4.0f)
                    [ SNew(SButton).Text(LOCTEXT("MaterialRepairReports", "打开修复记录"))
                        .OnClicked_Lambda([]() { FPlatformProcess::ExploreFolder(*FPaths::ConvertRelativePathToFull(
                            FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("AIBridgeLandscapeRepair/Offline/Jobs")))); return FReply::Handled(); }) ]
                    + SVerticalBox::Slot()
                    .AutoHeight().Padding(12.0f, 12.0f, 12.0f, 4.0f)
                    [ SNew(STextBlock).Text(LOCTEXT("LandscapeDataRepairGroup", "地形数据与高度")) ]
                    + SVerticalBox::Slot()
                    .AutoHeight()
                    .Padding(12.0f, 4.0f)
                    [
                        SNew(SButton)
                        .Text(LOCTEXT("LandscapeRepairScan", "检查地形数据"))
                        .ToolTipText(LOCTEXT("LandscapeRepairScanTip", "Read-only scan. Close the editor after queuing; the project reopens when complete."))
                        .OnClicked_Lambda([this]() { return QueueLandscapeRepairAction(TEXT("scan")); })
                    ]
                    + SVerticalBox::Slot()
                    .AutoHeight()
                    .Padding(12.0f, 4.0f)
                    [
                        SNew(SButton)
                        .Text(LOCTEXT("LandscapeRepairMigrate", "修复孤立编辑层"))
                        .ToolTipText(LOCTEXT("LandscapeRepairMigrateTip", "Run the guarded disk-final migration path with backup, verification and save gates."))
                        .OnClicked_Lambda([this]() { return QueueLandscapeRepairAction(TEXT("repair")); })
                    ]
                    + SVerticalBox::Slot()
                    .AutoHeight()
                    .Padding(12.0f, 4.0f)
                    [
                        SNew(SButton)
                        .Text(LOCTEXT("LandscapeRepairNormalize", "稳定高度共享边"))
                        .ToolTipText(LOCTEXT("LandscapeRepairNormalizeTip", "Run the Height-only stabilization path after migration is clean."))
                        .OnClicked_Lambda([this]() { return QueueLandscapeRepairAction(TEXT("normalize")); })
                    ]
                    + SVerticalBox::Slot()
                    .AutoHeight()
                    .Padding(12.0f, 4.0f, 12.0f, 12.0f)
                    [
                        SNew(SButton)
                        .Text(LOCTEXT("LandscapeRepairVerify", "复核最近数据修复"))
                        .ToolTipText(LOCTEXT("LandscapeRepairVerifyTip", "Cold-reopen verification of the last saved Landscape repair run."))
                        .OnClicked_Lambda([this]() { return QueueLandscapeRepairAction(TEXT("verify")); })
                    ]
                    + SVerticalBox::Slot()
                    .AutoHeight()
                    .Padding(12.0f)
                    [
                        SNew(STextBlock)
                        .Text(LOCTEXT(
                            "LandscapeRepairLimitations",
                            "Current safety envelope: UE 5.8 Editor, World Partition, exactly one registered Landscape parent, one identity persistent Edit Layer, no Landscape Blueprint Brush layer. Unsupported configurations fail closed instead of being guessed."))
                        .AutoWrapText(true)
                    ]
                ]
            ];
    }

    void PopulateAnimSequenceCurveExportMenu(FToolMenuSection& Section)
    {
        const UContentBrowserAssetContextMenuContext* Context =
            Section.FindContext<UContentBrowserAssetContextMenuContext>();
        if (Context == nullptr || !AIBridgeUE::IsAnimSequenceOnlySelection(Context->SelectedAssets))
        {
            return;
        }

        const TArray<FAssetData> SelectedAssets = Context->SelectedAssets;
        Section.AddSubMenu(
            TEXT("AIBridgeUE_AnimSequenceSubMenu"),
            LOCTEXT("AIBridgeAssetSubMenuLabel", "AI Bridge"),
            LOCTEXT("AIBridgeAssetSubMenuTooltip", "AI Bridge asset actions."),
            FNewToolMenuDelegate::CreateLambda(
                [this, SelectedAssets](UToolMenu* SubMenu)
                {
                    FToolMenuSection& ExportSection =
                        SubMenu->FindOrAddSection(TEXT("AIBridgeUE_AnimationExport"));
                    ExportSection.AddMenuEntry(
                        TEXT("AIBridgeUE_ExportAnimSequenceFbxWithCurves"),
                        LOCTEXT("ExportAnimSequenceFbxWithCurvesLabel", "Export FBX With Curves"),
                        LOCTEXT(
                            "ExportAnimSequenceFbxWithCurvesTooltip",
                            "Export the selected AnimSequence assets to FBX, preserving asset folder hierarchy (including Game/plugin roots) and Unreal Float Curves as animated FBX custom properties."),
                        FSlateIcon(),
                        FUIAction(FExecuteAction::CreateLambda(
                            [this, SelectedAssets]()
                            {
                                ExportAnimSequencesWithCurves(SelectedAssets);
                            })),
                        EUserInterfaceActionType::Button,
                        NAME_None);
                }));
    }

    void ExportAnimSequencesWithCurves(const TArray<FAssetData>& SelectedAssets)
    {
        if (!AIBridgeUE::IsAnimSequenceOnlySelection(SelectedAssets))
        {
            return;
        }

        IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
        if (DesktopPlatform == nullptr)
        {
            UE_LOG(LogAIBridgeUE, Error, TEXT("DesktopPlatform is unavailable; cannot choose an FBX export directory."));
            FMessageDialog::Open(
                EAppMsgType::Ok,
                LOCTEXT("DesktopPlatformUnavailable", "Unable to open the export-folder picker."));
            return;
        }

        FString InitialDirectory = LastAnimCurveExportDirectory;
        if (InitialDirectory.IsEmpty())
        {
            InitialDirectory = FPaths::ProjectSavedDir();
        }

        const void* ParentWindowHandle = nullptr;
        if (FSlateApplication::IsInitialized())
        {
            ParentWindowHandle = FSlateApplication::Get().FindBestParentWindowHandleForDialogs(
                nullptr,
                ESlateParentWindowSearchMethod::ActiveWindow);
        }

        FString OutputDirectory;
        if (!DesktopPlatform->OpenDirectoryDialog(
                ParentWindowHandle,
                TEXT("Export AnimSequence FBX With Curves"),
                InitialDirectory,
                OutputDirectory))
        {
            return;
        }

        OutputDirectory = FPaths::ConvertRelativePathToFull(OutputDirectory);
        FPaths::NormalizeDirectoryName(OutputDirectory);
        LastAnimCurveExportDirectory = OutputDirectory;

        int32 SuccessCount = 0;
        int32 FailureCount = 0;
        int32 TotalCurveCount = 0;

        for (const FAssetData& AssetData : SelectedAssets)
        {
            const FString AssetPath = AssetData.GetSoftObjectPath().ToString();
            const FString PackageName = AssetData.PackageName.ToString();
            // 使用 UE 包目录而非磁盘 Content 路径，保留 Game、插件挂载点和全部子目录。
            // 不截取本次选择的公共父目录，确保单独导出和分批导出得到相同的相对路径。
            if (!FPackageName::IsValidLongPackageName(PackageName, true))
            {
                ++FailureCount;
                UE_LOG(LogAIBridgeUE, Error,
                    TEXT("AnimSequence export skipped: invalid package path for %s: %s"),
                    *AssetPath, *PackageName);
                continue;
            }

            // 只移除包目录开头的斜杠，防止 Combine 将它当作绝对路径。
            const FString RelativeAssetDirectory = FPackageName::GetLongPackagePath(PackageName).RightChop(1);
            FString OutputPath = FPaths::ConvertRelativePathToFull(
                FPaths::Combine(OutputDirectory, RelativeAssetDirectory, AssetData.AssetName.ToString() + TEXT(".fbx")));
            FPaths::NormalizeFilename(OutputPath);

            // 路径异常时明确失败，不能回退到扁平目录或写到用户选择的导出根目录之外。
            if (!FPaths::IsUnderDirectory(OutputPath, OutputDirectory))
            {
                ++FailureCount;
                UE_LOG(LogAIBridgeUE, Error,
                    TEXT("AnimSequence export skipped: output path is outside the selected directory: %s -> %s"),
                    *AssetPath, *OutputPath);
                continue;
            }

            const FString AssetOutputDirectory = FPaths::GetPath(OutputPath);
            if (!IFileManager::Get().DirectoryExists(*AssetOutputDirectory)
                && !IFileManager::Get().MakeDirectory(*AssetOutputDirectory, true))
            {
                ++FailureCount;
                UE_LOG(LogAIBridgeUE, Error,
                    TEXT("AnimSequence export failed: could not create output directory for %s: %s"),
                    *AssetPath, *AssetOutputDirectory);
                continue;
            }

            TSharedRef<FJsonObject> Arguments = MakeShared<FJsonObject>();
            Arguments->SetStringField(TEXT("asset_path"), AssetPath);
            Arguments->SetStringField(TEXT("output_path"), OutputPath);

            FString ErrorCode;
            FString ErrorMessage;
            const TSharedPtr<FJsonObject> Result =
                AIBridgeUE::ExportAnimSequenceFbxWithCurves(Arguments, ErrorCode, ErrorMessage);
            if (!Result.IsValid())
            {
                ++FailureCount;
                UE_LOG(
                    LogAIBridgeUE,
                    Error,
                    TEXT("AnimSequence curve FBX export failed [%s] %s -> %s: %s"),
                    *ErrorCode,
                    *AssetPath,
                    *OutputPath,
                    *ErrorMessage);
                continue;
            }

            ++SuccessCount;
            double CurveCount = 0.0;
            if (Result->TryGetNumberField(TEXT("curve_count"), CurveCount))
            {
                TotalCurveCount += FMath::RoundToInt(CurveCount);
            }

            UE_LOG(
                LogAIBridgeUE,
                Display,
                TEXT("AnimSequence curve FBX export verified: %s -> %s"),
                *AssetPath,
                *OutputPath);
        }

        FString Summary = FString::Printf(
            TEXT("Exported: %d / Failed: %d / Curves: %d\n\nOutput: %s"),
            SuccessCount,
            FailureCount,
            TotalCurveCount,
            *OutputDirectory);
        if (FailureCount > 0)
        {
            Summary += TEXT("\n\nSee Output Log for failure details.");
        }

        FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Summary));
    }

    void InspectCurrentLevel()
    {
        FString OutputPath;
        FString Error;
        if (!AIBridgeUE::WriteCurrentLevelManifest(nullptr, OutputPath, Error))
        {
            UE_LOG(LogAIBridgeUE, Error, TEXT("Current-level inspection failed: %s"), *Error);
            return;
        }

        UE_LOG(LogAIBridgeUE, Display, TEXT("Read-only scene manifest written: %s"), *OutputPath);
    }

    FDelegateHandle MenuStartupHandle;
    TUniquePtr<FAIBridgeUESessionClient> SessionClient;
    FString LastAnimCurveExportDirectory;
};

IMPLEMENT_MODULE(FAIBridgeUEEditorModule, AIBridgeUEEditor)

#undef LOCTEXT_NAMESPACE
