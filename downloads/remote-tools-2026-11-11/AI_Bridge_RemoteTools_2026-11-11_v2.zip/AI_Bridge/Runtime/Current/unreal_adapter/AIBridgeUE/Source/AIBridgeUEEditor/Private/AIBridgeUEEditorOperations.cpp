#include "AIBridgeUEEditorOperations.h"

#include "AssetCompilingManager.h"
#include "Editor.h"
#include "FileHelpers.h"
#include "HAL/FileManager.h"
#include "HAL/PlatformFileManager.h"
#include "IPythonScriptPlugin.h"
#include "ImageUtils.h"
#include "LevelEditorViewport.h"
#include "Misc/FileHelper.h"
#include "HAL/PlatformOutputDevices.h"
#include "Misc/Guid.h"
#include "Misc/Paths.h"
#include "PlayInEditorDataTypes.h"
#include "PythonScriptTypes.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "UnrealClient.h"
#include "UObject/Package.h"

namespace AIBridgeUE
{
namespace
{
static constexpr int64 MaxLogBytesHardLimit = 256 * 1024;
static constexpr int32 MaxDirtyPackages = 128;
static constexpr int32 MaxScriptArgumentsChars = 32 * 1024;

void ResetError(FString& OutErrorCode, FString& OutErrorMessage)
{
    OutErrorCode.Reset();
    OutErrorMessage.Reset();
}

FString JsonString(const TSharedRef<FJsonObject>& Object)
{
    FString Text;
    const TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Text);
    FJsonSerializer::Serialize(Object, Writer);
    return Text;
}

FString PythonLiteral(FString Value)
{
    Value.ReplaceInline(TEXT("\\"), TEXT("\\\\"));
    Value.ReplaceInline(TEXT("'"), TEXT("\\'"));
    Value.ReplaceInline(TEXT("\r"), TEXT("\\r"));
    Value.ReplaceInline(TEXT("\n"), TEXT("\\n"));
    return FString::Printf(TEXT("'%s'"), *Value);
}

FLevelEditorViewportClient* FindLevelViewportClient(FString& OutSource)
{
    if (!GEditor)
    {
        return nullptr;
    }
    FViewport* ActiveViewport = GEditor->GetActiveViewport();
    const TArray<FLevelEditorViewportClient*>& Clients = GEditor->GetLevelViewportClients();
    for (FLevelEditorViewportClient* Candidate : Clients)
    {
        if (Candidate && Candidate->Viewport && Candidate->Viewport == ActiveViewport)
        {
            OutSource = TEXT("active_level_viewport");
            return Candidate;
        }
    }
    if (Clients.Contains(GCurrentLevelEditingViewportClient)
        && GCurrentLevelEditingViewportClient
        && GCurrentLevelEditingViewportClient->Viewport)
    {
        OutSource = TEXT("last_active_level_viewport");
        return GCurrentLevelEditingViewportClient;
    }
    return nullptr;
}

FString PIEState()
{
    if (!GEditor)
    {
        return TEXT("unavailable");
    }
    if (GEditor->IsPlaySessionRequestQueued())
    {
        return GEditor->IsSimulateInEditorQueued() ? TEXT("simulate_queued") : TEXT("play_queued");
    }
    if (GEditor->PlayWorld)
    {
        return GEditor->bIsSimulatingInEditor ? TEXT("simulating") : TEXT("playing");
    }
    return TEXT("stopped");
}

bool ReadBool(const TSharedPtr<FJsonObject>& Arguments, const TCHAR* Name, bool DefaultValue)
{
    bool Value = DefaultValue;
    if (Arguments.IsValid())
    {
        Arguments->TryGetBoolField(Name, Value);
    }
    return Value;
}
}

TSharedPtr<FJsonObject> InspectEditorState(
    const TSharedPtr<FJsonObject>& /*Arguments*/,
    FString& OutErrorCode,
    FString& OutErrorMessage)
{
    ResetError(OutErrorCode, OutErrorMessage);
    if (!GEditor)
    {
        OutErrorCode = TEXT("EDITOR_UNAVAILABLE");
        OutErrorMessage = TEXT("GEditor is unavailable.");
        return nullptr;
    }

    TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();
    Root->SetStringField(TEXT("schema_version"), TEXT("aibridge_ue_editor_state/1"));
    Root->SetStringField(TEXT("project_file"), FPaths::ConvertRelativePathToFull(FPaths::GetProjectFilePath()));
    Root->SetStringField(TEXT("pie_state"), PIEState());
    Root->SetBoolField(TEXT("play_session_in_progress"), GEditor->IsPlaySessionInProgress());
    Root->SetNumberField(TEXT("asset_compile_remaining"), FAssetCompilingManager::Get().GetNumRemainingAssets());
    Root->SetStringField(TEXT("log_file"), FPlatformOutputDevices::GetAbsoluteLogFilename());

    UWorld* World = GEditor->GetEditorWorldContext().World();
    Root->SetStringField(TEXT("editor_world"), IsValid(World) ? World->GetPathName() : FString());

    FString ViewportSource;
    FLevelEditorViewportClient* ViewportClient = FindLevelViewportClient(ViewportSource);
    Root->SetBoolField(TEXT("level_viewport_available"), ViewportClient != nullptr);
    Root->SetStringField(TEXT("level_viewport_source"), ViewportSource);

    TArray<UPackage*> DirtyPackages;
    FEditorFileUtils::GetDirtyPackages(DirtyPackages);
    TArray<TSharedPtr<FJsonValue>> DirtyNames;
    for (int32 Index = 0; Index < FMath::Min(DirtyPackages.Num(), MaxDirtyPackages); ++Index)
    {
        if (DirtyPackages[Index])
        {
            DirtyNames.Add(MakeShared<FJsonValueString>(DirtyPackages[Index]->GetName()));
        }
    }
    Root->SetNumberField(TEXT("dirty_package_count"), DirtyPackages.Num());
    Root->SetBoolField(TEXT("dirty_packages_truncated"), DirtyPackages.Num() > MaxDirtyPackages);
    Root->SetArrayField(TEXT("dirty_packages"), DirtyNames);
    return Root;
}

TSharedPtr<FJsonObject> ReadEditorLog(
    const TSharedPtr<FJsonObject>& Arguments,
    FString& OutErrorCode,
    FString& OutErrorMessage)
{
    ResetError(OutErrorCode, OutErrorMessage);
    const FString EditorLogPath = FPlatformOutputDevices::GetAbsoluteLogFilename();
    const int64 FileSize = IFileManager::Get().FileSize(*EditorLogPath);
    if (FileSize < 0)
    {
        OutErrorCode = TEXT("EDITOR_LOG_UNAVAILABLE");
        OutErrorMessage = FString::Printf(TEXT("Editor log is unavailable: %s"), *EditorLogPath);
        return nullptr;
    }

    double CursorNumber = -1.0;
    double MaxBytesNumber = 64.0 * 1024.0;
    if (Arguments.IsValid())
    {
        Arguments->TryGetNumberField(TEXT("cursor"), CursorNumber);
        Arguments->TryGetNumberField(TEXT("max_bytes"), MaxBytesNumber);
    }
    const int64 MaxBytes = FMath::Clamp<int64>(static_cast<int64>(MaxBytesNumber), 1024, MaxLogBytesHardLimit);
    bool bCursorReset = CursorNumber < 0.0 || CursorNumber > static_cast<double>(FileSize);
    int64 Start = bCursorReset
        ? FMath::Max<int64>(0, FileSize - MaxBytes)
        : FMath::Clamp<int64>(static_cast<int64>(CursorNumber), 0, FileSize);
    if (FileSize - Start > MaxBytes)
    {
        Start = FileSize - MaxBytes;
        bCursorReset = true;
    }

    TUniquePtr<IFileHandle> Handle(FPlatformFileManager::Get().GetPlatformFile().OpenRead(*EditorLogPath));
    if (!Handle || !Handle->Seek(Start))
    {
        OutErrorCode = TEXT("EDITOR_LOG_READ_FAILED");
        OutErrorMessage = TEXT("Failed to open or seek the current editor log.");
        return nullptr;
    }
    const int64 BytesToRead = FileSize - Start;
    TArray<uint8> Buffer;
    Buffer.SetNumUninitialized(static_cast<int32>(BytesToRead + 1));
    if (BytesToRead > 0 && !Handle->Read(Buffer.GetData(), BytesToRead))
    {
        OutErrorCode = TEXT("EDITOR_LOG_READ_FAILED");
        OutErrorMessage = TEXT("Failed to read the current editor log.");
        return nullptr;
    }
    Buffer[static_cast<int32>(BytesToRead)] = 0;
    FString Text = UTF8_TO_TCHAR(reinterpret_cast<const ANSICHAR*>(Buffer.GetData()));
    if (Start > 0 && bCursorReset)
    {
        int32 Newline = INDEX_NONE;
        if (Text.FindChar(TEXT('\n'), Newline))
        {
            Text.RightChopInline(Newline + 1, EAllowShrinking::No);
        }
    }

    TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();
    Root->SetStringField(TEXT("schema_version"), TEXT("aibridge_ue_log/1"));
    Root->SetStringField(TEXT("path"), EditorLogPath);
    Root->SetNumberField(TEXT("cursor"), static_cast<double>(Start));
    Root->SetNumberField(TEXT("next_cursor"), static_cast<double>(FileSize));
    Root->SetNumberField(TEXT("file_size"), static_cast<double>(FileSize));
    Root->SetBoolField(TEXT("cursor_reset"), bCursorReset);
    Root->SetStringField(TEXT("text"), Text);
    return Root;
}

TSharedPtr<FJsonObject> CaptureEditorViewport(
    const TSharedPtr<FJsonObject>& /*Arguments*/,
    FString& OutErrorCode,
    FString& OutErrorMessage)
{
    ResetError(OutErrorCode, OutErrorMessage);
    FString Source;
    FLevelEditorViewportClient* Client = FindLevelViewportClient(Source);
    if (!Client || !Client->Viewport)
    {
        OutErrorCode = TEXT("LEVEL_VIEWPORT_UNAVAILABLE");
        OutErrorMessage = TEXT("No active or last-active level viewport is available.");
        return nullptr;
    }
    const FIntPoint Size = Client->Viewport->GetSizeXY();
    if (Size.X <= 0 || Size.Y <= 0)
    {
        OutErrorCode = TEXT("LEVEL_VIEWPORT_EMPTY");
        OutErrorMessage = TEXT("The level viewport has no drawable area.");
        return nullptr;
    }
    TArray<FColor> Pixels;
    if (!Client->Viewport->ReadPixels(Pixels) || Pixels.Num() != Size.X * Size.Y)
    {
        OutErrorCode = TEXT("LEVEL_VIEWPORT_CAPTURE_FAILED");
        OutErrorMessage = TEXT("The level viewport pixel readback failed.");
        return nullptr;
    }

    TArray64<uint8> Png;
    FImageUtils::PNGCompressImageArray(
        Size.X,
        Size.Y,
        TArrayView64<const FColor>(Pixels.GetData(), Pixels.Num()),
        Png);
    const FString Directory = FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("AI_Bridge/Captures"));
    IFileManager::Get().MakeDirectory(*Directory, true);
    const FString Path = FPaths::Combine(
        Directory,
        FString::Printf(TEXT("viewport-%s-%s.png"),
            *FDateTime::UtcNow().ToString(TEXT("%Y%m%dT%H%M%SZ")),
            *FGuid::NewGuid().ToString(EGuidFormats::Digits).Left(8)));
    if (Png.IsEmpty() || !FFileHelper::SaveArrayToFile(Png, *Path))
    {
        OutErrorCode = TEXT("LEVEL_VIEWPORT_CAPTURE_SAVE_FAILED");
        OutErrorMessage = FString::Printf(TEXT("Failed to save viewport capture: %s"), *Path);
        return nullptr;
    }

    TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();
    Root->SetStringField(TEXT("schema_version"), TEXT("aibridge_ue_viewport_capture/1"));
    Root->SetStringField(TEXT("path"), Path);
    Root->SetStringField(TEXT("source"), Source);
    Root->SetNumberField(TEXT("width"), Size.X);
    Root->SetNumberField(TEXT("height"), Size.Y);
    Root->SetNumberField(TEXT("bytes"), static_cast<double>(Png.Num()));
    Root->SetStringField(TEXT("pie_state"), PIEState());
    return Root;
}

TSharedPtr<FJsonObject> ControlPIE(
    const TSharedPtr<FJsonObject>& Arguments,
    FString& OutErrorCode,
    FString& OutErrorMessage)
{
    ResetError(OutErrorCode, OutErrorMessage);
    if (!GEditor)
    {
        OutErrorCode = TEXT("EDITOR_UNAVAILABLE");
        OutErrorMessage = TEXT("GEditor is unavailable.");
        return nullptr;
    }
    FString Action = TEXT("query");
    if (Arguments.IsValid())
    {
        Arguments->TryGetStringField(TEXT("action"), Action);
    }
    Action.ToLowerInline();
    const FString Before = PIEState();
    if (Action == TEXT("start"))
    {
        if (GEditor->IsPlaySessionInProgress())
        {
            OutErrorCode = TEXT("PIE_ALREADY_ACTIVE");
            OutErrorMessage = TEXT("A PIE session is already active or queued.");
            return nullptr;
        }
        if (FAssetCompilingManager::Get().GetNumRemainingAssets() > 0)
        {
            OutErrorCode = TEXT("ASSET_COMPILATION_IN_PROGRESS");
            OutErrorMessage = TEXT("PIE start was refused while assets are still compiling.");
            return nullptr;
        }
        FRequestPlaySessionParams Params;
        Params.WorldType = ReadBool(Arguments, TEXT("simulate"), false)
            ? EPlaySessionWorldType::SimulateInEditor
            : EPlaySessionWorldType::PlayInEditor;
        GEditor->RequestPlaySession(Params);
    }
    else if (Action == TEXT("stop"))
    {
        if (GEditor->IsPlaySessionRequestQueued() && !GEditor->PlayWorld)
        {
            GEditor->CancelRequestPlaySession();
        }
        else if (GEditor->PlayWorld)
        {
            GEditor->RequestEndPlayMap();
        }
    }
    else if (Action != TEXT("query"))
    {
        OutErrorCode = TEXT("PIE_ACTION_UNSUPPORTED");
        OutErrorMessage = TEXT("Supported PIE actions are query, start, and stop.");
        return nullptr;
    }

    TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();
    Root->SetStringField(TEXT("schema_version"), TEXT("aibridge_ue_pie/1"));
    Root->SetStringField(TEXT("action"), Action);
    Root->SetStringField(TEXT("state_before"), Before);
    Root->SetStringField(TEXT("state_after_request"), PIEState());
    Root->SetBoolField(TEXT("request_accepted"), true);
    Root->SetBoolField(TEXT("asynchronous"), Action != TEXT("query"));
    return Root;
}

TSharedPtr<FJsonObject> ExecuteRegisteredReadOnlyScript(
    const TSharedPtr<FJsonObject>& Arguments,
    FString& OutErrorCode,
    FString& OutErrorMessage)
{
    ResetError(OutErrorCode, OutErrorMessage);
    FString Action;
    if (!Arguments.IsValid() || !Arguments->TryGetStringField(TEXT("action"), Action)
        || Action.IsEmpty() || Action.Len() > 96)
    {
        OutErrorCode = TEXT("REGISTERED_ACTION_REQUIRED");
        OutErrorMessage = TEXT("A bounded registered action name is required.");
        return nullptr;
    }
    for (TCHAR Char : Action)
    {
        if (!(FChar::IsAlnum(Char) || Char == TEXT('.') || Char == TEXT('_') || Char == TEXT('-')))
        {
            OutErrorCode = TEXT("REGISTERED_ACTION_INVALID");
            OutErrorMessage = TEXT("The action name contains unsupported characters.");
            return nullptr;
        }
    }

    const FString RegistryPath = FPaths::Combine(FPaths::ProjectConfigDir(), TEXT("AIBridgeUEActions.json"));
    FString RegistryText;
    TSharedPtr<FJsonObject> Registry;
    if (!FFileHelper::LoadFileToString(RegistryText, *RegistryPath)
        || !FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(RegistryText), Registry)
        || !Registry.IsValid()
        || !Registry->HasTypedField<EJson::Object>(TEXT("actions")))
    {
        OutErrorCode = TEXT("REGISTERED_ACTIONS_UNAVAILABLE");
        OutErrorMessage = FString::Printf(TEXT("Registered action manifest is missing or invalid: %s"), *RegistryPath);
        return nullptr;
    }
    const TSharedPtr<FJsonObject> Actions = Registry->GetObjectField(TEXT("actions"));
    if (!Actions->HasTypedField<EJson::Object>(Action))
    {
        OutErrorCode = TEXT("REGISTERED_ACTION_UNKNOWN");
        OutErrorMessage = FString::Printf(TEXT("Unknown registered action: %s"), *Action);
        return nullptr;
    }
    const TSharedPtr<FJsonObject> Spec = Actions->GetObjectField(Action);
    FString RelativeScript;
    bool bReadOnly = false;
    Spec->TryGetStringField(TEXT("script"), RelativeScript);
    Spec->TryGetBoolField(TEXT("read_only"), bReadOnly);
    RelativeScript.ReplaceInline(TEXT("\\"), TEXT("/"));
    if (!bReadOnly || !RelativeScript.StartsWith(TEXT("Scripts/AIBridgeUE/"))
        || !RelativeScript.EndsWith(TEXT(".py")) || RelativeScript.Contains(TEXT("..")))
    {
        OutErrorCode = TEXT("REGISTERED_ACTION_REFUSED");
        OutErrorMessage = TEXT("Only read-only Python actions under Scripts/AIBridgeUE may run through this operation.");
        return nullptr;
    }
    const FString ProjectRoot = FPaths::ConvertRelativePathToFull(FPaths::ProjectDir());
    const FString ScriptPath = FPaths::ConvertRelativePathToFull(FPaths::Combine(ProjectRoot, RelativeScript));
    if (!FPaths::IsUnderDirectory(ScriptPath, ProjectRoot) || !IFileManager::Get().FileExists(*ScriptPath))
    {
        OutErrorCode = TEXT("REGISTERED_ACTION_SCRIPT_MISSING");
        OutErrorMessage = FString::Printf(TEXT("Registered action script is unavailable: %s"), *RelativeScript);
        return nullptr;
    }

    TSharedRef<FJsonObject> ScriptArguments = MakeShared<FJsonObject>();
    if (Arguments->HasTypedField<EJson::Object>(TEXT("arguments")))
    {
        ScriptArguments = Arguments->GetObjectField(TEXT("arguments")).ToSharedRef();
    }
    const FString ArgumentsJson = JsonString(ScriptArguments);
    if (ArgumentsJson.Len() > MaxScriptArgumentsChars)
    {
        OutErrorCode = TEXT("REGISTERED_ACTION_ARGUMENTS_TOO_LARGE");
        OutErrorMessage = TEXT("Registered action arguments exceed 32 KiB.");
        return nullptr;
    }

    IPythonScriptPlugin* Python = IPythonScriptPlugin::Get();
    if (!Python || (!Python->IsPythonAvailable() && !Python->ForceEnablePythonAtRuntime()))
    {
        OutErrorCode = TEXT("PYTHON_UNAVAILABLE");
        OutErrorMessage = TEXT("PythonScriptPlugin is unavailable in the editor.");
        return nullptr;
    }
    FPythonCommandEx Command;
    Command.Flags = EPythonCommandFlags::Unattended;
    Command.ExecutionMode = EPythonCommandExecutionMode::ExecuteStatement;
    Command.Command = FString::Printf(
        TEXT("import json,runpy; _m=runpy.run_path(%s); print(json.dumps(_m['run_bridge'](json.loads(%s)), ensure_ascii=False))"),
        *PythonLiteral(ScriptPath),
        *PythonLiteral(ArgumentsJson));
    if (!Python->ExecPythonCommandEx(Command))
    {
        OutErrorCode = TEXT("REGISTERED_ACTION_EXCEPTION");
        OutErrorMessage = Command.CommandResult.Left(2048);
        return nullptr;
    }
    TSharedPtr<FJsonObject> Result;
    for (int32 Index = Command.LogOutput.Num() - 1; Index >= 0; --Index)
    {
        TSharedPtr<FJsonObject> Candidate;
        if (FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Command.LogOutput[Index].Output), Candidate)
            && Candidate.IsValid())
        {
            Result = MoveTemp(Candidate);
            break;
        }
    }
    if (!Result.IsValid())
    {
        OutErrorCode = TEXT("REGISTERED_ACTION_INVALID_RESULT");
        OutErrorMessage = TEXT("The registered action returned no JSON object.");
        return nullptr;
    }
    Result->SetStringField(TEXT("registered_action"), Action);
    Result->SetBoolField(TEXT("read_only"), true);
    return Result;
}
}
