﻿#include "AIBridgeUELandscapeMaterialRepair.h"
#include "Commandlets/Commandlet.h"
#include "ComponentRecreateRenderStateContext.h"
#include "Engine/Texture2D.h"
#include "HAL/FileManager.h"
#include "HAL/PlatformMemory.h"
#include "Landscape.h"
#include "LandscapeComponent.h"
#include "LandscapeEdit.h"
#include "LandscapeLayerInfoObject.h"
#include "LandscapeMaterialInstanceConstant.h"
#include "LandscapeStreamingProxy.h"
#include "MaterialShared.h"
#include "RenderingThread.h"
#include "TextureResource.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Misc/CommandLine.h"
#include "Misc/DateTime.h"
#include "Misc/FileHelper.h"
#include "Misc/FeedbackContext.h"
#include "Misc/PackageName.h"
#include "Misc/Paths.h"
#include "Misc/SecureHash.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Shader.h"
#include "ShaderCompiler.h"
#include "UObject/SavePackage.h"
#include "UObject/UnrealType.h"
#include "UObject/UObjectIterator.h"
#include "VertexFactory.h"
#include "WorldPartition/WorldPartition.h"
#include "WorldPartition/WorldPartitionActorDescInstance.h"
#include "WorldPartition/WorldPartitionHelpers.h"

DEFINE_LOG_CATEGORY_STATIC(LogLandscapeMaterialRepair, Log, All);
namespace AIBridgeUE::LandscapeMaterialRepair
{
namespace
{
using FJson = TSharedPtr<FJsonObject>;
bool WriteJson(const FString& Path, const FJson& Json)
{
    FString Text;
    IFileManager::Get().MakeDirectory(*FPaths::GetPath(Path), true);
    return FJsonSerializer::Serialize(Json.ToSharedRef(), TJsonWriterFactory<>::Create(&Text))
        && FFileHelper::SaveStringToFile(Text, *(Path + TEXT(".tmp")), FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM)
        && IFileManager::Get().Move(*Path, *(Path + TEXT(".tmp")), true, false, false, true);
}
FString FileHash(const FString& Path)
{
    TArray<uint8> Bytes;
    return FFileHelper::LoadFileToArray(Bytes, *Path) ? FSHA1::HashBuffer(Bytes.GetData(), Bytes.Num()).ToString() : FString();
}
FString RecordsHash(TArray<FString> Records)
{
    Records.Sort();
    const FTCHARToUTF8 Text(*FString::Join(Records, TEXT("\n")));
    return FSHA1::HashBuffer(Text.Get(), Text.Length()).ToString();
}
bool TextureHash(UTexture2D* Texture, FString& Hash)
{
    if (!Texture || Texture->Source.GetFormat() != TSF_BGRA8 || Texture->Source.GetNumLayers() != 1
        || Texture->Source.GetNumSlices() != 1 || Texture->Source.GetNumMips() < 1) return false;
    TArray<FString> Mips;
    for (int32 Mip = 0; Mip < Texture->Source.GetNumMips(); ++Mip)
    {
        const uint8* Data = Texture->Source.LockMipReadOnly(Mip);
        if (!Data) return false;
        const int64 Size = int64(FMath::Max(1, Texture->Source.GetSizeX() >> Mip))
            * FMath::Max(1, Texture->Source.GetSizeY() >> Mip) * 4;
        Mips.Add(FSHA1::HashBuffer(Data, Size).ToString());
        Texture->Source.UnlockMip(Mip);
    }
    Mips.Add(FString::Printf(TEXT("%d:%d"), Texture->Source.GetSizeX(), Texture->Source.GetSizeY()));
    Hash = RecordsHash(MoveTemp(Mips));
    return true;
}
bool PaintHash(UTexture2D* Texture, int32 Channel, FString& Hash, bool& AllZero)
{
    static constexpr int32 Offsets[] = {2, 1, 0, 3};
    if (!Texture || Channel < 0 || Channel > 3 || Texture->Source.GetFormat() != TSF_BGRA8
        || Texture->Source.GetNumLayers() != 1 || Texture->Source.GetNumSlices() != 1
        || Texture->Source.GetSizeX() != Texture->Source.GetSizeY()) return false;
    const uint8* Data = Texture->Source.LockMipReadOnly(0);
    if (!Data) return false;
    const int64 Count = int64(Texture->Source.GetSizeX()) * Texture->Source.GetSizeY();
    TArray<uint8> Plane;
    if (Count <= 0 || Count > 16 * 1024 * 1024) { Texture->Source.UnlockMip(0); return false; }
    Plane.SetNumUninitialized(int32(Count)); AllZero = true;
    for (int32 Pixel = 0; Pixel < Count; ++Pixel)
    {
        Plane[Pixel] = Data[Pixel * 4 + Offsets[Channel]];
        AllZero &= Plane[Pixel] == 0;
    }
    Texture->Source.UnlockMip(0);
    Hash = FSHA1::HashBuffer(Plane.GetData(), Plane.Num()).ToString();
    return true;
}
struct FSnapshot
{
    FString ProtectedHash;
    TMap<FString, FString> NonzeroPaint;
    TMap<FString, FString> AllPaint;
};
bool Snapshot(ULandscapeComponent* Component, FSnapshot& Out, FString& Error)
{
    if (FMapProperty* Obsolete = FindFProperty<FMapProperty>(Component->GetClass(), TEXT("ObsoleteEditLayerData")))
        if (FScriptMapHelper(Obsolete, Obsolete->ContainerPtrToValuePtr<void>(Component)).Num() != 0)
        { Error = TEXT("ORPHAN_EDIT_LAYER_REPAIR_REQUIRED"); return false; }
    TArray<FString> Protected;
    FString HeightHash;
    if (!TextureHash(Component->GetHeightmap(false), HeightHash)) { Error = TEXT("HEIGHT_SOURCE_UNSUPPORTED"); return false; }
    Protected.Add(TEXT("final-height:") + HeightHash);
    Protected.Add(Component->GetComponentTransform().ToString());
    bool SourcesOk = true; int32 SourceCount = 0;
    Component->ForEachLayer([&](const FGuid& Guid, FLandscapeLayerComponentData& Layer)
    {
        ++SourceCount;
        FString Hash;
        const FString Prefix = Guid.ToString(EGuidFormats::Digits) + TEXT(":");
        if (!TextureHash(Layer.HeightmapData.Texture, Hash)) { SourcesOk = false; return; }
        Protected.Add(Prefix + TEXT("height:") + Hash);
        for (const FWeightmapLayerAllocationInfo& Allocation : Layer.WeightmapData.LayerAllocations)
        {
            if (!Allocation.LayerInfo || !Layer.WeightmapData.Textures.IsValidIndex(Allocation.WeightmapTextureIndex))
            { SourcesOk = false; return; }
            UTexture2D* Texture = Layer.WeightmapData.Textures[Allocation.WeightmapTextureIndex];
            bool Zero;
            if (!PaintHash(Texture, Allocation.WeightmapTextureChannel, Hash, Zero)) { SourcesOk = false; return; }
            Protected.Add(Prefix + Allocation.LayerInfo->GetPathName() + TEXT(":") + Texture->GetName()
                + FString::Printf(TEXT(":%d:%d:"), Allocation.WeightmapTextureIndex, Allocation.WeightmapTextureChannel) + Hash);
        }
    });
    if (!SourcesOk || SourceCount == 0) { Error = TEXT("EDIT_LAYER_SOURCE_UNSUPPORTED"); return false; }
    const auto& Textures = Component->GetWeightmapTextures(FGuid());
    TSet<FString> FinalLayerKeys;
    for (const FWeightmapLayerAllocationInfo& Allocation : Component->GetWeightmapLayerAllocations(FGuid()))
    {
        if (!Allocation.LayerInfo || !Textures.IsValidIndex(Allocation.WeightmapTextureIndex))
        { Error = TEXT("FINAL_ALLOCATION_INVALID"); return false; }
        FString Hash; bool Zero;
        if (!PaintHash(Textures[Allocation.WeightmapTextureIndex], Allocation.WeightmapTextureChannel, Hash, Zero))
        { Error = TEXT("FINAL_SOURCE_UNSUPPORTED"); return false; }
        const FString Key = Allocation.LayerInfo->GetPathName();
        if (FinalLayerKeys.Contains(Key)) { Error = TEXT("DUPLICATE_FINAL_LAYER"); return false; }
        FinalLayerKeys.Add(Key);
        Out.AllPaint.Add(Key, Hash);
        if (!Zero) Out.NonzeroPaint.Add(Key, Hash);
    }
    Out.ProtectedHash = RecordsHash(MoveTemp(Protected));
    return true;
}
bool Same(const FSnapshot& Before, const FSnapshot& After)
{
    if (Before.ProtectedHash != After.ProtectedHash || Before.NonzeroPaint.Num() != After.NonzeroPaint.Num()) return false;
    for (const auto& Pair : Before.NonzeroPaint)
    {
        const FString* Hash = After.NonzeroPaint.Find(Pair.Key);
        if (!Hash || *Hash != Pair.Value) return false;
    }
    return true;
}
bool TargetShader(ULandscapeComponent* Component, FJson Row)
{
    UMaterialInterface* Parent = Component->GetLandscapeMaterial();
    const FShaderType* Shader = FShaderType::GetShaderTypeByName(TEXT("TVirtualTexturePSBaseColorNormalSpecular"));
    const FVertexFactoryType* VF = FVertexFactoryType::GetVFByName(FHashedName(TEXT("FLandscapeFixedGridVertexFactory")));
    if (!Parent || !Shader || !VF) { Row->SetStringField(TEXT("shader_error"), TEXT("TARGET_SHADER_UNSUPPORTED")); return false; }
    ULandscapeMaterialInstanceConstant* Clone = NewObject<ULandscapeMaterialInstanceConstant>(GetTransientPackage(), NAME_None, RF_Transient);
    Clone->AddToRoot(); Clone->SetParentEditorOnly(Parent, false);
    FStaticParameterSet Static;
    Clone->GetStaticParameterValues(Static);
    Static.EditorOnly.TerrainLayerWeightParameters.Empty();
    for (const auto& Allocation : Component->GetWeightmapLayerAllocations(FGuid()))
        Static.EditorOnly.TerrainLayerWeightParameters.Add(FStaticTerrainLayerWeightParameter(Allocation.LayerInfo->GetLayerName(), Allocation.WeightmapTextureIndex));
    Clone->UpdateStaticPermutation(Static);
    // Shader maps are shared by permutation, including component instances and this clone.
    // Cancelling all materials discards shared job results that a later save check needs.
    // Keep compilation alive; wait only for the requested resource below.
    Clone->CacheGivenTypesForCooking(SP_PCD3D_SM6, ERHIFeatureLevel::SM6, EMaterialQualityLevel::High, {VF}, {nullptr}, {Shader});
    FMaterialResource* Resource = Clone->GetMaterialResource(SP_PCD3D_SM6, EMaterialQualityLevel::High);
    bool Available = false;
    TArray<TSharedPtr<FJsonValue>> Errors;
    if (Resource)
    {
        Resource->FinishCacheShaders(); Resource->FinishCompilation();
        const FMaterialShaderMap* Map = Resource->GetGameThreadShaderMap();
        const FMeshMaterialShaderMap* Mesh = Map ? Map->GetMeshShaderMap(VF) : nullptr;
        Available = Mesh && Mesh->HasShader(Shader, 0);
        Row->SetBoolField(TEXT("shader_map_present"), Map != nullptr);
        Row->SetBoolField(TEXT("shader_mesh_map_present"), Mesh != nullptr);
        Row->SetBoolField(TEXT("shader_map_complete"), Resource->IsGameThreadShaderMapComplete());
        for (const FString& Error : Resource->GetCompileErrors()) Errors.Add(MakeShared<FJsonValueString>(Error));
        Row->SetStringField(TEXT("shader_debug_group"), Resource->GetDebugGroupName());
    }
    Row->SetBoolField(TEXT("shader_resource_present"), Resource != nullptr);
    Row->SetBoolField(TEXT("target_shader_available"), Available);
    Row->SetArrayField(TEXT("shader_errors"), Errors);
    Row->SetStringField(TEXT("shader_scope"), TEXT("DX12 SM6 High / FLandscapeFixedGridVertexFactory / TVirtualTexturePSBaseColorNormalSpecular / permutation 0"));
    if (!Available || !Errors.IsEmpty())
    {
        Row->SetStringField(TEXT("shader_error"), !Errors.IsEmpty() ? TEXT("TARGET_SHADER_COMPILE_ERROR")
            : Resource ? TEXT("TARGET_SHADER_MISSING_WITHOUT_COMPILE_ERROR") : TEXT("TARGET_SHADER_RESOURCE_MISSING"));
        UE_LOG(LogLandscapeMaterialRepair, Error, TEXT("Target shader gate: %s in %s; available=%d errors=%d"),
            *Component->GetName(), *Component->GetOutermost()->GetName(), Available, Errors.Num());
    }
    Clone->RemoveFromRoot();
    return Available && Errors.IsEmpty();
}

// Compare the serialized grass height plane with the final heightmap source. This
// recognizes the measured edge-clamp corruption; arbitrary WPO differences are
// reported separately and are never automatically treated as damaged terrain.
bool AnalyseGrass(ULandscapeComponent* Component, const FJson& Row, const FString& Prefix, bool& EdgeCorrupt, FString& Error)
{
    EdgeCorrupt = false;
    UTexture2D* Texture = Component->GetHeightmap(false);
    const int32 Sub = Component->SubsectionSizeQuads, Sections = Component->NumSubsections;
    const int32 Side = Sub * Sections + 1;
    if (!Texture || Texture->Source.GetFormat() != TSF_BGRA8 || Sub < 1 || Sections < 1 || Sections > 8 || Side > 2049)
    { Error = TEXT("GRASS_HEIGHT_SOURCE_UNSUPPORTED"); return false; }
    const int32 Width = Texture->Source.GetSizeX(), Height = Texture->Source.GetSizeY();
    const FVector4 Bias = Component->HeightmapScaleBias;
    const int32 Left = FMath::RoundToInt(Bias.Z * Width), Top = FMath::RoundToInt(Bias.W * Height);
    if (Width < 1 || Height < 1 || Left < 0 || Top < 0 || Left + (Sub + 1) * Sections > Width || Top + (Sub + 1) * Sections > Height)
    { Error = TEXT("GRASS_HEIGHT_SOURCE_CROP_INVALID"); return false; }
    Row->SetNumberField(TEXT("section_x"), Component->GetSectionBase().X);
    Row->SetNumberField(TEXT("section_y"), Component->GetSectionBase().Y);
    Row->SetNumberField(TEXT("height_samples"), Side * Side);
    Row->SetNumberField(Prefix + TEXT("source_size_x"), Width);
    Row->SetNumberField(Prefix + TEXT("source_size_y"), Height);
    const auto& Grass = *Component->GrassData;
    Row->SetNumberField(Prefix + TEXT("grass_elements"), Grass.NumElements);
    Row->SetNumberField(Prefix + TEXT("grass_bytes"), Grass.HeightWeightData.Num());
    Row->SetNumberField(Prefix + TEXT("grass_weight_planes"), Grass.WeightOffsets.Num());
    Row->SetNumberField(Prefix + TEXT("grass_type_count"), Component->GetNamedGrassTypes().Num());
    Row->SetBoolField(Prefix + TEXT("grass_summary_has_grass"), Component->GrassTypeSummary.bHasAnyGrass);
    Row->SetBoolField(Prefix + TEXT("grass_summary_invalid"), Component->GrassTypeSummary.bInvalid);
    Row->SetBoolField(Prefix + TEXT("scene_proxy_present"), Component->GetSceneProxy() != nullptr);
    Row->SetBoolField(Prefix + TEXT("component_registered"), Component->IsRegistered());
    Row->SetBoolField(Prefix + TEXT("can_render_grass"), Component->CanRenderGrassMap());
    if (UMaterialInterface* Material = Component->GetMaterialInstance(0))
    {
        Row->SetStringField(Prefix + TEXT("runtime_material"), Material->GetPathName());
        if (const FMaterialResource* Resource = Material->GetMaterialResource(SP_PCD3D_SM6))
        {
            Row->SetBoolField(Prefix + TEXT("material_shader_map_present"), Resource->GetGameThreadShaderMap() != nullptr);
            TArray<TSharedPtr<FJsonValue>> Errors;
            for (const FString& Message : Resource->GetCompileErrors()) Errors.Add(MakeShared<FJsonValueString>(Message));
            Row->SetArrayField(Prefix + TEXT("material_compile_errors"), Errors);
        }
    }
    if (Grass.NumElements != Side * Side || Grass.HeightWeightData.Num() < Side * Side * 2)
    {
        Row->SetStringField(Prefix + TEXT("grass_status"), Grass.NumElements == 0 ? TEXT("empty_grass") : TEXT("missing_cache"));
        Row->SetNumberField(Prefix + TEXT("different_height_samples"), 0);
        return true;
    }
    const uint8* Source = Texture->Source.LockMipReadOnly(0);
    if (!Source) { Error = TEXT("GRASS_HEIGHT_SOURCE_READ_FAILED"); return false; }
    const auto ReadHeight = [&](int32 X, int32 Y)
    {
        const uint8* Pixel = Source + (int64(Y) * Width + X) * 4;
        return uint16(uint16(Pixel[2]) * 256 + Pixel[1]); // BGRA8 height R/G
    };
    int32 Different = 0, EdgeMatches = 0, Minimum = 0, Maximum = 0;
    for (int32 Y = 0; Y < Side; ++Y) for (int32 X = 0; X < Side; ++X)
    {
        const int32 SX = Left + X + FMath::Min(X / Sub, Sections - 1);
        const int32 SY = Top + Y + FMath::Min(Y / Sub, Sections - 1);
        uint16 Actual;
        FMemory::Memcpy(&Actual, Grass.HeightWeightData.GetData() + (Y * Side + X) * 2, sizeof(Actual));
        const int32 Delta = int32(Actual) - ReadHeight(SX, SY);
        Different += Delta != 0; Minimum = FMath::Min(Minimum, Delta); Maximum = FMath::Max(Maximum, Delta);
        EdgeMatches += Actual == ReadHeight(X >= Sub ? Width - 1 : SX, Y >= Sub ? Height - 1 : SY);
    }
    Texture->Source.UnlockMip(0);
    EdgeCorrupt = Different > 0 && Sections > 1 && EdgeMatches == Side * Side;
    Row->SetNumberField(Prefix + TEXT("different_height_samples"), Different);
    Row->SetNumberField(Prefix + TEXT("edge_clamp_matching_samples"), EdgeMatches);
    const double Scale = Component->GetComponentTransform().GetScale3D().Z / 128.0;
    Row->SetNumberField(Prefix + TEXT("height_delta_min_cm"), Minimum * Scale);
    Row->SetNumberField(Prefix + TEXT("height_delta_max_cm"), Maximum * Scale);
    Row->SetStringField(Prefix + TEXT("grass_status"), Different == 0 ? TEXT("source_height_match")
        : EdgeCorrupt ? TEXT("edge_clamped") : TEXT("unclassified_height_difference"));
    return true;
}

bool PrepareGrassRendering(ALandscapeStreamingProxy* Proxy, const FJson& Report, FString& Error, bool RecreateProxy = true)
{
    TSet<UTexture2D*> Textures;
    TArray<TSharedPtr<FJsonValue>> Sizes;
    for (ULandscapeComponent* Component : Proxy->LandscapeComponents) if (Component)
    {
        UTexture2D* Height = Component->GetHeightmap(false);
        if (!Height) { Error = TEXT("GRASS_HEIGHTMAP_MISSING"); return false; }
        auto Row = MakeShared<FJsonObject>();
        Row->SetStringField(TEXT("component"), Component->GetPathName());
        Row->SetNumberField(TEXT("source_x"), Height->Source.GetSizeX());
        Row->SetNumberField(TEXT("source_y"), Height->Source.GetSizeY());
        Row->SetNumberField(TEXT("runtime_before_x"), Height->GetSizeX());
        Row->SetNumberField(TEXT("runtime_before_y"), Height->GetSizeY());
        Sizes.Add(MakeShared<FJsonValueObject>(Row));
        Textures.Add(Height);
        for (UTexture2D* Weight : Component->GetWeightmapTextures(FGuid())) if (Weight) Textures.Add(Weight);
    }
    Report->SetArrayField(TEXT("last_grass_texture_readiness"), Sizes);
    for (UTexture2D* Texture : Textures)
    {
        Texture->BlockOnAnyAsyncBuild();
        FTextureResource* Resource = Texture->GetResource();
        if (Texture->IsDefaultTexture() || !Resource || !Resource->TextureRHI.IsValid())
        {
            Texture->UpdateResourceWithParams(static_cast<UTexture::EUpdateResourceFlags>(
                uint32(UTexture::EUpdateResourceFlags::ForceRebuild) | uint32(UTexture::EUpdateResourceFlags::Synchronous)));
            Texture->BlockOnAnyAsyncBuild();
        }
    }
    FlushRenderingCommands();
    for (int32 Index = 0; Index < Proxy->LandscapeComponents.Num(); ++Index)
    {
        ULandscapeComponent* Component = Proxy->LandscapeComponents[Index];
        if (!Component) { Error = TEXT("GRASS_COMPONENT_MISSING"); return false; }
        UTexture2D* Height = Component->GetHeightmap(false);
        Sizes[Index]->AsObject()->SetNumberField(TEXT("runtime_ready_x"), Height->GetSizeX());
        Sizes[Index]->AsObject()->SetNumberField(TEXT("runtime_ready_y"), Height->GetSizeY());
        FTextureResource* Resource = Height->GetResource();
        if (Height->GetSizeX() != Height->Source.GetSizeX() || Height->GetSizeY() != Height->Source.GetSizeY()
            || !Resource || !Resource->TextureRHI.IsValid() || Height->IsDefaultTexture())
        { Error = TEXT("GRASS_HEIGHT_RESOURCE_SIZE_NOT_READY"); return false; }
        // Do not let the grass builder classify a component as NotReady while
        // its component material's fixed-grid grass shaders are still compiling.
        if (UMaterialInstance* Material = Component->GetMaterialInstance(0))
            if (FMaterialResource* MaterialResource = Material->GetMaterialResource(
                GetFeatureLevelShaderPlatform_Checked(Component->GetWorld()->GetFeatureLevel())))
                MaterialResource->FinishCompilation();
        // Subsection UV offsets are cached in the scene proxy constructor. Merely
        // waiting for texture compilation does not repair an already-created proxy.
        if (RecreateProxy) { FComponentRecreateRenderStateContext Recreate(Component); }
    }
    FlushRenderingCommands();
    for (int32 Index = 0; Index < Proxy->LandscapeComponents.Num(); ++Index)
    {
        ULandscapeComponent* Component = Proxy->LandscapeComponents[Index];
        const bool CanRender = Component->CanRenderGrassMap();
        Sizes[Index]->AsObject()->SetBoolField(TEXT("grass_shader_ready"), CanRender);
        if (!CanRender) { Error = TEXT("GRASS_SHADER_NOT_READY_NO_INSTALL"); return false; }
    }
    Report->SetArrayField(TEXT("last_grass_texture_readiness"), Sizes);
    return true;
}
}

bool Run(UWorld* World, const FString& Action, const FString& Job, const FString& ReportPath)
{
    const bool GrassMode = Action == TEXT("grass_scan") || Action == TEXT("grass_repair");
    const bool Repair = Action == TEXT("material_repair") || Action == TEXT("grass_repair");
    auto Report = MakeShared<FJsonObject>();
    Report->SetStringField(TEXT("schema_version"), GrassMode ? TEXT("landscape_grass_repair/1") : TEXT("landscape_material_repair/1"));
    Report->SetStringField(TEXT("job_id"), Job); Report->SetStringField(TEXT("action"), Action);
    Report->SetStringField(TEXT("map"), World->GetOutermost()->GetName());
    Report->SetStringField(TEXT("started_utc"), FDateTime::UtcNow().ToIso8601());
    Report->SetBoolField(TEXT("ok"), false); Report->SetBoolField(TEXT("map_saved"), false);
    Report->SetBoolField(TEXT("recurrence_verified"), false);
    Report->SetStringField(TEXT("shader_cache_mode"), IsMaterialMapDDCEnabled() ? TEXT("full_material_maps") : TEXT("per_shader"));
    Report->SetNumberField(TEXT("map_load_error_count"), GWarn->GetNumErrors());
    constexpr double GiB = 1024.0 * 1024.0 * 1024.0;
    double BudgetGiB = 0, ReservePhysicalGiB = 8, ReserveCommitGiB = 8;
    FParse::Value(FCommandLine::Get(), TEXT("MaterialMemoryBudgetGiB="), BudgetGiB);
    FParse::Value(FCommandLine::Get(), TEXT("MaterialReservePhysicalGiB="), ReservePhysicalGiB);
    FParse::Value(FCommandLine::Get(), TEXT("MaterialReserveCommitGiB="), ReserveCommitGiB);
    if (BudgetGiB < 0 || ReservePhysicalGiB < 1 || ReserveCommitGiB < 1) return false;
    const uint64 BudgetBytes = BudgetGiB > 0 ? uint64(BudgetGiB * GiB) : uint64(FPlatformMemory::GetConstants().TotalPhysical * 0.65);
    Report->SetNumberField(TEXT("memory_budget_bytes"), double(BudgetBytes));
    Report->SetNumberField(TEXT("reserve_physical_bytes"), ReservePhysicalGiB * GiB);
    Report->SetNumberField(TEXT("reserve_commit_bytes"), ReserveCommitGiB * GiB);
    // This maintenance command reports its own protected-data, shader and staging gates.
    // Keep unrelated map diagnostics in the log; use UE's supported commandlet result mode.
    for (TObjectIterator<UCommandlet> It; It; ++It)
        if (!It->HasAnyFlags(RF_ClassDefaultObject) && It->GetClass()->GetFName() == FName(TEXT("WorldPartitionBuilderCommandlet")))
            It->UseCommandletResultAsExitCode = true;
    TArray<TSharedPtr<FJsonValue>> Rows, PackageRows;
    auto Persist = [&]() { Report->SetArrayField(TEXT("components"), Rows); Report->SetArrayField(TEXT("packages"), PackageRows); return WriteJson(ReportPath, Report); };
    auto Fail = [&](const FString& Error) { Report->SetStringField(TEXT("error"), Error); Persist(); UE_LOG(LogLandscapeMaterialRepair, Error, TEXT("%s"), *Error); return false; };
    if (!World->GetWorldPartition() || (Action != TEXT("material_scan") && !GrassMode && !Repair)) return Fail(TEXT("MATERIAL_ACTION_UNSUPPORTED"));
    if (Repair && !FParse::Param(FCommandLine::Get(), GrassMode ? TEXT("AuthorizeGrassRepair") : TEXT("AuthorizeMaterialRepair"))) return Fail(TEXT("MATERIAL_AUTHORIZATION_REQUIRED"));
    FString ScopePath;
    TMap<FString, TSet<FString>> Scope;
    if (FParse::Value(FCommandLine::Get(), TEXT("MaterialTargets="), ScopePath))
    {
        FString Text; FJson Input;
        if (!FFileHelper::LoadFileToString(Text, *ScopePath) || !FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text), Input)) return Fail(TEXT("MATERIAL_SCOPE_INVALID"));
        if (Input->GetStringField(TEXT("map")) != World->GetOutermost()->GetName()) return Fail(TEXT("MATERIAL_SCOPE_MAP_MISMATCH"));
        for (const auto& Value : Input->GetArrayField(TEXT("targets")))
        {
            const FJson Target = Value->AsObject();
            FString Package = Target->GetStringField(TEXT("package"));
            if (!Package.StartsWith(TEXT("/Game/"))) Package = TEXT("/Game/") + Package;
            Scope.FindOrAdd(Package).Add(Target->GetStringField(TEXT("component")));
        }
        if (Scope.IsEmpty()) return Fail(TEXT("MATERIAL_SCOPE_EMPTY"));
    }
    UWorldPartition* WP = World->GetWorldPartition();
    TMap<FName, FString> DiskHashes;
    int32 TotalProxies = 0;
    FWorldPartitionHelpers::ForEachActorDescInstance<ALandscapeStreamingProxy>(WP, [&](const FWorldPartitionActorDescInstance* Desc)
    {
        ++TotalProxies;
        if (!Scope.IsEmpty() && !Scope.Contains(Desc->GetActorPackage().ToString())) return true;
        FString Filename;
        if (FPackageName::TryConvertLongPackageNameToFilename(Desc->GetActorPackage().ToString(), Filename, FPackageName::GetAssetPackageExtension()))
            DiskHashes.Add(Desc->GetActorPackage(), FileHash(Filename));
        return true;
    });
    Report->SetNumberField(TEXT("descriptor_proxy_count"), TotalProxies);
    Report->SetNumberField(TEXT("scope_proxy_count"), DiskHashes.Num());
    if (DiskHashes.IsEmpty() || (!Scope.IsEmpty() && Scope.Num() != DiskHashes.Num())) return Fail(TEXT("MATERIAL_SCOPE_COVERAGE_MISMATCH"));
    for (const auto& Pair : DiskHashes) if (Pair.Value.IsEmpty()) return Fail(TEXT("PACKAGE_UNREADABLE_BEFORE_LOAD"));
    const int32 TotalScopeProxies = DiskHashes.Num();
    int32 BatchOffset = 0, BatchLimit = TotalScopeProxies;
    const bool Batched = FParse::Value(FCommandLine::Get(), TEXT("MaterialBatchLimit="), BatchLimit);
    FParse::Value(FCommandLine::Get(), TEXT("MaterialBatchOffset="), BatchOffset);
    if (Batched && (!Repair || BatchOffset < 0 || BatchOffset >= TotalScopeProxies || BatchLimit < 1 || BatchLimit > 16))
        return Fail(TEXT("MATERIAL_BATCH_RANGE_INVALID"));
    if (Batched)
    {
        TArray<FName> OrderedPackages; DiskHashes.GetKeys(OrderedPackages);
        OrderedPackages.Sort([](const FName& A, const FName& B) { return A.LexicalLess(B); });
        TArray<TSharedPtr<FJsonValue>> Inputs;
        TMap<FName, FString> BatchHashes;
        for (int32 Index = 0; Index < OrderedPackages.Num(); ++Index)
        {
            const FName Name = OrderedPackages[Index];
            auto Input = MakeShared<FJsonObject>();
            Input->SetStringField(TEXT("package"), Name.ToString());
            Input->SetStringField(TEXT("original_sha1"), DiskHashes.FindChecked(Name));
            Inputs.Add(MakeShared<FJsonValueObject>(Input));
            if (Index >= BatchOffset && Index < BatchOffset + BatchLimit) BatchHashes.Add(Name, DiskHashes.FindChecked(Name));
        }
        Report->SetArrayField(TEXT("input_packages"), Inputs);
        Report->SetNumberField(TEXT("total_scope_proxy_count"), TotalScopeProxies);
        Report->SetNumberField(TEXT("batch_offset"), BatchOffset);
        Report->SetNumberField(TEXT("batch_limit"), BatchLimit);
        DiskHashes = MoveTemp(BatchHashes);
        Report->SetNumberField(TEXT("scope_proxy_count"), DiskHashes.Num());
    }
    if (!Persist()) return false;
    FWorldPartitionHelpers::FForEachActorWithLoadingResult ParentReferences;
    FWorldPartitionHelpers::FForEachActorWithLoadingParams ParentParams;
    ParentParams.ActorClasses.Reset(); ParentParams.ActorClasses.Add(ALandscape::StaticClass());
    ParentParams.bKeepReferences = true;
    int32 Parents = 0;
    FWorldPartitionHelpers::ForEachActorWithLoading(WP, [&](const FWorldPartitionActorDescInstance*) { ++Parents; return true; }, ParentParams, ParentReferences);
    if (Parents != 1) return Fail(TEXT("ONE_LANDSCAPE_PARENT_REQUIRED"));
    FWorldPartitionHelpers::FForEachActorWithLoadingParams Params;
    Params.ActorClasses.Reset(); Params.ActorClasses.Add(ALandscapeStreamingProxy::StaticClass());
    Params.bKeepReferences = false; Params.bGCPerActor = true;
    Params.FilterActorDescInstance = [&](const FWorldPartitionActorDescInstance* Desc) { return DiskHashes.Contains(Desc->GetActorPackage()); };
    bool Ok = true;
    int32 Loaded = 0, Selected = 0, Removed = 0, Candidates = 0;
    TSet<FString> FoundTargets;
    auto WithinMemoryBudget = [&]()
    {
        const FPlatformMemoryStats Memory = FPlatformMemory::GetStats();
        Report->SetNumberField(TEXT("peak_private_bytes"), double(Memory.PeakUsedVirtual));
        Report->SetNumberField(TEXT("current_private_bytes"), double(Memory.UsedVirtual));
        Report->SetNumberField(TEXT("available_physical_bytes"), double(Memory.AvailablePhysical));
        Report->SetNumberField(TEXT("available_commit_bytes"), double(Memory.AvailableVirtual));
        const FString Reason = Memory.AvailablePhysical < uint64(ReservePhysicalGiB * GiB) ? TEXT("system_physical_reserve")
            : Memory.AvailableVirtual < uint64(ReserveCommitGiB * GiB) ? TEXT("system_commit_reserve")
            : Memory.UsedVirtual > BudgetBytes ? TEXT("process_budget") : FString();
        if (!Reason.IsEmpty()) Report->SetStringField(TEXT("memory_guard_reason"), Reason);
        return Reason.IsEmpty();
    };
    FWorldPartitionHelpers::ForEachActorWithLoading(WP, [&](const FWorldPartitionActorDescInstance* Desc)
    {
        ++Loaded;
        auto Stop = [&](const FString& Error) { Ok = false; Fail(Error); return false; };
        if (!WithinMemoryBudget()) return Stop(TEXT("MATERIAL_MEMORY_GUARD"));
        ALandscapeStreamingProxy* Proxy = Cast<ALandscapeStreamingProxy>(Desc->GetActor());
        if (!Proxy || !Proxy->GetExternalPackage() || Proxy->GetExternalPackage()->GetFName() != Desc->GetActorPackage()) return Stop(TEXT("PROXY_EXTERNAL_PACKAGE_MISMATCH"));
        UPackage* Package = Proxy->GetExternalPackage();
        FString Original;
        if (!FPackageName::TryConvertLongPackageNameToFilename(Package->GetName(), Original, FPackageName::GetAssetPackageExtension())) return Stop(TEXT("PACKAGE_PATH_INVALID"));
        Original = FPaths::ConvertRelativePathToFull(Original);
        if (FileHash(Original) != DiskHashes.FindChecked(Desc->GetActorPackage())) return Stop(TEXT("PACKAGE_CHANGED_DURING_LOAD"));
        TMap<ULandscapeComponent*, FSnapshot> Before;
        FString Error;
        for (ULandscapeComponent* Component : Proxy->LandscapeComponents)
        {
            if (!Component || !Snapshot(Component, Before.FindOrAdd(Component), Error)) return Stop(TEXT("SNAPSHOT_FAILED:") + Error);
        }
        // PreSave recomposes shared edge weights. Keep adjacent terrain available for that merge,
        // while taking the protected snapshot before loading it and saving only the requested proxy.
        FWorldPartitionHelpers::FForEachActorWithLoadingResult NeighborReferences;
        if (Repair)
        {
            const FBox Bounds = Desc->GetEditorBounds();
            FWorldPartitionHelpers::FForEachActorWithLoadingParams Neighbors;
            Neighbors.ActorClasses.Reset(); Neighbors.ActorClasses.Add(ALandscapeStreamingProxy::StaticClass());
            Neighbors.bKeepReferences = true; Neighbors.bGCPerActor = false;
            Neighbors.FilterActorDescInstance = [&](const FWorldPartitionActorDescInstance* Other)
            {
                if (Other->GetActorPackage() == Desc->GetActorPackage()) return false;
                const FBox Box = Other->GetEditorBounds();
                return Box.Min.X <= Bounds.Max.X + 1 && Box.Max.X >= Bounds.Min.X - 1
                    && Box.Min.Y <= Bounds.Max.Y + 1 && Box.Max.Y >= Bounds.Min.Y - 1;
            };
            FWorldPartitionHelpers::ForEachActorWithLoading(WP, [](const FWorldPartitionActorDescInstance*) { return true; }, Neighbors, NeighborReferences);
            Report->SetNumberField(TEXT("current_neighbor_proxies"), NeighborReferences.ActorReferences.Num());
            if (!WithinMemoryBudget()) return Stop(TEXT("MATERIAL_MEMORY_GUARD"));
        }
        bool Changed = false;
        TSet<ULandscapeComponent*> GrassTargets;
        for (ULandscapeComponent* Component : Proxy->LandscapeComponents)
        {
            if (!Scope.IsEmpty() && !Scope.FindChecked(Package->GetName()).Contains(Component->GetName())) continue;
            ++Selected; FoundTargets.Add(Package->GetName() + TEXT(":") + Component->GetName());
            auto Row = MakeShared<FJsonObject>();
            Row->SetStringField(TEXT("component"), Component->GetName()); Row->SetStringField(TEXT("package"), Package->GetName());
            const int32 Initial = Component->GetWeightmapLayerAllocations(FGuid()).Num();
            Row->SetNumberField(TEXT("allocated_before"), Initial);
            Row->SetNumberField(TEXT("nonzero_layers"), Before.FindChecked(Component).NonzeroPaint.Num());
            if (GrassMode)
            {
                bool EdgeCorrupt;
                if (!AnalyseGrass(Component, Row, TEXT("before_"), EdgeCorrupt, Error)) return Stop(Error);
                Row->SetNumberField(TEXT("allocated_after"), Initial);
                Row->SetStringField(TEXT("protected_data_hash"), Before.FindChecked(Component).ProtectedHash);
                Row->SetBoolField(TEXT("grass_candidate"), EdgeCorrupt);
                if (EdgeCorrupt) { ++Candidates; if (Repair) { GrassTargets.Add(Component); Changed = true; } }
                Rows.Add(MakeShared<FJsonValueObject>(Row));
                continue;
            }
            TArray<TSharedPtr<FJsonValue>> Zeros;
            for (int32 Index = Initial - 1; Index >= 0; --Index)
            {
                const auto Allocation = Component->GetWeightmapLayerAllocations(FGuid())[Index];
                UTexture2D* Texture = Component->GetWeightmapTextures(FGuid())[Allocation.WeightmapTextureIndex];
                FString Hash; bool Zero;
                if (!PaintHash(Texture, Allocation.WeightmapTextureChannel, Hash, Zero)) return Stop(TEXT("PAINT_READ_FAILED"));
                if (!Zero || Allocation.LayerInfo == ALandscapeProxy::VisibilityLayer) continue;
                Zeros.Add(MakeShared<FJsonValueString>(Allocation.LayerInfo->GetLayerName().ToString()));
                if (Repair)
                {
                    ALandscape* Parent = Proxy->GetLandscapeActor();
                    if (!Parent) return Stop(TEXT("LANDSCAPE_PARENT_NOT_LOADED"));
                    // DeleteLayerIfAllZero and DeleteLayerAllocation are not DLL exports in UE 5.8.
                    // DeleteLayer is exported and delegates to the same allocation deletion.
                    FScopedSetLandscapeEditingLayer FinalLayer(Parent, FGuid());
                    FLandscapeEditDataInterface Edit(Proxy->GetLandscapeInfo(), FGuid(), false);
                    const int32 CountBeforeDelete = Component->GetWeightmapLayerAllocations(FGuid()).Num();
                    Component->DeleteLayer(Allocation.LayerInfo, Edit);
                    if (Component->GetWeightmapLayerAllocations(FGuid()).Num() != CountBeforeDelete - 1)
                        return Stop(TEXT("ZERO_LAYER_DELETE_REJECTED"));
                    Changed = true; ++Removed;
                }
            }
            Row->SetArrayField(TEXT("zero_layers"), Zeros);
            if (!Zeros.IsEmpty()) ++Candidates;
            Row->SetNumberField(TEXT("allocated_after"), Component->GetWeightmapLayerAllocations(FGuid()).Num());
            Row->SetStringField(TEXT("protected_data_hash"), Before.FindChecked(Component).ProtectedHash);
            if (Repair && !Zeros.IsEmpty())
            {
                // Refresh serialized component instances; compile only the diagnosed RVT shader for the save gate.
                Component->UpdateMaterialInstances();
                Row->SetStringField(TEXT("shader_check_stage"), TEXT("before_save"));
                if (!TargetShader(Component, Row)) { Rows.Add(MakeShared<FJsonValueObject>(Row)); Report->SetStringField(TEXT("error_component"), Component->GetName()); Report->SetStringField(TEXT("error_package"), Package->GetName()); return Stop(TEXT("TARGET_SHADER_FAILED_NO_INSTALL")); }
            }
            else Row->SetStringField(TEXT("shader_status"), TEXT("not_compiled"));
            Rows.Add(MakeShared<FJsonValueObject>(Row));
        }
        if (GrassMode && Changed)
        {
            const bool ProbeBaseline = FParse::Param(FCommandLine::Get(), TEXT("GrassProbeBaseline"));
            if (!PrepareGrassRendering(Proxy, Report, Error, !ProbeBaseline)) return Stop(Error);
            if (ProbeBaseline)
            {
                // Compare ready textures with the original scene proxy against a
                // newly-created proxy, using the native grass exporter both times.
                Report->SetBoolField(TEXT("grass_probe_enabled"), true);
                Proxy->FlushGrassComponents(&GrassTargets, true);
                Proxy->BuildGrassMaps();
                for (const auto& Value : Rows)
                {
                    const auto Row = Value->AsObject();
                    if (Row->GetStringField(TEXT("package")) != Package->GetName()) continue;
                    for (ULandscapeComponent* Component : GrassTargets) if (Component->GetName() == Row->GetStringField(TEXT("component")))
                    {
                        bool Corrupt;
                        if (!AnalyseGrass(Component, Row, TEXT("baseline_"), Corrupt, Error)) return Stop(Error);
                    }
                }
                for (ULandscapeComponent* Component : Proxy->LandscapeComponents)
                { FComponentRecreateRenderStateContext Recreate(Component); }
                FlushRenderingCommands();
            }
            Proxy->FlushGrassComponents(&GrassTargets, true);
            Proxy->BuildGrassMaps();
            for (const auto& Value : Rows)
            {
                const auto Row = Value->AsObject();
                if (Row->GetStringField(TEXT("package")) != Package->GetName()) continue;
                for (ULandscapeComponent* Component : GrassTargets) if (Component->GetName() == Row->GetStringField(TEXT("component")))
                {
                    bool Corrupt;
                    if (!AnalyseGrass(Component, Row, TEXT("rebuilt_"), Corrupt, Error)) return Stop(Error);
                    if (Row->GetStringField(TEXT("rebuilt_grass_status")) != TEXT("source_height_match"))
                    {
                        Report->SetStringField(TEXT("error_component"), Component->GetName());
                        Report->SetStringField(TEXT("error_package"), Package->GetName());
                        return Stop(TEXT("GRASS_REBUILD_HEIGHT_GATE_FAILED_NO_INSTALL"));
                    }
                }
            }
        }
        else if (!GrassMode && Changed)
        {
            // Material maintenance also invokes BuildGrassMaps through PreSave.
            // Prevent it from persisting the same stale subsection UV parameters.
            if (!PrepareGrassRendering(Proxy, Report, Error)) return Stop(Error);
        }
        for (const auto& Pair : Before)
        {
            FSnapshot After;
            if (!Snapshot(Pair.Key, After, Error) || !Same(Pair.Value, After)) return Stop(TEXT("PROTECTED_DATA_CHANGED_NO_INSTALL"));
        }
        if (Changed)
        {
            FString Relative = Original;
            FPaths::MakePathRelativeTo(Relative, *FPaths::ConvertRelativePathToFull(FPaths::ProjectDir()));
            if (!Relative.StartsWith(TEXT("Content/__ExternalActors__/")) || Relative.Contains(TEXT(".."))) return Stop(TEXT("EXTERNAL_PACKAGE_OUTSIDE_CONTENT"));
            const FString Staged = FPaths::Combine(FPaths::GetPath(ReportPath), TEXT("material-staged"), Relative);
            IFileManager::Get().MakeDirectory(*FPaths::GetPath(Staged), true);
            // Landscape PreSave may merge source layers again. Validate its actual result below.
            FSavePackageArgs Args; Args.TopLevelFlags = RF_Standalone; Args.SaveFlags = SAVE_NoError;
            if (!UPackage::SavePackage(Package, nullptr, *Staged, Args)) return Stop(TEXT("STAGED_SAVE_FAILED"));
            bool PersistedChange = false;
            for (const auto& Pair : Before)
            {
                FSnapshot AfterSave;
                if (!Snapshot(Pair.Key, AfterSave, Error) || !Same(Pair.Value, AfterSave))
                {
                    Report->SetStringField(TEXT("error_component"), Pair.Key->GetName());
                    Report->SetStringField(TEXT("error_package"), Package->GetName());
                    Report->SetBoolField(TEXT("protected_hash_unchanged"), Pair.Value.ProtectedHash == AfterSave.ProtectedHash);
                    return Stop(TEXT("SAVE_CHANGED_PROTECTED_DATA_NO_INSTALL"));
                }
                bool ComponentChanged = Pair.Value.AllPaint.Num() != AfterSave.AllPaint.Num();
                for (const auto& Paint : Pair.Value.AllPaint)
                {
                    const FString* SavedHash = AfterSave.AllPaint.Find(Paint.Key);
                    if (!SavedHash || *SavedHash != Paint.Value) ComponentChanged = true;
                }
                // Saving can recompose layers. Permit only removal of original zero allocations.
                for (const auto& Paint : AfterSave.AllPaint)
                {
                    const FString* OriginalHash = Pair.Value.AllPaint.Find(Paint.Key);
                    if (!OriginalHash || *OriginalHash != Paint.Value) return Stop(TEXT("SAVE_ADDED_OR_CHANGED_FINAL_LAYER_NO_INSTALL"));
                }
                if (ComponentChanged && !Scope.IsEmpty() && !Scope.FindChecked(Package->GetName()).Contains(Pair.Key->GetName()))
                    return Stop(TEXT("SAVE_CHANGED_UNSELECTED_COMPONENT_NO_INSTALL"));
                if (GrassMode && ComponentChanged) return Stop(TEXT("GRASS_SAVE_CHANGED_PAINT_ALLOCATIONS_NO_INSTALL"));
                PersistedChange |= ComponentChanged;
            }
            for (const auto& Value : Rows)
            {
                const FJson Row = Value->AsObject();
                if (Row->GetStringField(TEXT("package")) != Package->GetName()) continue;
                ULandscapeComponent* Component = nullptr;
                for (ULandscapeComponent* Candidate : Proxy->LandscapeComponents)
                    if (Candidate && Candidate->GetName() == Row->GetStringField(TEXT("component"))) { Component = Candidate; break; }
                if (!Component) return Stop(TEXT("SAVE_COMPONENT_MISSING_NO_INSTALL"));
                const int32 SavedCount = Component->GetWeightmapLayerAllocations(FGuid()).Num();
                const int32 BeforeCount = int32(Row->GetNumberField(TEXT("allocated_before")));
                const int32 PredictedCount = int32(Row->GetNumberField(TEXT("allocated_after")));
                Row->SetNumberField(TEXT("allocated_pre_save"), PredictedCount);
                Row->SetNumberField(TEXT("allocated_after"), SavedCount);
                Row->SetNumberField(TEXT("regenerated_on_save"), SavedCount - PredictedCount);
                if (GrassMode)
                {
                    bool Corrupt;
                    if (!AnalyseGrass(Component, Row, TEXT("after_"), Corrupt, Error)) return Stop(Error);
                    if (GrassTargets.Contains(Component) && Row->GetStringField(TEXT("after_grass_status")) != TEXT("source_height_match")) return Stop(TEXT("GRASS_SAVE_HEIGHT_GATE_FAILED_NO_INSTALL"));
                    Row->SetBoolField(TEXT("post_save_protected_data_verified"), true);
                    continue;
                }
                bool GrassCorrupt;
                if (!AnalyseGrass(Component, Row, TEXT("after_"), GrassCorrupt, Error)) return Stop(Error);
                if (GrassCorrupt) return Stop(TEXT("MATERIAL_SAVE_CORRUPTED_GRASS_NO_INSTALL"));
                Row->SetStringField(TEXT("shader_check_stage"), TEXT("after_save"));
                if (PredictedCount < BeforeCount && (SavedCount > BeforeCount || !TargetShader(Component, Row)))
                {
                    Report->SetStringField(TEXT("error_component"), Component->GetName());
                    Report->SetStringField(TEXT("error_package"), Package->GetName());
                    return Stop(TEXT("POST_SAVE_MATERIAL_GATE_FAILED_NO_INSTALL"));
                }
                Row->SetBoolField(TEXT("post_save_protected_data_verified"), true);
            }
            if (!PersistedChange && !GrassMode) return Persist(); // already repaired; don't install a metadata-only resave
            auto PackageRow = MakeShared<FJsonObject>();
            PackageRow->SetStringField(TEXT("relative"), Relative);
            PackageRow->SetStringField(TEXT("original_sha1"), DiskHashes.FindChecked(Desc->GetActorPackage()));
            PackageRow->SetStringField(TEXT("staged"), FPaths::ConvertRelativePathToFull(Staged));
            PackageRow->SetStringField(TEXT("staged_sha1"), FileHash(Staged));
            if (PackageRow->GetStringField(TEXT("staged_sha1")).IsEmpty()) return Stop(TEXT("STAGED_FILE_UNREADABLE"));
            PackageRows.Add(MakeShared<FJsonValueObject>(PackageRow));
        }
        Report->SetNumberField(TEXT("loaded_proxies"), Loaded); Report->SetNumberField(TEXT("selected_components"), Selected);
        Report->SetNumberField(TEXT("removed_allocations"), Removed); Report->SetNumberField(TEXT("staged_packages"), PackageRows.Num());
        Report->SetNumberField(TEXT("candidate_components"), Candidates);
        UE_LOG(LogLandscapeMaterialRepair, Display, TEXT("Material %s proxy %d/%d; components=%d removed=%d staged=%d"), *Action, Loaded, DiskHashes.Num(), Selected, Removed, PackageRows.Num());
        if (!Persist()) { Ok = false; return false; }
        return true;
    }, Params);
    if (!Ok) return false;
    if (Loaded != DiskHashes.Num()) return Fail(TEXT("MATERIAL_LOADED_COVERAGE_MISMATCH"));
    for (const auto& Pair : Scope) for (const FString& Name : Pair.Value)
        if ((!Batched || DiskHashes.Contains(FName(*Pair.Key))) && !FoundTargets.Contains(Pair.Key + TEXT(":") + Name)) return Fail(TEXT("MATERIAL_COMPONENT_MISSING"));
    Report->SetStringField(TEXT("phase"), Repair ? (Batched ? TEXT("batch_staged_not_installed") : TEXT("staged_not_installed")) : TEXT("scan_complete"));
    int32 PersistedRemoved = 0;
    for (const auto& Value : Rows)
        PersistedRemoved += int32(Value->AsObject()->GetNumberField(TEXT("allocated_before")) - Value->AsObject()->GetNumberField(TEXT("allocated_after")));
    Report->SetNumberField(TEXT("removed_allocations"), PersistedRemoved);
    Report->SetNumberField(TEXT("loaded_proxies"), Loaded);
    Report->SetNumberField(TEXT("selected_components"), Selected);
    Report->SetNumberField(TEXT("candidate_components"), Candidates);
    Report->SetNumberField(TEXT("staged_packages"), PackageRows.Num());
    Report->SetStringField(TEXT("finished_utc"), FDateTime::UtcNow().ToIso8601());
    Report->SetBoolField(TEXT("ok"), true);
    return Persist();
}
}
