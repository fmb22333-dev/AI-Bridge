#pragma once
#include "CoreMinimal.h"
class UWorld;
namespace AIBridgeUE::LandscapeMaterialRepair
{
// Writes staged packages only. The existing offline worker owns backup and installation.
bool Run(UWorld* World, const FString& Action, const FString& Job, const FString& ReportPath);
}
