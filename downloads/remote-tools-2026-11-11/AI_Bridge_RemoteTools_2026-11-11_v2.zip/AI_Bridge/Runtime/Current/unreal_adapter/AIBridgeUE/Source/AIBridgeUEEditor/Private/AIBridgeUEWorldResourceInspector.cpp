#include "AIBridgeUEWorldResourceInspector.h"

#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Editor.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "FoliageType.h"
#include "GameFramework/Actor.h"
#include "InstancedFoliage.h"
#include "InstancedFoliageActor.h"

namespace AIBridgeUE
{
namespace
{
constexpr int32 DefaultMaxComponents = 256;
constexpr int32 HardMaxComponents = 2048;
constexpr int32 HardMaxSamples = 16;
constexpr int32 HardMaxTags = 16;

int32 ReadLimit(const TSharedPtr<FJsonObject>& Arguments, const TCHAR* Name,
    const int32 DefaultValue, const int32 Minimum, const int32 Maximum)
{
    double Requested = 0.0;
    if (!Arguments.IsValid() || !Arguments->TryGetNumberField(Name, Requested) || !FMath::IsFinite(Requested))
    {
        return DefaultValue;
    }
    return static_cast<int32>(FMath::Clamp(Requested,
        static_cast<double>(Minimum), static_cast<double>(Maximum)));
}

TSharedRef<FJsonObject> MakeVector(const FVector& Value)
{
    TSharedRef<FJsonObject> Json = MakeShared<FJsonObject>();
    Json->SetNumberField(TEXT("x"), Value.X);
    Json->SetNumberField(TEXT("y"), Value.Y);
    Json->SetNumberField(TEXT("z"), Value.Z);
    return Json;
}

TArray<TSharedPtr<FJsonValue>> MakeTags(const TArray<FName>& Tags)
{
    TArray<TSharedPtr<FJsonValue>> Json;
    for (int32 Index = 0; Index < FMath::Min(Tags.Num(), HardMaxTags); ++Index)
    {
        Json.Add(MakeShared<FJsonValueString>(Tags[Index].ToString()));
    }
    return Json;
}

TSharedRef<FJsonObject> MakeComponentRecord(
    const AActor* Actor,
    const UInstancedStaticMeshComponent* Component,
    const FString& FoliageTypePath,
    const int32 SampleInstances)
{
    TSharedRef<FJsonObject> Record = MakeShared<FJsonObject>();
    Record->SetStringField(TEXT("actor_path"), Actor->GetPathName());
    Record->SetStringField(TEXT("component_path"), Component->GetPathName());
    Record->SetStringField(TEXT("component_class"), Component->GetClass()->GetPathName());
    Record->SetStringField(TEXT("component_type"),
        Component->IsA<UHierarchicalInstancedStaticMeshComponent>() ? TEXT("HISM") : TEXT("ISM"));
    Record->SetStringField(TEXT("source_kind"),
        FoliageTypePath.IsEmpty() ? TEXT("instanced_component") : TEXT("foliage_type"));
    Record->SetStringField(TEXT("foliage_type_path"), FoliageTypePath);
    Record->SetStringField(TEXT("mesh_path"),
        IsValid(Component->GetStaticMesh()) ? Component->GetStaticMesh()->GetPathName() : FString());
    Record->SetNumberField(TEXT("instance_count"), Component->GetInstanceCount());
    Record->SetBoolField(TEXT("collision_enabled"),
        Component->GetCollisionEnabled() != ECollisionEnabled::NoCollision);
    Record->SetArrayField(TEXT("actor_tags"), MakeTags(Actor->Tags));
    Record->SetArrayField(TEXT("component_tags"), MakeTags(Component->ComponentTags));

    TArray<TSharedPtr<FJsonValue>> Samples;
    for (int32 Index = 0; Index < FMath::Min(Component->GetInstanceCount(), SampleInstances); ++Index)
    {
        FTransform Transform;
        if (!Component->GetInstanceTransform(Index, Transform, true))
        {
            continue;
        }
        TSharedRef<FJsonObject> Sample = MakeShared<FJsonObject>();
        Sample->SetNumberField(TEXT("index"), Index);
        Sample->SetObjectField(TEXT("world_location"), MakeVector(Transform.GetLocation()));
        Samples.Add(MakeShared<FJsonValueObject>(Sample));
    }
    Record->SetArrayField(TEXT("sample_instances"), MoveTemp(Samples));
    return Record;
}
}

TSharedPtr<FJsonObject> InspectWorldResourceSourcesInWorld(
    UWorld* World,
    const TSharedPtr<FJsonObject>& Arguments,
    FString& OutErrorCode,
    FString& OutErrorMessage)
{
    OutErrorCode.Reset();
    OutErrorMessage.Reset();
    if (!IsValid(World))
    {
        OutErrorCode = TEXT("EDITOR_WORLD_UNAVAILABLE");
        OutErrorMessage = TEXT("No loaded editor world is available for instance source inspection.");
        return nullptr;
    }

    const int32 MaxComponents = ReadLimit(
        Arguments, TEXT("max_components"), DefaultMaxComponents, 1, HardMaxComponents);
    const int32 SampleInstances = ReadLimit(
        Arguments, TEXT("sample_instances"), 0, 0, HardMaxSamples);

    TArray<TSharedPtr<FJsonValue>> ComponentsJson;
    int64 InstanceCount = 0;
    bool bTruncated = false;
    for (TActorIterator<AActor> ActorIt(World); ActorIt && !bTruncated; ++ActorIt)
    {
        AActor* Actor = *ActorIt;
        if (!IsValid(Actor))
        {
            continue;
        }

        TMap<const UInstancedStaticMeshComponent*, FString> FoliageTypes;
        if (AInstancedFoliageActor* FoliageActor = Cast<AInstancedFoliageActor>(Actor))
        {
            FoliageActor->ForEachFoliageInfo(
                [&FoliageTypes](UFoliageType* FoliageType, FFoliageInfo& Info)
                {
                    if (IsValid(FoliageType) && IsValid(Info.GetComponent()))
                    {
                        FoliageTypes.Add(Info.GetComponent(), FoliageType->GetPathName());
                    }
                    return true;
                });
        }

        TInlineComponentArray<UInstancedStaticMeshComponent*> Components;
        Actor->GetComponents(Components);
        for (UInstancedStaticMeshComponent* Component : Components)
        {
            if (!IsValid(Component))
            {
                continue;
            }
            if (ComponentsJson.Num() >= MaxComponents)
            {
                bTruncated = true;
                break;
            }
            const FString* FoliageTypePath = FoliageTypes.Find(Component);
            ComponentsJson.Add(MakeShared<FJsonValueObject>(MakeComponentRecord(
                Actor, Component, FoliageTypePath ? *FoliageTypePath : FString(), SampleInstances)));
            InstanceCount += Component->GetInstanceCount();
        }
    }

    TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
    Result->SetStringField(TEXT("schema"), TEXT("aibridge_ue_world_resource_sources/1"));
    Result->SetStringField(TEXT("world_path"), World->GetPathName());
    Result->SetNumberField(TEXT("component_count"), ComponentsJson.Num());
    Result->SetNumberField(TEXT("listed_instance_count"), static_cast<double>(InstanceCount));
    Result->SetBoolField(TEXT("truncated"), bTruncated);
    Result->SetArrayField(TEXT("components"), MoveTemp(ComponentsJson));
    return Result;
}

TSharedPtr<FJsonObject> InspectCurrentWorldResourceSources(
    const TSharedPtr<FJsonObject>& Arguments,
    FString& OutErrorCode,
    FString& OutErrorMessage)
{
    UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
    return InspectWorldResourceSourcesInWorld(World, Arguments, OutErrorCode, OutErrorMessage);
}
}
