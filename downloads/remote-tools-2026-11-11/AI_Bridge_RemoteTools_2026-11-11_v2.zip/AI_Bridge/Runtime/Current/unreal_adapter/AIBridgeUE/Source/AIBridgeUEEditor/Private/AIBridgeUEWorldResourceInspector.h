#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"

class UWorld;

namespace AIBridgeUE
{
TSharedPtr<FJsonObject> InspectWorldResourceSourcesInWorld(
    UWorld* World,
    const TSharedPtr<FJsonObject>& Arguments,
    FString& OutErrorCode,
    FString& OutErrorMessage);

TSharedPtr<FJsonObject> InspectCurrentWorldResourceSources(
    const TSharedPtr<FJsonObject>& Arguments,
    FString& OutErrorCode,
    FString& OutErrorMessage);
}
