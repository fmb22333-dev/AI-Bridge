#if WITH_DEV_AUTOMATION_TESTS

#include "AIBridgeUEWorldResourceInspector.h"

#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "Misc/AutomationTest.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(
    FAIBridgeUEWorldResourceSourceInventoryTest,
    "AIBridgeUE.WorldResource.SourceInventory",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FAIBridgeUEWorldResourceSourceInventoryTest::RunTest(const FString& Parameters)
{
    UWorld* World = UWorld::CreateWorld(EWorldType::Game, false);
    TestNotNull(TEXT("Transient test world"), World);
    if (!World)
    {
        return false;
    }

    AActor* Actor = World->SpawnActor<AActor>();
    TestNotNull(TEXT("Source actor"), Actor);
    if (!Actor)
    {
        World->DestroyWorld(false);
        return false;
    }

    auto* ISM = NewObject<UInstancedStaticMeshComponent>(Actor);
    auto* HISM = NewObject<UHierarchicalInstancedStaticMeshComponent>(Actor);
    Actor->AddInstanceComponent(ISM);
    Actor->AddInstanceComponent(HISM);
    ISM->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    HISM->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    ISM->AddInstance(FTransform(FVector(100.0, 0.0, 0.0)));
    HISM->AddInstance(FTransform(FVector(200.0, 0.0, 0.0)));

    FString ErrorCode;
    FString ErrorMessage;
    TSharedPtr<FJsonObject> Result = AIBridgeUE::InspectWorldResourceSourcesInWorld(
        World, nullptr, ErrorCode, ErrorMessage);
    TestTrue(TEXT("Snapshot exists"), Result.IsValid());
    if (Result.IsValid())
    {
        TestEqual(TEXT("Schema"), Result->GetStringField(TEXT("schema")),
            FString(TEXT("aibridge_ue_world_resource_sources/1")));
        const TArray<TSharedPtr<FJsonValue>>& Components = Result->GetArrayField(TEXT("components"));
        TestEqual(TEXT("ISM and HISM are both listed"), Components.Num(), 2);
        for (const TSharedPtr<FJsonValue>& Value : Components)
        {
            const TSharedPtr<FJsonObject> Component = Value->AsObject();
            TestEqual(TEXT("Each component has one instance"),
                static_cast<int32>(Component->GetNumberField(TEXT("instance_count"))), 1);
            TestFalse(TEXT("Collision is disabled"), Component->GetBoolField(TEXT("collision_enabled")));
        }
    }

    TSharedPtr<FJsonObject> LimitedArgs = MakeShared<FJsonObject>();
    LimitedArgs->SetNumberField(TEXT("max_components"), 1);
    TSharedPtr<FJsonObject> Limited = AIBridgeUE::InspectWorldResourceSourcesInWorld(
        World, LimitedArgs, ErrorCode, ErrorMessage);
    TestTrue(TEXT("Bounded snapshot exists"), Limited.IsValid());
    if (Limited.IsValid())
    {
        TestEqual(TEXT("One component returned"), Limited->GetArrayField(TEXT("components")).Num(), 1);
        TestTrue(TEXT("Truncation reported"), Limited->GetBoolField(TEXT("truncated")));
    }

    World->DestroyWorld(false);
    return true;
}

#endif
