#include "AIBridgeUEWorldResourceWriter.h"

#include "IPythonScriptPlugin.h"
#include "HAL/FileManager.h"
#include "Misc/Paths.h"
#include "PythonScriptTypes.h"
#include "Serialization/JsonSerializer.h"

namespace AIBridgeUE
{
namespace
{
FString PythonLiteral(FString Value)
{
    FPaths::NormalizeFilename(Value);
    Value.ReplaceInline(TEXT("\\"), TEXT("\\\\"));
    Value.ReplaceInline(TEXT("'"), TEXT("\\'"));
    return FString::Printf(TEXT("'%s'"), *Value);
}
}

TSharedPtr<FJsonObject> WriteWorldResourceDefinitions(
    const bool bDryRun, FString& OutErrorCode, FString& OutErrorMessage)
{
    OutErrorCode.Reset();
    OutErrorMessage.Reset();
    const FString ScriptDirectory = FPaths::Combine(FPaths::ProjectDir(), TEXT("Scripts/WorldResource"));
    const FString ScriptPath = FPaths::Combine(ScriptDirectory, TEXT("import_definitions.py"));
    if (!IFileManager::Get().FileExists(*ScriptPath))
    {
        OutErrorCode = TEXT("WORLD_RESOURCE_IMPORTER_MISSING");
        OutErrorMessage = FString::Printf(TEXT("Importer script unavailable: %s"), *ScriptPath);
        return nullptr;
    }
    IPythonScriptPlugin* Python = IPythonScriptPlugin::Get();
    if (!Python || (!Python->IsPythonAvailable() && !Python->ForceEnablePythonAtRuntime()))
    {
        OutErrorCode = TEXT("PYTHON_UNAVAILABLE");
        OutErrorMessage = TEXT("PythonScriptPlugin is unavailable in the editor.");
        return nullptr;
    }

    // The mode and path are fixed by this adapter; callers cannot supply code or an output location.
    const FString Mode = bDryRun ? TEXT("preview") : TEXT("apply");
    FPythonCommandEx Command;
    Command.Flags = EPythonCommandFlags::Unattended;
    Command.ExecutionMode = EPythonCommandExecutionMode::ExecuteStatement;
    Command.Command = FString::Printf(
        TEXT("print((__import__('sys').path.insert(0, %s), __import__('runpy').run_path(%s)['run_bridge']('%s'))[1])"),
        *PythonLiteral(ScriptDirectory), *PythonLiteral(ScriptPath), *Mode);
    if (!Python->ExecPythonCommandEx(Command))
    {
        OutErrorCode = TEXT("WORLD_RESOURCE_IMPORTER_EXCEPTION");
        OutErrorMessage = Command.CommandResult.Left(1024);
        return nullptr;
    }
    TSharedPtr<FJsonObject> Result;
    for (const FPythonLogOutputEntry& Entry : Command.LogOutput)
    {
        const TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Entry.Output);
        TSharedPtr<FJsonObject> Candidate;
        if (FJsonSerializer::Deserialize(Reader, Candidate) && Candidate.IsValid()
            && Candidate->HasField(TEXT("schema")))
        {
            Result = MoveTemp(Candidate);
            break;
        }
    }
    if (!Result.IsValid())
    {
        OutErrorCode = TEXT("WORLD_RESOURCE_IMPORTER_INVALID_RESULT");
        OutErrorMessage = FString::Printf(
            TEXT("WorldResource importer emitted no JSON result (%d Python log entries; result %s)."),
            Command.LogOutput.Num(), *Command.CommandResult.Left(120));
        return nullptr;
    }
    bool bOk = false;
    Result->TryGetBoolField(TEXT("ok"), bOk);
    if (!bOk)
    {
        OutErrorCode = bDryRun ? TEXT("WORLD_RESOURCE_PREVIEW_FAILED") : TEXT("WORLD_RESOURCE_APPLY_FAILED");
        OutErrorMessage = TEXT("Importer returned validation or apply errors; inspect result.errors and backup_root.");
    }
    return Result;
}
}
