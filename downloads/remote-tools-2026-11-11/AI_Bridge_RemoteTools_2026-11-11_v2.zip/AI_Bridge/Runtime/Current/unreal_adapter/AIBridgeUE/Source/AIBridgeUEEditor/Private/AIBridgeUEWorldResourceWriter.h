#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"

namespace AIBridgeUE
{
/** Executes only the fixed project WorldResource importer, never arbitrary Python supplied by a caller. */
TSharedPtr<FJsonObject> WriteWorldResourceDefinitions(
    bool bDryRun, FString& OutErrorCode, FString& OutErrorMessage);
}
