#if WITH_DEV_AUTOMATION_TESTS

#include "AIBridgeUEWorldResourceWriter.h"
#include "Misc/AutomationTest.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(
    FAIBridgeUEWorldResourceBatchPreviewTest,
    "AIBridgeUE.WorldResource.BatchPreview",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FAIBridgeUEWorldResourceBatchPreviewTest::RunTest(const FString& Parameters)
{
    FString ErrorCode;
    FString ErrorMessage;
    TSharedPtr<FJsonObject> Result = AIBridgeUE::WriteWorldResourceDefinitions(
        true, ErrorCode, ErrorMessage);
    TestTrue(TEXT("Bridge wrapper returns a preview object"), Result.IsValid());
    if (!Result.IsValid())
    {
        AddError(ErrorCode + TEXT(": ") + ErrorMessage);
        return false;
    }
    bool bOk = false;
    Result->TryGetBoolField(TEXT("ok"), bOk);
    TestTrue(TEXT("Preview validates the project definitions"), bOk);
    double Count = 0.0;
    Result->TryGetNumberField(TEXT("resource_count"), Count);
    const TArray<TSharedPtr<FJsonValue>>* Operations = nullptr;
    TestTrue(TEXT("Preview contains an operation list"),
        Result->TryGetArrayField(TEXT("operations"), Operations));
    if (!Operations)
    {
        return false;
    }
    TSet<FString> ResourceIds;
    int32 ResourceOperations = 0;
    for (const TSharedPtr<FJsonValue>& Operation : *Operations)
    {
        const TSharedPtr<FJsonObject> Item = Operation->AsObject();
        if (Item.IsValid() && Item->HasField(TEXT("id")))
        {
            ++ResourceOperations;
            ResourceIds.Add(Item->GetStringField(TEXT("id")));
        }
    }
    TestEqual(TEXT("Resource count matches preview operations"),
        static_cast<int32>(Count), ResourceOperations);
    TestTrue(TEXT("Target map tall tree is present"), ResourceIds.Contains(TEXT("BH_Tree_Tall_01")));
    TestTrue(TEXT("Target map small tree is present"), ResourceIds.Contains(TEXT("BH_Tree_Small_03")));
    TestTrue(TEXT("Target map bush is present"), ResourceIds.Contains(TEXT("BH_Bush_B_01_Pickup")));
    return true;
}

#endif
